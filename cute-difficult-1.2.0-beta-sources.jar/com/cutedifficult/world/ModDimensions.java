package com.cutedifficult.world;

import com.cutedifficult.CuteDifficult;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Registry keys for Cute Difficult's custom dimensions.
 *
 * <p>The actual dimension is defined in datapack JSON:
 * <ul>
 *   <li>{@code data/cutedifficult/dimension_type/horizon.json} — physics</li>
 *   <li>{@code data/cutedifficult/dimension/horizon.json} — generation
 *       (a flat void with The Void biome everywhere)</li>
 * </ul>
 *
 * <p>This class only holds the {@link class_5321} so Java code (the
 * Interstellar teleport item) can reference the dimension by key.
 */
public final class ModDimensions {

    /** The Horizon — an empty void dimension for building anything. */
    public static final class_5321<class_1937> HORIZON = class_5321.method_29179(
        class_7924.field_41223,
        class_2960.method_60655(CuteDifficult.MOD_ID, "horizon"));

    private ModDimensions() {}

    public static void init() {
        CuteDifficult.LOGGER.info("[CuteDifficult] Dimension keys registered: horizon");
    }
}
