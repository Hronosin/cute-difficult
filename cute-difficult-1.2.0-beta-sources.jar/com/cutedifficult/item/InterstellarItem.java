package com.cutedifficult.item;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.world.ModDimensions;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The Interstellar — a relic that tears a hole between worlds. Right-click to
 * travel to {@link ModDimensions#HORIZON the Horizon}, an empty void dimension
 * where you can build anything. Right-click again to leave.
 *
 * <h2>Travel rules</h2>
 * <ul>
 *   <li><b>Entering</b> (from ANY dimension) drops you at YOUR personal island
 *       — a unique coordinate derived from your UUID, so every player gets
 *       their own corner of the void. We remember where you came from.</li>
 *   <li><b>Leaving normally</b> returns you to the exact dimension + spot you
 *       entered from.</li>
 *   <li><b>Leaving while sneaking (Shift)</b> drops you in the SAME dimension
 *       you entered from, but at the coordinates matching your current Horizon
 *       position scaled up — 1 Horizon block = {@value #SCALE_DEFAULT} blocks
 *       in the Overworld/End, or {@value #SCALE_NETHER} in the Nether. The
 *       saved return point is discarded.</li>
 * </ul>
 *
 * <p>Fall damage is cancelled in the Horizon (see HorizonHandler). The item is
 * not consumed — it's an expensive endgame key meant to be kept.
 */
public class InterstellarItem extends class_1792 {

    /** Coordinate scale: 1 Horizon block = this many blocks in Overworld/End. */
    private static final int SCALE_DEFAULT = 40;
    /** 1 Horizon block = this many Nether blocks. */
    private static final int SCALE_NETHER = 5;
    /** Y level of personal arrival platforms. */
    private static final int ARRIVAL_Y = 64;
    /** Spacing between players' personal islands, in Horizon blocks. */
    private static final int ISLAND_SPACING = 1024;

    private static final Map<UUID, ReturnPoint> RETURN_POINTS = new ConcurrentHashMap<>();

    private record ReturnPoint(class_5321<class_1937> dimension,
                               double x, double y, double z, float yaw, float pitch) {}

    public InterstellarItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (world.field_9236) return class_1271.method_22427(stack);
        if (!(user instanceof class_3222 player)) return class_1271.method_22430(stack);
        MinecraftServer server = player.method_5682();
        if (server == null) return class_1271.method_22430(stack);

        user.method_7357().method_7906(this, 60);

        boolean inHorizon = world.method_27983() == ModDimensions.HORIZON;
        if (inHorizon) {
            if (player.method_5715()) {
                exitInPlace(server, player);
            } else {
                exitToReturnPoint(server, player);
            }
        } else {
            enterHorizon(server, player);
        }
        return class_1271.method_22427(stack);
    }

    // ===== Entering =====

    private void enterHorizon(MinecraftServer server, class_3222 player) {
        class_3218 horizon = server.method_3847(ModDimensions.HORIZON);
        if (horizon == null) {
            player.method_7353(class_2561.method_43470("The Horizon does not answer. (dimension not loaded)")
                    .method_27692(class_124.field_1061), false);
            CuteDifficult.LOGGER.warn("[CuteDifficult] Horizon world is null — datapack dimension missing?");
            return;
        }

        // Remember where we came from for a normal exit.
        RETURN_POINTS.put(player.method_5667(), new ReturnPoint(
                player.method_37908().method_27983(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()));

        // Personal island coordinate, unique per player.
        class_2338 island = personalIsland(player.method_5667());
        buildPlatform(horizon, island.method_10074());

        player.method_48105(horizon,
                island.method_10263() + 0.5, island.method_10264(), island.method_10260() + 0.5,
                Set.of(), player.method_36454(), player.method_36455());

        horizon.method_14199(class_2398.field_23190,
                island.method_10263() + 0.5, island.method_10264() + 1, island.method_10260() + 0.5,
                40, 0.5, 1.0, 0.5, 0.2);
        horizon.method_8396(null, island,
                class_3417.field_14716, class_3419.field_15248, 0.6f, 1.2f);
        player.method_7353(class_2561.method_43470("You step beyond the edge of everything. Welcome to the Horizon.")
                .method_27695(class_124.field_1076, class_124.field_1056), false);
        player.method_7353(class_2561.method_43470("(Sneak + use to exit at your current position, scaled to the world.)")
                .method_27695(class_124.field_1063, class_124.field_1056), true);
    }

    /** A unique, stable island position for a player, spread far apart but
     *  kept within sane coordinates — even after the ×40 exit scale, the
     *  result must stay well inside the world border. */
    private static class_2338 personalIsland(UUID uuid) {
        long h = uuid.getMostSignificantBits() ^ uuid.getLeastSignificantBits();
        // Constrain to a small grid: roughly ±24 cells each axis. With
        // ISLAND_SPACING = 1024 that's about ±24,576 Horizon blocks, which
        // becomes ±983,040 after the ×40 Overworld scale — comfortably inside
        // the ±29,999,984 world border.
        int gx = (int) Math.floorMod(h, 49) - 24;
        int gz = (int) Math.floorMod(h >>> 16, 49) - 24;
        return new class_2338(gx * ISLAND_SPACING, ARRIVAL_Y, gz * ISLAND_SPACING);
    }

    // ===== Normal exit (to saved return point) =====

    private void exitToReturnPoint(MinecraftServer server, class_3222 player) {
        ReturnPoint rp = RETURN_POINTS.remove(player.method_5667());
        class_3218 targetWorld = (rp != null) ? server.method_3847(rp.dimension()) : null;

        double tx, ty, tz;
        float tyaw, tpitch;

        if (targetWorld != null) {
            tx = rp.x(); ty = rp.y(); tz = rp.z();
            tyaw = rp.yaw(); tpitch = rp.pitch();
        } else {
            class_3218 overworld = server.method_30002();
            if (overworld == null) return;
            class_2338 spawn = player.method_26280() != null
                    ? player.method_26280() : overworld.method_43126();
            targetWorld = overworld;
            tx = spawn.method_10263() + 0.5; ty = spawn.method_10264(); tz = spawn.method_10260() + 0.5;
            tyaw = player.method_36454(); tpitch = player.method_36455();
        }

        player.method_48105(targetWorld, tx, ty, tz, Set.of(), tyaw, tpitch);
        targetWorld.method_8396(null, class_2338.method_49637(tx, ty, tz),
                class_3417.field_14716, class_3419.field_15248, 0.6f, 0.8f);
        player.method_7353(class_2561.method_43470("The Horizon releases you. You return to where you tore the veil.")
                .method_27695(class_124.field_1075, class_124.field_1056), false);
    }

    // ===== Sneak exit (scaled, in place) =====

    private void exitInPlace(MinecraftServer server, class_3222 player) {
        ReturnPoint rp = RETURN_POINTS.remove(player.method_5667());
        class_5321<class_1937> destKey = (rp != null) ? rp.dimension() : class_1937.field_25179;
        class_3218 dest = server.method_3847(destKey);
        if (dest == null) {
            dest = server.method_30002();
            if (dest == null) return;
        }

        int scale = scaleFor(dest.method_27983());
        double tx = player.method_23317() * scale;
        double tz = player.method_23321() * scale;

        // Clamp to just inside the destination's world border so we never
        // teleport into the "far lands" / invalid space.
        double limit = dest.method_8621().method_11965() / 2.0 - 16;
        double center = dest.method_8621().method_11964();
        double centerZ = dest.method_8621().method_11980();
        tx = Math.max(center - limit, Math.min(center + limit, tx));
        tz = Math.max(centerZ - limit, Math.min(centerZ + limit, tz));

        // Find safe ground at the scaled spot via the heightmap (same call used
        // elsewhere in the mod). If the column is void, keep the player's Y.
        class_2338 column = class_2338.method_49637(tx, player.method_23318(), tz);
        class_2338 top = dest.method_8598(
                net.minecraft.class_2902.class_2903.field_13197, column);
        class_2338 safe = (top.method_10264() > dest.method_31607()) ? top : column;

        player.method_48105(dest, safe.method_10263() + 0.5, safe.method_10264(), safe.method_10260() + 0.5,
                Set.of(), player.method_36454(), player.method_36455());
        dest.method_8396(null, safe,
                class_3417.field_14716, class_3419.field_15248, 0.7f, 0.6f);
        player.method_7353(class_2561.method_43470(String.format(
                        "You fold space and step out at %d, %d, %d — the Horizon's distances writ large.",
                        safe.method_10263(), safe.method_10264(), safe.method_10260()))
                .method_27695(class_124.field_1076, class_124.field_1056), false);
    }

    private static int scaleFor(class_5321<class_1937> dim) {
        if (dim == class_1937.field_25180) return SCALE_NETHER;
        return SCALE_DEFAULT; // Overworld, End, and everything else
    }

    // ===== Helpers =====

    private void buildPlatform(class_3218 world, class_2338 center) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                class_2338 p = center.method_10069(dx, 0, dz);
                if (world.method_8320(p).method_26215()) {
                    world.method_8501(p, class_2246.field_10540.method_9564());
                }
            }
        }
    }

    @Override
    public void method_7851(class_1799 stack, class_9635 context,
                              java.util.List<class_2561> tooltip, net.minecraft.class_1836 type) {
        tooltip.add(class_2561.method_43470("Tears a path to the Horizon — and back.")
                .method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("Sneak + use in the Horizon to exit in place, scaled to the world.")
                .method_27695(class_124.field_1063, class_124.field_1056));
        tooltip.add(class_2561.method_43470("1 Horizon block = 40 Overworld blocks (5 in the Nether).")
                .method_27695(class_124.field_1063, class_124.field_1056));
    }
}