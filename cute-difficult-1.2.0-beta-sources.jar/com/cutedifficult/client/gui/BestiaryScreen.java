package com.cutedifficult.client.gui;

import com.cutedifficult.spirit.Element;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * The Bestiary of Inari — a clean scrollable list of all nine elements and
 * their five tail-tiers, showing which the player has discovered.
 *
 * <p>Replaces the old book.png page-flip layout with a standard dark panel
 * and mouse-wheel scrolling, so the player can see everything at a glance.
 * Each element block shows: kami name, flavor, tiered offerings (cheap /
 * standard / premium), and a row of five tail-tier badges (lit if discovered).
 */
public class BestiaryScreen extends class_437 {

    private final Set<String> entries;
    private final int totalDiscovered;
    private final int maxEntries;

    private double scroll = 0;
    private int contentHeight = 0;

    private static final String[] TIERS = {"young", "matured", "venerable", "ancient", "Kyuubi"};
    private static final int PANEL_WIDTH = 340;
    private static final int ELEMENT_BLOCK_HEIGHT = 78;
    private static final int HEADER_HEIGHT = 40;

    public BestiaryScreen(Set<String> entries, int maxEntries) {
        super(class_2561.method_43470("Bestiary of Inari"));
        this.entries = entries;
        this.totalDiscovered = entries.size();
        this.maxEntries = maxEntries;
    }

    @Override
    protected void method_25426() {
        this.contentHeight = HEADER_HEIGHT + Element.values().length * ELEMENT_BLOCK_HEIGHT + 20;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int viewport = this.field_22790 - 40;
        double maxScroll = Math.max(0, contentHeight - viewport);
        scroll = Math.max(0, Math.min(maxScroll, scroll - verticalAmount * 18));
        return true;
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // NOTE: do NOT call this.renderBackground(...) — in 1.21.1 it applies
        // a gaussian blur that smears over everything we draw. Instead draw a
        // plain translucent darkening fill ourselves.
        ctx.method_25294(0, 0, this.field_22789, this.field_22790, 0xC0000000);

        int panelLeft = (this.field_22789 - PANEL_WIDTH) / 2;
        int panelRight = panelLeft + PANEL_WIDTH;
        int top = 20;
        int bottom = this.field_22790 - 20;

        // Panel background.
        ctx.method_25294(panelLeft - 6, top - 6, panelRight + 6, bottom + 6, 0xF0100018);
        ctx.method_25294(panelLeft - 4, top - 4, panelRight + 4, bottom + 4, 0xFF2A1A3A);

        // Enable scissor so content clips to the panel.
        ctx.method_44379(panelLeft - 4, top, panelRight + 4, bottom);

        int y = top - (int) scroll;

        // Header.
        ctx.method_27534(this.field_22793,
                class_2561.method_43470("✦ Bestiary of Inari ✦").method_27695(class_124.field_1065, class_124.field_1067),
                this.field_22789 / 2, y + 4, 0xFFFFFF);
        ctx.method_27534(this.field_22793,
                class_2561.method_43470("Discovered " + totalDiscovered + " / " + maxEntries)
                        .method_27692(class_124.field_1080),
                this.field_22789 / 2, y + 18, 0xFFFFFF);
        y += HEADER_HEIGHT;

        // Element blocks.
        for (Element element : Element.values()) {
            renderElementBlock(ctx, element, panelLeft, y);
            y += ELEMENT_BLOCK_HEIGHT;
        }

        ctx.method_44380();

        // Scroll hint.
        if (contentHeight > (bottom - top)) {
            ctx.method_27534(this.field_22793,
                    class_2561.method_43470("scroll ↕").method_27692(class_124.field_1063),
                    this.field_22789 / 2, bottom - 2, 0xFFFFFF);
        }
        // No widgets to draw — this screen is pure scroll content, so we
        // intentionally skip super.render() to avoid re-applying the blur.
    }

    private void renderElementBlock(class_332 ctx, Element element, int panelLeft, int y) {
        int x = panelLeft + 8;

        // Element name.
        ctx.method_27535(this.field_22793,
                class_2561.method_43470(element.kamiName()).method_27695(element.color(), class_124.field_1067),
                x, y, 0xFFFFFF);

        // Discovered count for this element.
        int discovered = 0;
        for (String tier : TIERS) {
            if (entries.contains(element.name() + ":" + tier)) discovered++;
        }
        ctx.method_27535(this.field_22793,
                class_2561.method_43470(discovered + "/5").method_27692(
                        discovered == 5 ? class_124.field_1060 : class_124.field_1080),
                panelLeft + PANEL_WIDTH - 32, y, 0xFFFFFF);

        // Flavor (wrapped to one short line).
        String flavor = element.flavor();
        if (flavor.length() > 58) flavor = flavor.substring(0, 55) + "...";
        ctx.method_27535(this.field_22793,
                class_2561.method_43470(flavor).method_27695(class_124.field_1063, class_124.field_1056),
                x, y + 11, 0xFFFFFF);

        // Tier badges — five boxes, lit if discovered.
        int badgeY = y + 24;
        int badgeX = x;
        for (String tier : TIERS) {
            boolean known = entries.contains(element.name() + ":" + tier);
            int color = known ? colorOf(element.color()) : 0xFF333333;
            ctx.method_25294(badgeX, badgeY, badgeX + 60, badgeY + 11, color);
            ctx.method_51439(this.field_22793,
                    class_2561.method_43470(tier).method_27692(known ? class_124.field_1068 : class_124.field_1063),
                    badgeX + 3, badgeY + 2, 0xFFFFFF, false);
            badgeX += 64;
        }

        // Offerings row: cheap / standard / premium item icons.
        int offY = y + 40;
        ctx.method_27535(this.field_22793,
                class_2561.method_43470("Offerings:").method_27692(class_124.field_1080),
                x, offY + 4, 0xFFFFFF);
        int iconX = x + 64;
        drawOffering(ctx, new class_1799(element.cheapOffering()), iconX, offY, "cheap");
        drawOffering(ctx, new class_1799(element.standardOffering()), iconX + 90, offY, "standard");
        drawOffering(ctx, new class_1799(element.premiumOffering()), iconX + 190, offY, "premium");

        // Separator line.
        ctx.method_25294(panelLeft + 6, y + ELEMENT_BLOCK_HEIGHT - 6,
                panelLeft + PANEL_WIDTH - 6, y + ELEMENT_BLOCK_HEIGHT - 5, 0xFF3D2A55);
    }

    private void drawOffering(class_332 ctx, class_1799 stack, int x, int y, String label) {
        ctx.method_51427(stack, x, y);
        class_124 labelColor = switch (label) {
            case "cheap" -> class_124.field_1063;
            case "premium" -> class_124.field_1065;
            default -> class_124.field_1080;
        };
        ctx.method_51439(this.field_22793,
                class_2561.method_43470(label).method_27692(labelColor),
                x + 18, y + 4, 0xFFFFFF, false);
    }

    /** Map a Formatting color to an ARGB int with some transparency for badges. */
    private int colorOf(class_124 fmt) {
        Integer c = fmt.method_532();
        int rgb = (c == null) ? 0x888888 : c;
        return 0xCC000000 | rgb;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public static void open(Set<String> entries, int maxEntries) {
        class_310.method_1551().method_1507(new BestiaryScreen(entries, maxEntries));
    }
}