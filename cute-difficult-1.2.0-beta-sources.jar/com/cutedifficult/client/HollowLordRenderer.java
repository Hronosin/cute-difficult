package com.cutedifficult.client;

import com.cutedifficult.entity.HollowLordEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_927;

/**
 * Renders the Hollow Lord as a fallen monk: a humanoid (player-model) figure,
 * scaled to twice player size, in a custom void-themed skin. Unlike the dragon
 * model, the player/biped model isn't bound to a specific entity type, so it
 * renders cleanly on our FlyingEntity-based boss.
 *
 * <p>The skin texture lives at
 * {@code assets/cutedifficult/textures/entity/hollow_lord.png} — a 64×64 player
 * skin layout (Steve / wide-arms model). Supply your own art there.
 */
public class HollowLordRenderer extends class_927<HollowLordEntity, class_591<HollowLordEntity>> {

    private static final class_2960 TEXTURE =
        class_2960.method_60655("cutedifficult", "textures/entity/hollow_lord.png");
    private static final float SCALE = 2.0f;

    public HollowLordRenderer(class_5617.class_5618 ctx) {
        // false = use the wide-arms (Steve) player model layer.
        super(ctx, new class_591<>(ctx.method_32167(class_5602.field_27577), false), 1.0f);
    }

    @Override
    public class_2960 getTexture(HollowLordEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(HollowLordEntity entity, class_4587 matrices, float amount) {
        matrices.method_22905(SCALE, SCALE, SCALE);
    }
}
