package com.cutedifficult.entity;

import com.cutedifficult.CuteDifficult;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1308;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_2902;
import net.minecraft.class_9169;

/**
 * Registers natural spawning for the kitsune. Two parts:
 * <ul>
 *   <li><b>SpawnRestriction</b> — the rules for a valid spawn position (on
 *       ground, animal-style light/world checks), mirroring vanilla foxes.</li>
 *   <li><b>BiomeModifications</b> — which biomes the kitsune spawns in, and how
 *       often. We add them broadly across the Overworld so every element's
 *       themed biome is covered (the entity picks its element from the biome at
 *       spawn — see {@link KitsuneSpawnLogic}).</li>
 * </ul>
 */
public final class ModSpawns {

    private ModSpawns() {}

    public static void init() {
        // Valid-position rule: on ground, like other passive animals.
        class_1317.method_20637(ModEntities.KITSUNE,
                class_9169.field_48745,
                class_2902.class_2903.field_13203,
                class_1308::method_20636);

        // Spawn across the Overworld. Weight ~20 (uncommon but present), groups
        // of 1-2. The element is decided per-biome at spawn time.
        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                class_1311.field_6294,
                ModEntities.KITSUNE,
                20,  // spawn weight
                1,   // min group size
                2);  // max group size

        CuteDifficult.LOGGER.info("[CuteDifficult] Kitsune natural spawns registered.");
    }
}