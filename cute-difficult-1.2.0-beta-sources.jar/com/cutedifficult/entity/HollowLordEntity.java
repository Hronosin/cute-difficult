package com.cutedifficult.entity;

import com.cutedifficult.CuteDifficult;
import java.util.EnumSet;
import net.minecraft.class_124;
import net.minecraft.class_1259;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1307;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1331;
import net.minecraft.class_1352;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * The Hollow Lord — the mod's final boss, rebuilt from scratch on a flying-mob
 * base (instead of extending the Ender Dragon, which fought us on boss bars,
 * serialization, and phase control). This gives full control: our own AI,
 * our own boss bar, clean NBT, predictable behavior across reloads.
 *
 * <p>It renders with the vanilla dragon model (see HollowLordRenderer) at a
 * medium scale. Combat (attacks, phases) is layered in
 * {@code HollowLordCombatHandler}, which reads/feeds this entity.
 */
public class HollowLordEntity extends class_1307 {

    private int spawnInvuln = 0;
    private boolean dying = false;
    private int currentPhase = 1;
    private int phaseInvuln = 0; // brief invuln on phase transitions

    private final class_3213 bossBar = new class_3213(
        class_2561.method_43470("The Hollow Lord").method_27695(class_124.field_1064, class_124.field_1067),
        class_1259.class_1260.field_5783, class_1259.class_1261.field_5795);

    public HollowLordEntity(class_1299<? extends class_1307> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 20, true);
        this.bossBar.method_5406(true);
        this.bossBar.method_5411(true);
        this.field_6194 = 200;
    }

    public static class_5132.class_5133 createHollowLordAttributes() {
        return class_1308.method_26828()
            .method_26868(class_5134.field_23716, 300.0)
            .method_26868(class_5134.field_23717, 80.0)
            .method_26868(class_5134.field_23719, 0.6)
            .method_26868(class_5134.field_23720, 1.2)
            .method_26868(class_5134.field_23721, 12.0)
            .method_26868(class_5134.field_23724, 8.0)
            .method_26868(class_5134.field_23718, 1.0);
    }

    @Override
    protected void method_5959() {
        // A simple circling/approach goal so the Lord orbits and closes on the
        // nearest player. Attacks themselves are driven by the combat handler.
        this.field_6201.method_6277(1, new HoverNearTargetGoal(this));
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6332(false);
        nav.method_6331(false);
        nav.method_6354(false);
        return nav;
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!this.method_37908().field_9236 && spawnInvuln > 0) {
            spawnInvuln--;
        }
    }

    // No gravity while flying.
    @Override
    public boolean method_5740() {
        return true;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    protected void method_5958() {
        super.method_5958();
        if (this.method_37908() instanceof class_3218 sw) {
            this.bossBar.method_5408(Math.max(0f, this.method_6032() / this.method_6063()));

            if (phaseInvuln > 0) phaseInvuln--;

            // Phase detection by HP fraction: 1 (100-75%), 2 (75-50%), 3 (50-25%), 4 (<25%).
            float frac = this.method_6032() / this.method_6063();
            int newPhase = frac > 0.75f ? 1 : frac > 0.50f ? 2 : frac > 0.25f ? 3 : 4;
            if (newPhase > currentPhase && !dying) {
                enterPhase(sw, newPhase);
            }

            if (this.field_6012 % 20 == 0) {
                java.util.Set<class_3222> nearby = new java.util.HashSet<>();
                for (class_3222 p : sw.method_18456()) {
                    if (p.method_5858(this) < 128 * 128) nearby.add(p);
                }
                for (class_3222 p : new java.util.ArrayList<>(bossBar.method_14092())) {
                    if (!nearby.contains(p)) bossBar.method_14089(p);
                }
                for (class_3222 p : nearby) bossBar.method_14088(p);
            }
        }
    }

    /** Transition into a new, harder phase: brief invuln, roar, flash, retitle. */
    private void enterPhase(class_3218 sw, int phase) {
        currentPhase = phase;
        phaseInvuln = 40; // 2s of mercy so the transition reads clearly

        String name = switch (phase) {
            case 2 -> "The Hollow Lord — The Hollowing";
            case 3 -> "The Hollow Lord — The Devouring";
            case 4 -> "The Hollow Lord — The Last Light";
            default -> "The Hollow Lord";
        };
        this.bossBar.method_5413(net.minecraft.class_2561.method_43470(name)
            .method_27695(class_124.field_1064, class_124.field_1067));
        this.bossBar.method_5416(phase >= 4 ? class_1259.class_1260.field_5784
            : phase == 3 ? class_1259.class_1260.field_5783 : class_1259.class_1260.field_5783);

        // Roar + shockwave flash.
        sw.method_14199(net.minecraft.class_2398.field_38002,
            this.method_23317(), this.method_23318() + 2, this.method_23321(), 120, 3, 3, 3, 0.4);
        sw.method_14199(net.minecraft.class_2398.field_11236,
            this.method_23317(), this.method_23318() + 2, this.method_23321(), 5, 2, 2, 2, 0);
        sw.method_8396(null, this.method_24515(),
            net.minecraft.class_3417.field_14671,
            net.minecraft.class_3419.field_15251, 4.0f, 0.5f);

        for (class_3222 p : sw.method_18456()) {
            if (p.method_5858(this) < 128 * 128) {
                p.method_7353(net.minecraft.class_2561.method_43470(switch (phase) {
                    case 2 -> "The Lord hollows. The air grows thin.";
                    case 3 -> "The Lord hungers. It begins to devour.";
                    case 4 -> "The last light gutters. Nothing is held back now.";
                    default -> "";
                }).method_27695(class_124.field_1064, class_124.field_1056), false);
            }
        }
    }

    public int getPhase() { return currentPhase; }
    public boolean isPhaseInvuln() { return phaseInvuln > 0; }

    public void grantSpawnInvulnerability(int ticks) { this.spawnInvuln = ticks; }
    public int getSpawnInvuln() { return spawnInvuln; }

    public boolean isDying() { return dying; }
    public void setDying(boolean d) { this.dying = d; }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        if (spawnInvuln > 0) return false;
        if (phaseInvuln > 0) return false; // brief mercy on phase transitions
        if (dying) return false; // frozen during the death sequence
        // Immune to drowning/fall/void-less nonsense; takes normal combat damage.
        return super.method_5643(source, amount);
    }

    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        this.bossBar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        this.bossBar.method_14089(player);
    }

    @Override
    public void method_5650(class_5529 reason) {
        this.bossBar.method_14094();
        super.method_5650(reason);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("CdSpawnInvuln", spawnInvuln);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.spawnInvuln = nbt.method_10550("CdSpawnInvuln");
    }

    /**
     * Rich flight AI: the Lord cycles through maneuvers instead of just hovering.
     * It circles the target, makes diving dash attacks, retreats to reposition,
     * and hovers menacingly — picking a new maneuver every few seconds.
     */
    private static class HoverNearTargetGoal extends class_1352 {
        private final HollowLordEntity lord;

        private enum Move { CIRCLE, DASH, RETREAT, HOVER }
        private Move move = Move.HOVER;
        private int moveTicks = 0;
        private double circleAngle = 0;

        HoverNearTargetGoal(HollowLordEntity lord) {
            this.lord = lord;
            this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        }

        @Override public boolean method_6264() { return true; }
        @Override public boolean method_6266() { return true; }

        @Override
        public void method_6268() {
            class_1309 target = lord.method_37908().method_18460(lord, 80);
            if (target == null) {
                // Idle drift upward a little so it doesn't sink.
                lord.method_5962().method_6239(lord.method_23317(), lord.method_23318() + 2, lord.method_23321(), 0.3);
                return;
            }

            lord.method_5988().method_6226(target, 30, 30);

            if (moveTicks > 0) moveTicks--;
            if (moveTicks <= 0) chooseNextMove(target);

            switch (move) {
                case CIRCLE -> doCircle(target);
                case DASH -> doDash(target);
                case RETREAT -> doRetreat(target);
                case HOVER -> doHover(target);
            }
        }

        private void chooseNextMove(class_1309 target) {
            double dist = lord.method_5739(target);
            int roll = lord.method_59922().method_43048(100);
            // Closer → more likely to dash; farther → more likely to circle/approach.
            if (dist > 25) {
                move = (roll < 60) ? Move.CIRCLE : Move.DASH;
                moveTicks = 60;
            } else if (dist < 8) {
                move = (roll < 50) ? Move.RETREAT : Move.HOVER;
                moveTicks = 30;
            } else {
                if (roll < 35) move = Move.DASH;
                else if (roll < 70) move = Move.CIRCLE;
                else if (roll < 85) move = Move.HOVER;
                else move = Move.RETREAT;
                moveTicks = 40 + lord.method_59922().method_43048(40);
            }
        }

        private void doCircle(class_1309 target) {
            circleAngle += 0.08;
            double radius = 14;
            double tx = target.method_23317() + Math.cos(circleAngle) * radius;
            double tz = target.method_23321() + Math.sin(circleAngle) * radius;
            double ty = target.method_23318() + 6 + Math.sin(circleAngle * 2) * 2;
            lord.method_5962().method_6239(tx, ty, tz, 1.0);
        }

        private void doDash(class_1309 target) {
            // Charge straight at the target's position fast.
            double tx = target.method_23317();
            double ty = target.method_23318() + 1;
            double tz = target.method_23321();
            lord.method_5962().method_6239(tx, ty, tz, 2.2);
            // Contact damage when very close.
            if (lord.method_5739(target) < 3.5 && target instanceof net.minecraft.class_1657) {
                target.method_5643(lord.method_37908().method_48963().method_48812(lord), 8.0f);
                class_243 kb = target.method_19538().method_1020(lord.method_19538()).method_1029().method_1021(1.2);
                target.method_5762(kb.field_1352, 0.4, kb.field_1350);
                target.field_6037 = true;
            }
        }

        private void doRetreat(class_1309 target) {
            // Back away and gain altitude to reposition.
            class_243 away = lord.method_19538().method_1020(target.method_19538()).method_1029().method_1021(16);
            lord.method_5962().method_6239(
                lord.method_23317() + away.field_1352, target.method_23318() + 12, lord.method_23321() + away.field_1350, 1.4);
        }

        private void doHover(class_1309 target) {
            // Hold position above and near the target, swaying slightly.
            double tx = target.method_23317();
            double ty = target.method_23318() + 9;
            double tz = target.method_23321();
            lord.method_5962().method_6239(tx, ty, tz, 0.7);
        }
    }
}
