package com.cutedifficult.entity;

import com.cutedifficult.entity.ai.KitsuneAttackGoal;
import com.cutedifficult.entity.ai.KitsuneFleeGoal;
import com.cutedifficult.entity.ai.KitsuneLookAtPlayerGoal;
import com.cutedifficult.entity.ai.KitsuneMeleeGoal;
import com.cutedifficult.entity.ai.KitsuneSitGoal;
import com.cutedifficult.entity.ai.KitsuneWanderGoal;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.FoxPersonality;
import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1376;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_4019;

/**
 * KitsuneEntity. v0.9.4: KitsuneData is now a plain class, NBT and cache
 * logic lives in {@link FoxStorage}. Persistence pattern is unchanged
 * — cache holds the live working copy, NBT is written on save by this
 * class via {@link FoxStorage#toNbt}, read on load via
 * {@link FoxStorage#fromNbt} and pushed back into cache.
 */
public class KitsuneEntity extends class_4019 {

    private static final Random RANDOM = new Random();

    public KitsuneEntity(class_1299<? extends KitsuneEntity> entityType, class_1937 world) {
        super(entityType, world);
    }

    /**
     * Natural-spawn initialization: assign an element from the biome and a
     * weighted tail count (young common, ancient rare). Command/egg spawns set
     * their own data afterward, so we only act on world-driven spawns.
     */
    @Override
    public net.minecraft.class_1315 method_5943(
            net.minecraft.class_5425 world,
            net.minecraft.class_1266 difficulty,
            net.minecraft.class_3730 spawnReason,
            net.minecraft.class_1315 entityData) {
        net.minecraft.class_1315 result =
                super.method_5943(world, difficulty, spawnReason, entityData);

        if (spawnReason == net.minecraft.class_3730.field_16459
                || spawnReason == net.minecraft.class_3730.field_16472
                || spawnReason == net.minecraft.class_3730.field_16469) {
            Random rng = new Random();
            Element element = KitsuneSpawnLogic.elementFor(
                    world.method_23753(this.method_24515()), rng);
            int tails = KitsuneSpawnLogic.rollTails(rng);

            KitsuneData data = KitsuneData.of6(element, FoxPersonality.random(rng), tails, 0, 0L, 0);
            FoxStorage.store(this, data);
            com.cutedifficult.spirit.FoxStats.applyHpForTails(this, tails);
        }
        return result;
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new KitsuneSitGoal(this));
        this.field_6201.method_6277(2, new KitsuneFleeGoal(this));
        this.field_6201.method_6277(3, new KitsuneMeleeGoal(this));
        this.field_6201.method_6277(4, new KitsuneAttackGoal(this));
        this.field_6201.method_6277(5, new KitsuneWanderGoal(this));
        this.field_6201.method_6277(6, new KitsuneLookAtPlayerGoal(this));
        this.field_6201.method_6277(7, new class_1376(this));
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        KitsuneData data = FoxStorage.peekCache(this);
        if (data == null) data = FoxStorage.getOrCreate(this, RANDOM);
        nbt.method_10566(FoxStorage.NBT_KEY, FoxStorage.toNbt(data));
        com.cutedifficult.CuteDifficult.LOGGER.debug(
                "[CuteDifficult] Wrote KitsuneData for {} (element={}, tails={}, trust={})",
                this.method_5667(), data.element, data.tails, data.trustLevel);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        try {
            super.method_5749(nbt);
        } catch (NullPointerException npe) {
            com.cutedifficult.CuteDifficult.LOGGER.debug(
                    "[CuteDifficult] Suppressed NPE from vanilla addTypeSpecificGoals (expected)."
            );
        }
        if (nbt.method_10545(FoxStorage.NBT_KEY)) {
            KitsuneData data = FoxStorage.fromNbt(nbt.method_10562(FoxStorage.NBT_KEY));
            FoxStorage.injectIntoCache(this, data);
            com.cutedifficult.CuteDifficult.LOGGER.debug(
                    "[CuteDifficult] Loaded KitsuneData for {} (element={}, tails={}, trust={})",
                    this.method_5667(), data.element, data.tails, data.trustLevel);
        } else {
            com.cutedifficult.CuteDifficult.LOGGER.debug(
                    "[CuteDifficult] readCustomDataFromNbt: no spirit data found for {} — will regenerate.",
                    this.method_5667());
        }
    }
}