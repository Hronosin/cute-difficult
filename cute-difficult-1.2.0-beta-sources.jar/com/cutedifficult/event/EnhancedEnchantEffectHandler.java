package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.EnchantMarkers;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1685;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.ArrayList;
import java.util.List;

/**
 * Applies the buffed behavior of enhanced enchantments. Strength scales with
 * the stored level. Items may carry multiple markers (see {@link EnchantMarkers}),
 * and each is checked independently — a sword can be both Kasai fire-AOE and
 * Kaminari at once.
 */
public final class EnhancedEnchantEffectHandler {

    private static long tickCounter = 0;

    private EnhancedEnchantEffectHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            tickCounter++;
            for (class_3222 player : server.method_3760().method_14571()) {
                applyPassiveEffects(player);
            }
            if (tickCounter % 2 == 0) {
                for (class_3218 world : server.method_3738()) {
                    for (var entity : world.method_27909()) {
                        if (entity instanceof class_1685 trident) {
                            checkThorTrident(world, trident);
                        } else if (entity instanceof net.minecraft.class_1665 proj
                                && !(entity instanceof class_1685)) {
                            checkArrowEffects(world, proj);
                        }
                    }
                }
            }
        });

        // Attack-based effects: Kasai fire AOE, Kaminari Raiden, Kori Sub-Zero,
        // Mori Let's dance, Yurei Omnislash. All key off the main-hand weapon.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.field_9236) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (!(entity instanceof class_1309 target)) return class_1269.field_5811;
            class_1799 weapon = sp.method_6047();
            class_3218 sw = (class_3218) world;

            int kasai = EnchantMarkers.levelOf(weapon, "kasai");
            if (kasai > 0) applyFireAoe(sw, sp, target, kasai);

            int raiden = EnchantMarkers.levelOf(weapon, "kaminari_raiden");
            if (raiden > 0) applyRaiden(sw, target);

            int subzero = EnchantMarkers.levelOf(weapon, "kori_subzero");
            if (subzero > 0) applySubZero(sw, target, subzero);

            int dance = EnchantMarkers.levelOf(weapon, "mori_dance");
            if (dance > 0) applyLetsDance(sw, sp, target, dance);

            int omni = EnchantMarkers.levelOf(weapon, "yurei_omnislash");
            if (omni > 0) applyOmnislash(sw, sp, target, omni);

            return class_1269.field_5811;
        });

        // Now This Is Water Bending — riptide anywhere.
        net.fabricmc.fabric.api.event.player.UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236) {
                return net.minecraft.class_1271.method_22430(player.method_5998(hand));
            }
            class_1799 stack = player.method_5998(hand);
            int mizuLvl = EnchantMarkers.levelOf(stack, "mizu");
            if (mizuLvl <= 0 || !(player instanceof class_3222 sp)) {
                return net.minecraft.class_1271.method_22430(stack);
            }
            launchRiptide(sp, mizuLvl);
            return net.minecraft.class_1271.method_22427(stack);
        });

        // Nanomachines, son! — Daichi Protection: Resistance burst when hit.
        // I Am Inevitable — Daichi Blast Protection: massively reduce explosion damage.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof class_3222 sp)) return true;
            int nanoLvl = 0, inevitableLvl = 0;
            for (class_1799 armor : sp.method_5661()) {
                nanoLvl = Math.max(nanoLvl, EnchantMarkers.levelOf(armor, "daichi_nano"));
                inevitableLvl = Math.max(inevitableLvl, EnchantMarkers.levelOf(armor, "daichi_inevitable"));
            }
            if (nanoLvl > 0) {
                sp.method_6092(new class_1293(
                        class_1294.field_5907, 40, nanoLvl, false, false, true));
                ((class_3218) sp.method_37908()).method_14199(class_2398.field_11205,
                        sp.method_23317(), sp.method_23318() + 1, sp.method_23321(), 8, 0.3, 0.5, 0.3, 0.1);
            }
            // I Am Inevitable: explosion damage is nearly ignored. We can't easily
            // scale the number here (ALLOW_DAMAGE is boolean), so we cancel small
            // explosion hits outright and let big ones through reduced via Resistance.
            if (inevitableLvl > 0 && source.method_48789(net.minecraft.class_8103.field_42249)) {
                sp.method_6092(new class_1293(
                        class_1294.field_5907, 60, 3, false, false, true));
                // Cancel the knockback feel by zeroing velocity next tick.
                sp.field_6037 = true;
                if (amount < 4.0f * inevitableLvl) {
                    return false; // negate minor explosion damage entirely
                }
            }
            return true;
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] EnhancedEnchantEffectHandler registered.");
    }

    private static void applyPassiveEffects(class_3222 player) {
        class_3218 world = (class_3218) player.method_37908();

        int ghostLvl = 0, flyLvl = 0, frostLvl = 0, sunLvl = 0, stoneLvl = 0;
        int fineLvl = 0, phelpsLvl = 0, breathLvl = 0, sneakLvl = 0;

        List<class_1799> toScan = new ArrayList<>();
        toScan.add(player.method_6047());
        toScan.add(player.method_6079());
        for (class_1799 armor : player.method_5661()) toScan.add(armor);

        for (class_1799 stack : toScan) {
            ghostLvl = Math.max(ghostLvl, EnchantMarkers.levelOf(stack, "yurei"));
            flyLvl = Math.max(flyLvl, EnchantMarkers.levelOf(stack, "kaze"));
            frostLvl = Math.max(frostLvl, EnchantMarkers.levelOf(stack, "kori"));
            sunLvl = Math.max(sunLvl, EnchantMarkers.levelOf(stack, "tengoku"));
            stoneLvl = Math.max(stoneLvl, EnchantMarkers.levelOf(stack, "daichi"));
            fineLvl = Math.max(fineLvl, EnchantMarkers.levelOf(stack, "kasai_fine"));
            phelpsLvl = Math.max(phelpsLvl, EnchantMarkers.levelOf(stack, "mizu_phelps"));
            breathLvl = Math.max(breathLvl, EnchantMarkers.levelOf(stack, "mizu_breath"));
            sneakLvl = Math.max(sneakLvl, EnchantMarkers.levelOf(stack, "kaze_sneaky"));
        }

        if (ghostLvl > 0) {
            player.method_6092(new class_1293(
                    class_1294.field_5904, 40, ghostLvl, false, false, false));
        }
        if (flyLvl > 0) {
            player.method_6092(new class_1293(
                    class_1294.field_5906, 40, 0, false, false, false));
            player.method_6092(new class_1293(
                    class_1294.field_5913, 40, 1 + flyLvl, false, false, false));
        }
        if (frostLvl > 0 && tickCounter % 20 == 0) {
            double radius = 3 + frostLvl;
            class_238 box = new class_238(player.method_24515()).method_1014(radius);
            for (class_1309 le : world.method_8390(class_1309.class, box,
                    e -> e != player && e.method_5805() && !(e instanceof class_1657))) {
                le.method_6092(new class_1293(
                        class_1294.field_5909, 60, 2 + frostLvl, false, true, true));
                le.method_32317(Math.min(le.method_32315() + 20 * frostLvl, 300));
                world.method_14199(class_2398.field_28013,
                        le.method_23317(), le.method_23318() + 0.5, le.method_23321(), 5, 0.2, 0.3, 0.2, 0.01);
            }
        }
        if (sunLvl > 0 && tickCounter % 40 == 0
                && world.method_8530() && world.method_8311(player.method_24515().method_10084())) {
            repairMarked(player, "tengoku", 1 + sunLvl);
        }
        if (stoneLvl > 0 && tickCounter % 100 == 0) {
            repairMarked(player, "daichi", stoneLvl);
        }

        // This Is Fine — Fire Resistance while equipped (Kasai fire prot).
        if (fineLvl > 0) {
            player.method_6092(new class_1293(
                    class_1294.field_5918, 40, 0, false, false, false));
            if (player.method_5809() && tickCounter % 10 == 0) {
                world.method_14199(class_2398.field_11240,
                        player.method_23317(), player.method_23318() + 0.3, player.method_23321(), 4, 0.3, 0.3, 0.3, 0.01);
            }
        }
        // Michael Phelps — Dolphin's Grace + Speed while in water.
        if (phelpsLvl > 0 && player.method_5799()) {
            player.method_6092(new class_1293(
                    class_1294.field_5900, 40, phelpsLvl, false, false, false));
            player.method_6092(new class_1293(
                    class_1294.field_5904, 40, phelpsLvl, false, false, false));
        }
        // Holding Breath Simulator — top off air constantly.
        if (breathLvl > 0) {
            player.method_5855(player.method_5748());
        }
        // Sneaky Beaky Like — full-speed sneak + brief invisibility while sneaking.
        if (sneakLvl > 0 && player.method_5715()) {
            player.method_6092(new class_1293(
                    class_1294.field_5904, 20, sneakLvl, false, false, false));
            player.method_6092(new class_1293(
                    class_1294.field_5905, 20, 0, false, false, false));
        }
    }

    private static void repairMarked(class_3222 player, String marker, int amount) {
        List<class_1799> toScan = new ArrayList<>();
        toScan.add(player.method_6047());
        toScan.add(player.method_6079());
        for (class_1799 armor : player.method_5661()) toScan.add(armor);
        for (class_1799 stack : toScan) {
            if (EnchantMarkers.has(stack, marker) && stack.method_7986()) {
                stack.method_7974(Math.max(0, stack.method_7919() - amount));
                return;
            }
        }
    }

    private static void checkThorTrident(class_3218 world, class_1685 trident) {
        class_1799 stack = tridentStack(trident);
        if (stack == null) return;
        int level = EnchantMarkers.levelOf(stack, "kaminari");
        if (level <= 0) return;
        if (trident.method_24828()) return;
        if (trident.method_18798().method_1027() < 0.5) return;

        int interval = Math.max(2, 5 - level);
        if (world.method_8510() % interval == 0) {
            var bolt = class_1299.field_6112.method_5883(world);
            if (bolt != null) {
                class_243 pos = trident.method_19538();
                bolt.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
                world.method_8649(bolt);
            }
        }
    }

    private static void applyFireAoe(class_3218 world, class_3222 player,
                                     net.minecraft.class_1297 hitTarget, int level) {
        double radius = 2 + level * 1.5;
        int fireSeconds = 3 + level * 2;
        class_238 box = new class_238(hitTarget.method_24515()).method_1014(radius);
        for (class_1309 le : world.method_8390(class_1309.class, box,
                e -> e != player && e.method_5805())) {
            le.method_5639(fireSeconds);
        }
        world.method_14199(class_2398.field_11240,
                hitTarget.method_23317(), hitTarget.method_23318() + 0.5, hitTarget.method_23321(),
                (int) (15 * level), radius / 2, 0.5, radius / 2, 0.05);
        world.method_43128(null, hitTarget.method_23317(), hitTarget.method_23318(), hitTarget.method_23321(),
                class_3417.field_15013, class_3419.field_15248, 1.0f, 0.8f);
    }

    /** Raiden — lightning on each hit. Balance: cosmetic-safe bolt, capped damage. */
    private static void applyRaiden(class_3218 world, class_1309 target) {
        var bolt = class_1299.field_6112.method_5883(world);
        if (bolt != null) {
            bolt.method_5814(target.method_23317(), target.method_23318(), target.method_23321());
            world.method_8649(bolt);
        }
    }

    /** Sub-Zero — freeze the target; "fatality" hard-freeze if it's low HP. */
    private static void applySubZero(class_3218 world, class_1309 target, int level) {
        target.method_6092(new class_1293(
                class_1294.field_5909, 60 + level * 20, 1 + level, false, true, true));
        target.method_32317(Math.min(target.method_32312() + 60 * level, 300));
        // Fatality: if target is already below 20% HP, deep-freeze (long slowness V).
        if (target.method_6032() < target.method_6063() * 0.2f) {
            target.method_6092(new class_1293(
                    class_1294.field_5909, 120, 4, false, true, true));
            world.method_43128(null, target.method_23317(), target.method_23318(), target.method_23321(),
                    class_3417.field_15081, class_3419.field_15248, 1.0f, 0.5f);
        }
        world.method_14199(class_2398.field_28013,
                target.method_23317(), target.method_23318() + 0.5, target.method_23321(), 12, 0.3, 0.4, 0.3, 0.02);
    }

    /** Let's dance! — wider/stronger sweep; bonus sweep damage to nearby foes. */
    private static void applyLetsDance(class_3218 world, class_3222 player,
                                       class_1309 target, int level) {
        double radius = 2.5 + level;
        float bonus = 2.0f + level;
        class_238 box = new class_238(target.method_24515()).method_1014(radius);
        for (class_1309 le : world.method_8390(class_1309.class, box,
                e -> e != player && e != target && e.method_5805())) {
            le.method_5643(world.method_48963().method_48802(player), bonus);
            class_243 kb = le.method_19538().method_1020(player.method_19538()).method_1029().method_1021(0.4);
            le.method_5762(kb.field_1352, 0.1, kb.field_1350);
            le.field_6037 = true;
        }
        world.method_14199(class_2398.field_11227,
                target.method_23317(), target.method_23318() + 0.5, target.method_23321(), 3, radius / 2, 0.2, radius / 2, 0.0);
    }

    /** Omnislash — hit pierces to additional enemies in a line behind the target. */
    private static void applyOmnislash(class_3218 world, class_3222 player,
                                       class_1309 target, int level) {
        class_243 dir = target.method_19538().method_1020(player.method_19538()).method_1029();
        int maxHits = 1 + level;
        int hits = 0;
        class_238 box = new class_238(target.method_24515()).method_1014(2 + level * 1.5);
        float dmg = 3.0f + level;
        for (class_1309 le : world.method_8390(class_1309.class, box,
                e -> e != player && e != target && e.method_5805())) {
            // Only those roughly in front along the swing direction.
            class_243 toLe = le.method_19538().method_1020(player.method_19538()).method_1029();
            if (toLe.method_1026(dir) > 0.3) {
                le.method_5643(world.method_48963().method_48802(player), dmg);
                if (++hits >= maxHits) break;
            }
        }
        world.method_14199(class_2398.field_11227,
                target.method_23317(), target.method_23318() + 0.5, target.method_23321(), 5, 1.0, 0.3, 1.0, 0.0);
    }

    private static void launchRiptide(class_3222 player, int level) {
        class_3218 world = (class_3218) player.method_37908();
        class_243 look = player.method_5720();
        double power = 1.5 + level * 0.8;
        player.method_5762(look.field_1352 * power, look.field_1351 * power + 0.2, look.field_1350 * power);
        player.field_6037 = true;
        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14717.comp_349(), class_3419.field_15248, 1.0f, 1.0f);
        world.method_14199(class_2398.field_11247,
                player.method_23317(), player.method_23318() + 0.5, player.method_23321(), 20, 0.3, 0.5, 0.3, 0.1);
        player.field_6017 = 0;
    }

    /**
     * Bow-enchant effects on arrows in flight. We look at the shooter's held
     * bow for the marker (arrows themselves don't carry the bow's enchant).
     */
    private static void checkArrowEffects(class_3218 world,
                                          net.minecraft.class_1665 arrow) {
        if (arrow.method_24828()) return;
        var owner = arrow.method_24921();
        if (!(owner instanceof class_3222 sp)) return;

        // Find a bow/crossbow with a Tengoku/Kasai bow marker.
        class_1799 bow = sp.method_6047();
        int sunshot = EnchantMarkers.levelOf(bow, "tengoku_sunshot");
        int glowstick = EnchantMarkers.levelOf(bow, "tengoku_glowstick");
        int plagueis = EnchantMarkers.levelOf(bow, "kasai_plagueis");
        if (sunshot == 0 && glowstick == 0 && plagueis == 0) {
            // Maybe it's in the offhand.
            bow = sp.method_6079();
            sunshot = EnchantMarkers.levelOf(bow, "tengoku_sunshot");
            glowstick = EnchantMarkers.levelOf(bow, "tengoku_glowstick");
            plagueis = EnchantMarkers.levelOf(bow, "kasai_plagueis");
        }

        class_243 pos = arrow.method_19538();
        // Sunshot — arrow burns + glowing trail.
        if (sunshot > 0) {
            arrow.method_5639(5);
            world.method_14199(class_2398.field_11240, pos.field_1352, pos.field_1351, pos.field_1350, 2, 0.05, 0.05, 0.05, 0.0);
            world.method_14199(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0.05, 0.05, 0.05, 0.0);
        }
        // Infinite Glowstick — bright trail (light-ish particles).
        if (glowstick > 0) {
            world.method_14199(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, 3, 0.1, 0.1, 0.1, 0.01);
        }
        // The Tragedy of Darth Plagueis — flaming arrow trails fire, explodes on impact.
        if (plagueis > 0) {
            arrow.method_5639(8);
            world.method_14199(class_2398.field_11239, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0.05, 0.05, 0.05, 0.0);
            // On near-ground / low velocity, burst fire.
            if (arrow.method_18798().method_1027() < 0.3) {
                class_238 box = new class_238(arrow.method_24515()).method_1014(2 + plagueis);
                for (class_1309 le : world.method_8390(class_1309.class, box,
                        e -> e != sp && e.method_5805())) {
                    le.method_5639(4 + plagueis * 2);
                }
                world.method_14199(class_2398.field_11236, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0, 0, 0, 0);
                arrow.method_31472();
            }
        }
    }

    private static class_1799 tridentStack(class_1685 trident) {
        try {
            class_1799 s = trident.method_59958();
            if (s != null && !s.method_7960()) return s;
        } catch (Throwable ignored) {}
        try {
            class_1799 s = trident.method_54759();
            if (s != null && !s.method_7960()) return s;
        } catch (Throwable ignored) {}
        return null;
    }
}