package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.entity.HollowLordEntity;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1538;
import net.minecraft.class_1674;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Combat AI for the (now custom, FlyingEntity-based) Hollow Lord. The boss bar
 * is owned by the entity; this handler only drives attacks on cooldowns. On
 * death it opens the End exit portal and drops a reward.
 */
public final class HollowLordCombatHandler {

    private static final Random RANDOM = new Random();
    private static final double BATTLE_RADIUS = 64.0;

    private static final Map<UUID, int[]> COOLDOWNS = new ConcurrentHashMap<>();
    // Active death sequences, ticked each server tick.
    private static final java.util.List<HollowLordDeathSequence> SEQUENCES =
        new java.util.concurrent.CopyOnWriteArrayList<>();
    private static final java.util.List<PendingLaser> PENDING_LASERS =
        new java.util.concurrent.CopyOnWriteArrayList<>();
    private static final java.util.List<PendingStrike> PENDING_STRIKES =
        new java.util.concurrent.CopyOnWriteArrayList<>();
    // cooldown indices
    private static final int FIREBALL = 0, BREATH = 1, CURSE = 2, LASER = 3, LIGHTNING = 4;

    private HollowLordCombatHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            // Advance any active death sequences.
            if (!SEQUENCES.isEmpty()) {
                for (HollowLordDeathSequence seq : SEQUENCES) {
                    seq.tick();
                    if (seq.isFinished()) SEQUENCES.remove(seq);
                }
            }
            // Advance telegraphed lasers and lightning strikes.
            for (PendingLaser pl : PENDING_LASERS) {
                pl.tick();
                if (pl.done) PENDING_LASERS.remove(pl);
            }
            for (PendingStrike ps : PENDING_STRIKES) {
                ps.tick();
                if (ps.done) PENDING_STRIKES.remove(ps);
            }

            for (class_3218 world : server.method_3738()) {
                for (var entity : world.method_27909()) {
                    if (!(entity instanceof HollowLordEntity lord) || !lord.method_5805()) continue;

                    // Scripted death: once HP drops low, freeze the Lord and play
                    // the cinematic sequence (rather than relying on AFTER_DEATH,
                    // where the entity is already gone and timing breaks).
                    if (!lord.isDying() && lord.method_6032() <= 10.0f) {
                        startScriptedDeath(world, lord);
                        continue;
                    }
                    if (lord.isDying()) continue; // frozen; sequence handles it

                    if (lord.getSpawnInvuln() > 0) continue;
                    tickCombat(world, lord);
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] HollowLordCombatHandler registered.");
    }

    /** Begin the scripted death: freeze the Lord, lift it to centre, start the
     *  cinematic sequence. The sequence removes the Lord when it finishes. */
    private static void startScriptedDeath(class_3218 world, HollowLordEntity lord) {
        COOLDOWNS.remove(lord.method_5667());
        lord.setDying(true);
        lord.method_6033(1.0f);              // keep it alive but pinned
        lord.method_5875(true);
        lord.method_18800(0, 0, 0);
        lord.field_6037 = true;
        // Teleport to the arena centre, lifted, for the animation.
        lord.method_5859(0.5, 70, 0.5);
        SEQUENCES.add(new HollowLordDeathSequence(world, lord, new class_243(0.5, 70, 0.5)));
        CuteDifficult.LOGGER.info("[CuteDifficult] Hollow Lord scripted death started.");
    }

    private static void tickCombat(class_3218 world, HollowLordEntity lord) {
        int[] cd = COOLDOWNS.computeIfAbsent(lord.method_5667(), u -> new int[]{40, 80, 120, 160, 200});
        for (int i = 0; i < cd.length; i++) if (cd[i] > 0) cd[i]--;

        class_3222 target = nearestTarget(world, lord);
        if (target == null) return;

        class_243 origin = lord.method_19538().method_1031(0, lord.method_17682() * 0.5, 0);
        class_243 toTarget = target.method_19538().method_1031(0, target.method_17682() / 2, 0).method_1020(origin);
        double dist = toTarget.method_1033();
        class_243 dir = toTarget.method_1029();

        if (cd[FIREBALL] <= 0) {
            launchFireball(world, lord, origin, dir);
            cd[FIREBALL] = 60 + RANDOM.nextInt(20);
        }
        if (cd[BREATH] <= 0 && dist < 30) {
            fireBreath(world, lord, origin, dir, target);
            cd[BREATH] = 100 + RANDOM.nextInt(40);
        }
        if (cd[CURSE] <= 0) {
            hollowCurse(world, target);
            cd[CURSE] = 140 + RANDOM.nextInt(60);
        }

        int phase = lord.getPhase();

        // Phase 2+: telegraphed laser. We "aim" for a moment (shows the line),
        // then fire — giving the player time to break line of sight or dodge.
        if (phase >= 2 && cd[LASER] <= 0) {
            beginLaser(world, lord, origin, target);
            cd[LASER] = 120 + RANDOM.nextInt(40);
        }

        // Phase 2+: area lightning. Telegraphed strike markers appear, then
        // lightning falls a moment later at those spots.
        if (phase >= 2 && cd[LIGHTNING] <= 0) {
            beginLightning(world, target);
            cd[LIGHTNING] = 160 + RANDOM.nextInt(60);
        }

        // Crystal turrets fire at the player every so often (phase-independent,
        // but only the crystals that still exist).
        if (world.method_8510() % 40 == 0) {
            crystalTurretsFire(world, target);
        }
    }

    // ===== Telegraphed laser =====

    /** Aim a laser at the target: draw the beam path as a warning for ~1s, then
     *  schedule the damaging strike. Implemented as a short scheduled task via a
     *  pending-laser list ticked alongside combat. */
    private static void beginLaser(class_3218 world, HollowLordEntity lord, class_243 origin, class_3222 target) {
        class_243 aim = target.method_19538().method_1031(0, target.method_17682() / 2, 0);
        PENDING_LASERS.add(new PendingLaser(world, lord, origin, aim, 25));
        world.method_8396(null, lord.method_24515(),
            class_3417.field_14703, class_3419.field_15251, 2.0f, 1.6f);
    }

    // ===== Telegraphed lightning =====

    private static void beginLightning(class_3218 world, class_3222 target) {
        // Mark 3 spots around the target; lightning falls after a telegraph.
        for (int i = 0; i < 3; i++) {
            double ox = (RANDOM.nextDouble() - 0.5) * 8;
            double oz = (RANDOM.nextDouble() - 0.5) * 8;
            class_2338 spot = class_2338.method_49637(target.method_23317() + ox, target.method_23318(), target.method_23321() + oz);
            PENDING_STRIKES.add(new PendingStrike(world, spot, 30));
        }
    }

    // ===== Crystal turrets =====

    private static void crystalTurretsFire(class_3218 world, class_3222 target) {
        var crystals = world.method_8390(
            net.minecraft.class_1511.class,
            target.method_5829().method_1014(80), c -> true);
        for (var crystal : crystals) {
            class_243 from = crystal.method_19538().method_1031(0, 1, 0);
            class_243 to = target.method_19538().method_1031(0, target.method_17682() / 2, 0);
            class_243 dir = to.method_1020(from).method_1029();
            // Small fireball turret shot. Owner = the crystal (a LivingEntity is
            // not required for SmallFireball's velocity-only constructor path,
            // but the proven ctor takes an owner; use the target's nearest Lord
            // is overkill — pass null-safe via the (world, x,y,z, vx,vy,vz) ctor).
            net.minecraft.class_1677 shot =
                new net.minecraft.class_1677(world,
                    from.field_1352, from.field_1351, from.field_1350, dir);
            world.method_8649(shot);
            world.method_14199(net.minecraft.class_2398.field_11207,
                from.field_1352, from.field_1351, from.field_1350, 5, 0.2, 0.2, 0.2, 0.02);
        }
    }

    private static class_3222 nearestTarget(class_3218 world, HollowLordEntity lord) {
        class_3222 best = null;
        double bestSq = BATTLE_RADIUS * BATTLE_RADIUS;
        for (class_3222 p : world.method_18456()) {
            if (p.method_7325() || p.method_7337()) continue;
            if (!p.method_5805() || p.method_29504()) continue;
            double d = p.method_5858(lord);
            if (d < bestSq) { bestSq = d; best = p; }
        }
        return best;
    }

    private static void launchFireball(class_3218 world, HollowLordEntity lord, class_243 origin, class_243 dir) {
        class_1674 fb = new class_1674(world, lord, dir.method_1021(0.1), 2);
        fb.method_5814(origin.field_1352 + dir.field_1352 * 3, origin.field_1351 + dir.field_1351 * 3, origin.field_1350 + dir.field_1350 * 3);
        world.method_8649(fb);
        world.method_8396(null, lord.method_24515(),
            class_3417.field_15231, class_3419.field_15251, 3.0f, 0.6f);
    }

    private static void fireBreath(class_3218 world, HollowLordEntity lord, class_243 origin, class_243 dir,
                                   class_3222 target) {
        for (double d = 1; d < 25; d += 0.6) {
            class_243 p = origin.method_1019(dir.method_1021(d));
            double spread = d * 0.06;
            world.method_14199(class_2398.field_11240, p.field_1352, p.field_1351, p.field_1350, 3, spread, spread, spread, 0.02);
            world.method_14199(class_2398.field_11237, p.field_1352, p.field_1351, p.field_1350, 1, spread, spread, spread, 0.0);
        }
        class_243 toT = target.method_19538().method_1031(0, target.method_17682() / 2, 0).method_1020(origin).method_1029();
        if (toT.method_1026(dir) > 0.85) {
            target.method_5639(5);
            target.method_5643(world.method_48963().method_48812(lord), 6.0f);
        }
        world.method_8396(null, lord.method_24515(),
            class_3417.field_14970, class_3419.field_15251, 3.0f, 0.5f);
    }

    private static void hollowCurse(class_3218 world, class_3222 target) {
        class_1293 effect = switch (RANDOM.nextInt(4)) {
            case 0 -> new class_1293(class_1294.field_5920, 100, 0, false, true, true);
            case 1 -> new class_1293(class_1294.field_5899, 120, 0, false, true, true);
            case 2 -> new class_1293(class_1294.field_5909, 160, 1, false, true, true);
            default -> new class_1293(class_1294.field_5919, 100, 0, false, true, true);
        };
        target.method_6092(effect);
        world.method_14199(class_2398.field_38002,
            target.method_23317(), target.method_23318() + 1, target.method_23321(), 12, 0.4, 0.6, 0.4, 0.05);
        world.method_8396(null, target.method_24515(),
            class_3417.field_15203, class_3419.field_15251, 1.5f, 0.8f);
    }

    /**
     * A telegraphed laser: for {@code warn} ticks it draws a thin beam line as a
     * warning (no damage), then on the final tick it fires — damaging only if
     * the player is still on the line. Lets the player dodge / break LoS.
     */
    private static final class PendingLaser {
        final class_3218 world;
        final HollowLordEntity lord;
        final class_243 origin;
        final class_243 aim;
        int warn;
        boolean done = false;

        PendingLaser(class_3218 world, HollowLordEntity lord, class_243 origin, class_243 aim, int warn) {
            this.world = world; this.lord = lord; this.origin = origin; this.aim = aim; this.warn = warn;
        }

        void tick() {
            if (!lord.method_5805()) { done = true; return; }
            class_243 dir = aim.method_1020(origin).method_1029();
            for (double d = 1; d < 40; d += 0.8) {
                class_243 p = origin.method_1019(dir.method_1021(d));
                world.method_14199(net.minecraft.class_2398.field_29644,
                    p.field_1352, p.field_1351, p.field_1350, 1, 0, 0, 0, 0.0);
            }
            warn--;
            if (warn <= 0) {
                fire(dir);
                done = true;
            }
        }

        private void fire(class_243 dir) {
            for (double d = 1; d < 40; d += 0.5) {
                class_243 p = origin.method_1019(dir.method_1021(d));
                world.method_14199(net.minecraft.class_2398.field_22246,
                    p.field_1352, p.field_1351, p.field_1350, 3, 0.1, 0.1, 0.1, 0.02);
            }
            for (class_3222 pl : world.method_18456()) {
                if (pl.method_7337() || pl.method_7325()) continue;
                class_243 toPlayer = pl.method_19538().method_1031(0, pl.method_17682() / 2, 0).method_1020(origin);
                double along = toPlayer.method_1026(dir);
                if (along < 0 || along > 40) continue;
                class_243 closest = origin.method_1019(dir.method_1021(along));
                double perp = pl.method_19538().method_1031(0, pl.method_17682() / 2, 0).method_1022(closest);
                if (perp < 2.0) {
                    pl.method_5643(world.method_48963().method_48831(), 10.0f);
                }
            }
            world.method_8396(null, class_2338.method_49638(origin),
                class_3417.field_38830, class_3419.field_15251, 2.0f, 0.9f);
        }
    }

    /**
     * A telegraphed lightning strike: shows particle markers at the spot for
     * {@code warn} ticks, then summons a lightning bolt — dodgeable by leaving.
     */
    private static final class PendingStrike {
        final class_3218 world;
        final class_2338 pos;
        int warn;
        boolean done = false;

        PendingStrike(class_3218 world, class_2338 pos, int warn) {
            this.world = world; this.pos = pos; this.warn = warn;
        }

        void tick() {
            world.method_14199(net.minecraft.class_2398.field_29644,
                pos.method_10263() + 0.5, pos.method_10264() + 0.2, pos.method_10260() + 0.5, 6, 0.6, 0.1, 0.6, 0.0);
            warn--;
            if (warn <= 0) {
                var bolt = net.minecraft.class_1299.field_6112.method_5883(world);
                if (bolt != null) {
                    bolt.method_24203(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
                    world.method_8649(bolt);
                }
                done = true;
            }
        }
    }

}
