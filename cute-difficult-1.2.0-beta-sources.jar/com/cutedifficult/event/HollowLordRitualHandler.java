package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.entity.HollowLordEntity;
import com.cutedifficult.entity.ModEntities;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1510;
import net.minecraft.class_1542;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4969;

/**
 * Summoning ritual for the Hollow Lord.
 *
 * <p>In the End, near the central exit portal, the player sets up at least
 * {@link #REQUIRED_ANCHORS} <b>fully-charged Respawn Anchors</b> (which do
 * nothing on their own in the End — so no vanilla dragon spawns) and drops a
 * Nether Star. The star is consumed, a black hole forms ~10 blocks above the
 * portal, collapses into a singularity over {@link #ANIM_TICKS} ticks, and the
 * Hollow Lord rises from it.
 */
public final class HollowLordRitualHandler {

    private static final int REQUIRED_ANCHORS = 4;
    private static final int ANIM_TICKS = 100; // 5 seconds of black-hole animation
    private static final class_2338 SINGULARITY = new class_2338(0, 73, 0); // ~10 above portal

    private static long tick = 0;
    private static int animTicksLeft = 0; // >0 while the black hole is forming
    private static final java.util.List<class_2338> ritualAnchors = new java.util.ArrayList<>();

    private HollowLordRitualHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            class_3218 end = server.method_3847(class_1937.field_25181);
            if (end == null) return;

            if (animTicksLeft > 0) {
                tickAnimation(end);
                animTicksLeft--;
                if (animTicksLeft == 0) summon(end);
                return;
            }

            if (tick % 10 == 0) scanForRitual(end);
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] HollowLordRitualHandler registered.");
    }

    private static void scanForRitual(class_3218 end) {
        class_238 centre = new class_238(-8, 50, -8, 8, 90, 8);
        var stars = end.method_8390(class_1542.class, centre,
            ie -> ie.method_6983().method_31574(class_1802.field_8137));
        if (stars.isEmpty()) return;

        // Don't summon if a dragon is already present.
        class_238 wide = new class_238(-64, 0, -64, 64, 128, 64);
        if (!end.method_8390(class_1510.class, wide, e -> true).isEmpty()) return;

        // Require fully-charged respawn anchors near the centre. These do
        // nothing vanilla in the End, so no ordinary dragon is triggered.
        java.util.List<class_2338> anchors = findChargedAnchors(end);
        if (anchors.size() < REQUIRED_ANCHORS) return;

        // Ritual met — consume one star, remember the anchors, begin animation.
        class_1542 star = stars.get(0);
        star.method_6983().method_7934(1);
        if (star.method_6983().method_7960()) star.method_31472();

        ritualAnchors.clear();
        ritualAnchors.addAll(anchors);

        animTicksLeft = ANIM_TICKS;
        end.method_8396(null, SINGULARITY,
            class_3417.field_14703, class_3419.field_15251, 4.0f, 0.3f);
        for (var player : end.method_8503().method_3760().method_14571()) {
            player.method_7353(class_2561.method_43470("The star is devoured. Something tears open above the portal...")
                .method_27695(class_124.field_1064, class_124.field_1056), false);
        }
    }

    /** Find fully-charged respawn anchors (charge == max) near the centre. */
    private static java.util.List<class_2338> findChargedAnchors(class_3218 end) {
        java.util.List<class_2338> found = new java.util.ArrayList<>();
        class_2338.class_2339 cur = new class_2338.class_2339();
        for (int x = -8; x <= 8; x++) {
            for (int y = 50; y <= 80; y++) {
                for (int z = -8; z <= 8; z++) {
                    cur.method_10103(x, y, z);
                    class_2680 st = end.method_8320(cur);
                    if (st.method_27852(class_2246.field_23152)
                        && st.method_11654(class_4969.field_23153) >= class_4969.field_31232) {
                        found.add(cur.method_10062());
                    }
                }
            }
        }
        return found;
    }

    /** Black hole forming: an inward spiral collapsing into a dense singularity. */
    private static void tickAnimation(class_3218 end) {
        double cx = SINGULARITY.method_10263() + 0.5;
        double cy = SINGULARITY.method_10264() + 0.5;
        double cz = SINGULARITY.method_10260() + 0.5;

        // Progress 0..1 as the animation proceeds (0 at start, 1 at collapse).
        double progress = 1.0 - (animTicksLeft / (double) ANIM_TICKS);
        // Radius shrinks as it collapses.
        double radius = 6.0 * (1.0 - progress) + 0.5;

        double phase = tick * 0.4;
        int arms = 24;
        for (int i = 0; i < arms; i++) {
            double t = i / (double) arms;
            double angle = phase + t * Math.PI * 6;
            double sx = cx + Math.cos(angle) * radius;
            double sy = cy + Math.sin(t * Math.PI * 2) * radius * 0.4;
            double sz = cz + Math.sin(angle) * radius;
            class_243 inward = new class_243(cx - sx, cy - sy, cz - sz).method_1029().method_1021(0.15 + progress * 0.2);
            end.method_14199(class_2398.field_11214,
                sx, sy, sz, 0, inward.field_1352, inward.field_1351, inward.field_1350, 1.0);
        }
        // Dark dense core grows as it collapses.
        int coreCount = (int) (4 + progress * 20);
        end.method_14199(class_2398.field_11233, cx, cy, cz, coreCount, 0.3, 0.3, 0.3, 0.0);
        end.method_14199(class_2398.field_23190, cx, cy, cz, (int)(2 + progress * 8),
            0.5, 0.5, 0.5, 0.02);

        // Rising hum.
        if (tick % 10 == 0) {
            float pitch = 0.3f + (float) progress * 0.7f;
            end.method_8396(null, SINGULARITY,
                class_3417.field_14802, class_3419.field_15251, 2.0f, pitch);
        }

        // Shrinking warning rings over each anchor — radius collapses toward
        // detonation, giving players a fair "get clear" cue.
        double ringRadius = 2.5 * (1.0 - progress) + 0.2;
        for (class_2338 anchor : ritualAnchors) {
            double ax = anchor.method_10263() + 0.5;
            double ay = anchor.method_10264() + 1.1;
            double az = anchor.method_10260() + 0.5;
            int pts = 20;
            for (int i = 0; i < pts; i++) {
                double a = (i / (double) pts) * Math.PI * 2;
                double rx = ax + Math.cos(a) * ringRadius;
                double rz = az + Math.sin(a) * ringRadius;
                end.method_14199(class_2398.field_22246, rx, ay, rz, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
    }

    private static void summon(class_3218 end) {
        // Collapse burst.
        double cx = SINGULARITY.method_10263() + 0.5, cy = SINGULARITY.method_10264() + 0.5, cz = SINGULARITY.method_10260() + 0.5;
        end.method_14199(class_2398.field_38002, cx, cy, cz, 200, 1.0, 1.0, 1.0, 0.3);
        end.method_14199(class_2398.field_11221, cx, cy, cz, 1, 0, 0, 0, 0);
        end.method_8396(null, SINGULARITY,
            class_3417.field_14671, class_3419.field_15251, 4.0f, 0.4f);

        HollowLordEntity boss = ModEntities.HOLLOW_LORD.method_5883(end);
        if (boss == null) {
            CuteDifficult.LOGGER.warn("[CuteDifficult] Failed to create Hollow Lord entity.");
            return;
        }
        boss.method_5808(cx, cy, cz, 0, 0);
        boss.grantSpawnInvulnerability(60); // 3 seconds — can't be cheesed on arrival
        end.method_8649(boss);

        // Rebuild the obsidian pillars' End crystals (they heal the boss, like a
        // vanilla respawn) and seal the exit portal so there's no easy escape.
        regenerateCrystals(end);
        sealExitPortal(end);

        // Detonate the anchors — they gave their energy to the Lord.
        for (class_2338 anchor : ritualAnchors) {
            end.method_8650(anchor, false);
            end.method_8537(null,
                anchor.method_10263() + 0.5, anchor.method_10264() + 0.5, anchor.method_10260() + 0.5,
                5.0f, false, class_1937.class_7867.field_40889);
        }
        ritualAnchors.clear();

        for (var player : end.method_8503().method_3760().method_14571()) {
            player.method_7353(class_2561.method_43470("From the hollow between stars, the Lord descends.")
                .method_27695(class_124.field_1064, class_124.field_1067), false);
        }
        CuteDifficult.LOGGER.info("[CuteDifficult] The Hollow Lord has been summoned.");
    }

    /** Place End crystals atop the obsidian pillars, as a vanilla respawn does. */
    private static void regenerateCrystals(class_3218 end) {
        // The ten obsidian pillars sit on a ~43-block-radius ring around (0,0).
        // We approximate by placing crystals on a ring; vanilla snaps them to
        // pillar tops, but a ring of crystals reads correctly and heals the boss.
        int count = 10;
        double radius = 43.0;
        for (int i = 0; i < count; i++) {
            double angle = (i / (double) count) * Math.PI * 2;
            int x = (int) Math.round(Math.cos(angle) * radius);
            int z = (int) Math.round(Math.sin(angle) * radius);
            // Find the pillar top via heightmap.
            class_2338 top = end.method_8598(net.minecraft.class_2902.class_2903.field_13197,
                new class_2338(x, 0, z));
            net.minecraft.class_1511 crystal =
                new net.minecraft.class_1511(end,
                    x + 0.5, top.method_10264() + 1, z + 0.5);
            crystal.method_6839(true);
            end.method_8649(crystal);
        }
    }

    /** Seal the exit portal so non-bedrock portal blocks are deactivated. */
    private static void sealExitPortal(class_3218 end) {
        class_2338.class_2339 cur = new class_2338.class_2339();
        int broken = 0;
        // Search a generous box around the central exit-portal location. The
        // portal blocks sit near y=64 but we scan wide to be safe.
        for (int x = -6; x <= 6; x++) {
            for (int y = 55; y <= 75; y++) {
                for (int z = -6; z <= 6; z++) {
                    cur.method_10103(x, y, z);
                    if (end.method_8320(cur).method_27852(class_2246.field_10027)) {
                        end.method_8501(cur, class_2246.field_10124.method_9564());
                        broken++;
                    }
                }
            }
        }
        com.cutedifficult.CuteDifficult.LOGGER.info(
            "[CuteDifficult] sealExitPortal: removed {} END_PORTAL blocks.", broken);
    }
}
