package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.SpecialMoon;
import com.cutedifficult.spirit.WeatherEvent;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Random;

/**
 * Special weather system. Each day (rolled at dawn) may carry a special
 * {@link WeatherEvent}. Mirrors {@link LunarCycleHandler} in structure.
 *
 * <p>Some events naturally pair with vanilla weather (Acid Rain / Blizzard
 * want rain; Heatwave / Fog want clear), but for simplicity and admin control
 * the event is just a tag that drives effects, and we nudge vanilla weather
 * to match when we set it.
 *
 * <p>Combos: when a special moon and a special weather coincide, a named
 * combo announcement fires and effects stack (handled by both this and the
 * lunar handler running together). See {@link #checkCombo}.
 */
public final class WeatherEventHandler {

    private static final Random RANDOM = new Random();

    private static WeatherEvent active = null;
    private static WeatherEvent forced = null;
    private static boolean forcedClear = false;
    private static boolean announcedToday = false;
    private static long lastCheckedDay = -1;
    private static String lastComboAnnounced = null;

    private static final double SPECIAL_DAY_CHANCE = 0.40;

    private WeatherEventHandler() {}

    public static WeatherEvent getActive() { return active; }

    public static void forceWeather(MinecraftServer server, WeatherEvent w) {
        active = w;
        forced = null;
        forcedClear = false;
        announcedToday = false;
        nudgeVanillaWeather(server, w);
        announce(server);
    }

    public static void clearWeather(MinecraftServer server) {
        active = null;
        forced = null;
        forcedClear = true;
        class_3218 ow = server.method_30002();
        if (ow != null) ow.method_27910(6000, 0, false, false);
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            class_3218 overworld = server.method_30002();
            if (overworld == null) return;

            long timeOfDay = overworld.method_8532() % 24000L;
            long day = overworld.method_8532() / 24000L;

            // Dawn roll (~1000), once per day.
            if (timeOfDay >= 1000 && timeOfDay < 1100 && day != lastCheckedDay) {
                lastCheckedDay = day;
                announcedToday = false;
                rollDay(server);
            }

            // Clear at next dawn handled by re-roll; also clear if event "expires"
            // (we let it run the full day).

            if (active != null) {
                tickWeather(server, overworld);
                checkCombo(server);
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] WeatherEventHandler registered.");
    }

    private static void rollDay(MinecraftServer server) {
        if (forcedClear) {
            active = null;
            forcedClear = false;
        } else if (forced != null) {
            active = forced;
            forced = null;
            nudgeVanillaWeather(server, active);
        } else if (RANDOM.nextDouble() < SPECIAL_DAY_CHANCE) {
            active = weightedPick();
            nudgeVanillaWeather(server, active);
        } else {
            active = null;
        }
        if (active != null) announce(server);
    }

    private static WeatherEvent weightedPick() {
        int total = WeatherEvent.totalWeight();
        int roll = RANDOM.nextInt(total);
        int cursor = 0;
        for (WeatherEvent w : WeatherEvent.values()) {
            cursor += w.weight;
            if (roll < cursor) return w;
        }
        return WeatherEvent.FOG;
    }

    /** Push vanilla weather to match the event's feel. */
    private static void nudgeVanillaWeather(MinecraftServer server, WeatherEvent w) {
        class_3218 ow = server.method_30002();
        if (ow == null || w == null) return;
        switch (w) {
            case ACID_RAIN, BLIZZARD -> ow.method_27910(0, 12000, true, false);
            case THUNDERSTORM -> ow.method_27910(0, 12000, true, true);
            case HEATWAVE, FOG, METEOR_SHOWER -> ow.method_27910(12000, 0, false, false);
        }
    }

    private static void announce(MinecraftServer server) {
        if (announcedToday || active == null) return;
        announcedToday = true;
        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_7353(class_2561.method_43470(active.announcement)
                .method_27695(active.color, class_124.field_1067), false);
        }
    }

    private static void tickWeather(MinecraftServer server, class_3218 overworld) {
        long t = overworld.method_8510();
        for (class_3222 player : server.method_3760().method_14571()) {
            if (!(player.method_37908() instanceof class_3218 pw)) continue;
            boolean exposed = pw.method_8311(player.method_24515());

            switch (active) {
                case ACID_RAIN -> {
                    if (exposed && pw.method_8419() && t % 60 == 0) {
                        player.method_5643(pw.method_48963().method_48831(), 1.0f);
                    }
                    if (t % 10 == 0 && exposed) pw.method_14166(player, class_2398.field_11234, true,
                        player.method_23317(), player.method_23318() + 2.0, player.method_23321(), 6, 1.5, 0.5, 1.5, 0.01);
                }
                case THUNDERSTORM -> {
                    // Lightning hunts the exposed: occasional strike near player.
                    if (exposed && t % 200 == 0 && RANDOM.nextInt(3) == 0) {
                        var bolt = class_1299.field_6112.method_5883(pw);
                        if (bolt != null) {
                            double ox = (RANDOM.nextDouble() - 0.5) * 8;
                            double oz = (RANDOM.nextDouble() - 0.5) * 8;
                            bolt.method_5814(player.method_23317() + ox, player.method_23318(), player.method_23321() + oz);
                            pw.method_8649(bolt);
                        }
                    }
                }
                case BLIZZARD -> {
                    if (exposed && t % 40 == 0) {
                        player.method_32317(Math.min(player.method_32312() + 30, 140));
                        player.method_6092(new class_1293(
                            class_1294.field_5909, 60, 0, false, false, false));
                    }
                    if (t % 8 == 0) pw.method_14166(player, class_2398.field_28013, true,
                        player.method_23317(), player.method_23318() + 2.0, player.method_23321(), 14, 2.0, 2.0, 2.0, 0.02);
                }
                case HEATWAVE -> {
                    if (pw.method_8530() && exposed && t % 60 == 0) {
                        player.method_6092(new class_1293(
                            class_1294.field_5903, 80, 0, false, false, false));
                        if (!player.method_5799()) {
                            player.method_6092(new class_1293(
                                class_1294.field_5911, 80, 0, false, false, false));
                        }
                    }
                    if (t % 20 == 0 && pw.method_8530()) pw.method_14166(player, class_2398.field_11240, true,
                        player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 4, 1.5, 0.5, 1.5, 0.0);
                }
                case FOG -> {
                    if (t % 60 == 0) {
                        player.method_6092(new class_1293(
                            class_1294.field_38092, 100, 0, false, false, false));
                    }
                    if (t % 10 == 0) pw.method_14166(player, class_2398.field_11204, true,
                        player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 8, 3.0, 1.0, 3.0, 0.0);
                }
                case METEOR_SHOWER -> {
                    if (pw.method_23886() && t % 80 == 0 && RANDOM.nextInt(2) == 0) {
                        spawnMeteor(pw, player);
                    }
                }
            }
        }
    }

    /** A meteor: cosmetic fireball streak + impact that drops ore and burns. */
    private static void spawnMeteor(class_3218 world, class_3222 player) {
        double ox = (RANDOM.nextDouble() - 0.5) * 16;
        double oz = (RANDOM.nextDouble() - 0.5) * 16;
        double tx = player.method_23317() + ox;
        double tz = player.method_23321() + oz;
        class_2338 impact = class_2338.method_49637(tx, player.method_23318(), tz);
        // Find ground.
        impact = world.method_8598(net.minecraft.class_2902.class_2903.field_13197, impact);

        // Visual streak + impact.
        world.method_14199(class_2398.field_11240, tx, impact.method_10264() + 6, tz, 30, 0.5, 3.0, 0.5, 0.1);
        world.method_14199(class_2398.field_11236, tx, impact.method_10264() + 0.5, tz, 2, 0.5, 0.5, 0.5, 0.0);
        world.method_8396(null, impact, net.minecraft.class_3417.field_15152.comp_349(),
            net.minecraft.class_3419.field_15252, 1.0f, 0.8f);

        // Light a small fire and drop a treasure.
        var loot = switch (RANDOM.nextInt(4)) {
            case 0 -> new net.minecraft.class_1799(net.minecraft.class_1802.field_8620, 1 + RANDOM.nextInt(2));
            case 1 -> new net.minecraft.class_1799(net.minecraft.class_1802.field_8695);
            case 2 -> new net.minecraft.class_1799(net.minecraft.class_1802.field_22021);
            default -> new net.minecraft.class_1799(net.minecraft.class_1802.field_8713, 2 + RANDOM.nextInt(3));
        };
        var ie = new net.minecraft.class_1542(world, tx, impact.method_10264() + 1, tz, loot);
        world.method_8649(ie);

        // Light damage to anything at impact (so it's a real hazard).
        class_238 box = new class_238(impact).method_1014(2);
        for (var le : world.method_8390(net.minecraft.class_1309.class, box, e -> true)) {
            le.method_5643(world.method_48963().method_48813(), 4.0f);
            le.method_5639(3);
        }
    }

    /** Detect named moon+weather combos and announce them once each night. */
    private static void checkCombo(MinecraftServer server) {
        SpecialMoon moon = LunarCycleHandler.getActiveMoon();
        if (moon == null) return;

        String combo = null;
        class_124 color = class_124.field_1068;
        if (moon == SpecialMoon.BLOOD && active == WeatherEvent.THUNDERSTORM) {
            combo = "Tempest of Blood — the storm and the red moon feed each other. Pray for dawn.";
            color = class_124.field_1079;
        } else if (moon == SpecialMoon.HOLLOW && active == WeatherEvent.FOG) {
            combo = "The Veil Thins — fog and the Hollow Moon. The dead are very close tonight.";
            color = class_124.field_1076;
        } else if (moon == SpecialMoon.FROST && active == WeatherEvent.BLIZZARD) {
            combo = "The Long Winter — Frost Moon over a blizzard. Nothing warm survives the night.";
            color = class_124.field_1075;
        }

        if (combo != null && !combo.equals(lastComboAnnounced)) {
            lastComboAnnounced = combo;
            for (class_3222 p : server.method_3760().method_14571()) {
                p.method_7353(class_2561.method_43470(combo).method_27695(color, class_124.field_1067, class_124.field_1056), false);
            }
        } else if (combo == null) {
            lastComboAnnounced = null;
        }
    }
}
