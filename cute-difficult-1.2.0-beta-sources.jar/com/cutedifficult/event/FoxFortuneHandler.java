package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.Random;

/**
 * "I'll farm up the last item and get out of the forest, I promise" — the
 * Mori enhanced Fortune. Vanilla Fortune only affects ores and a few special
 * blocks. This makes it drop bonus copies of **any** block broken, scaling
 * with the stored level.
 *
 * <p>Implemented via PlayerBlockBreakEvents.AFTER — after the block breaks,
 * we look at what would normally drop and spawn extra copies. To keep it
 * simple and robust, we drop extra copies of the block's own item form,
 * with the count rolled like vanilla Fortune (1 + random(level+1), biased).
 */
public final class FoxFortuneHandler {

    private static final Random RANDOM = new Random();

    private FoxFortuneHandler() {}

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(world instanceof class_3218 serverWorld)) return;
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(player instanceof class_3222 sp)) return;
            if (sp.method_7337()) return;

            class_1799 tool = sp.method_6047();
            int level = com.cutedifficult.spirit.EnchantMarkers.levelOf(tool, "mori");
            if (level <= 0) return;

            dropBonus(serverWorld, pos, state, level);
        });

        // Loot Goblin — Mori Looting: mobs drop bonus loot when killed with a marked weapon.
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (entity instanceof net.minecraft.class_1657) return;
            if (!(entity.method_37908() instanceof class_3218 serverWorld)) return;
            if (!(source.method_5529() instanceof class_3222 sp)) return;
            int level = com.cutedifficult.spirit.EnchantMarkers.levelOf(sp.method_6047(), "mori_goblin");
            if (level <= 0) return;
            // Bonus: a few emeralds + extra XP orbs as "goblin loot".
            int emeralds = RANDOM.nextInt(level + 1);
            if (emeralds > 0) {
                net.minecraft.class_1542 drop = new net.minecraft.class_1542(
                    serverWorld, entity.method_23317(), entity.method_23318() + 0.5, entity.method_23321(),
                    new class_1799(net.minecraft.class_1802.field_8687, emeralds));
                serverWorld.method_8649(drop);
            }
            serverWorld.method_14199(net.minecraft.class_2398.field_11211,
                entity.method_23317(), entity.method_23318() + 0.5, entity.method_23321(), 8, 0.3, 0.3, 0.3, 0.1);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxFortuneHandler registered.");
    }

    private static void dropBonus(class_3218 world, class_2338 pos, class_2680 state, int level) {
        class_2248 block = state.method_26204();
        class_1799 blockItem = new class_1799(block.method_8389());
        if (blockItem.method_7960()) return; // block has no item form (e.g. fire)

        // Vanilla-ish Fortune roll: each level adds a chance for +1..+level extra.
        int bonus = 0;
        for (int i = 0; i < level; i++) {
            if (RANDOM.nextInt(2) == 0) bonus++;
        }
        // Guarantee at least +1 so the enchant always feels rewarding.
        bonus = Math.max(1, bonus);

        class_1799 drop = new class_1799(block.method_8389(), bonus);
        class_2248.method_9577(world, pos, drop);
    }
}
