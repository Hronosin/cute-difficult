package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.EnchantMarkers;
import com.cutedifficult.spirit.EnhancedEnchant;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.KitsuneData;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The kitsune enchantment-transformation system.
 *
 * <p>Give a kitsune an enchanted item (weapon/tool/armor — NOT a book, since
 * anvils strip custom data) whose enchantment matches one of the fox's
 * element enchants. After {@link #TRANSFORM_TICKS} the item gains an enhanced
 * blessing marker (stackable — see {@link EnchantMarkers}) plus updated lore.
 *
 * <p>Multiple different-element blessings can stack on one item: take your
 * Kasai-blessed sword to a Kaminari fox and it'll add the lightning blessing
 * too.
 */
public final class FoxEnchantHandler {

    private static final int TRANSFORM_TICKS = 600; // 30 seconds
    private static final int MIN_TRUST = 20;

    private static final Map<UUID, TransformState> ACTIVE = new ConcurrentHashMap<>();

    private FoxEnchantHandler() {}

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.field_9236) return class_1269.field_5811;
            if (!(entity instanceof class_4019 fox)) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (hand != class_1268.field_5808) return class_1269.field_5811;

            class_1799 held = player.method_5998(hand);
            if (held.method_7960()) return class_1269.field_5811;
            boolean hasAnyEnchant =
                held.method_57824(class_9334.field_49643) != null
                || held.method_57824(class_9334.field_49633) != null;
            if (!hasAnyEnchant) return class_1269.field_5811;

            return tryBeginTransform((class_3218) world, sp, fox, held);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (ACTIVE.isEmpty()) return;
            var it = ACTIVE.entrySet().iterator();
            while (it.hasNext()) {
                var entry = it.next();
                TransformState state = entry.getValue();
                state.ticksRemaining--;

                class_1297 e = null;
                for (class_3218 w : server.method_3738()) {
                    e = w.method_14190(entry.getKey());
                    if (e != null) break;
                }
                if (!(e instanceof class_4019 fox) || !fox.method_5805()) {
                    it.remove();
                    continue;
                }

                class_3218 world = (class_3218) fox.method_37908();
                if (state.ticksRemaining % 10 == 0) {
                    world.method_14199(class_2398.field_11215,
                        fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(),
                        6, 0.3, 0.3, 0.3, 0.5);
                }

                if (state.ticksRemaining <= 0) {
                    completeTransform(world, fox, state);
                    it.remove();
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxEnchantHandler registered.");
    }

    private static class_1269 tryBeginTransform(class_3218 world, class_3222 player,
                                                  class_4019 fox, class_1799 item) {
        KitsuneData data = FoxStorage.peekCache(fox);
        if (data == null) return class_1269.field_5811;
        if (data.trustLevel < MIN_TRUST) {
            player.method_7353(class_2561.method_43470("The kitsune doesn't trust you enough to enchant. (need trust ≥ 20)")
                .method_27695(class_124.field_1080, class_124.field_1056), true);
            return class_1269.field_5814;
        }
        if (ACTIVE.containsKey(fox.method_5667())) {
            player.method_7353(class_2561.method_43470("This kitsune is already transforming something.")
                .method_27695(class_124.field_1080, class_124.field_1056), true);
            return class_1269.field_5814;
        }

        // Gather the item's enchantments (gear uses ENCHANTMENTS, books STORED_).
        class_9304 enchants = item.method_57824(class_9334.field_49633);
        if (enchants == null || enchants.method_57543()) {
            enchants = item.method_57824(class_9334.field_49643);
        }
        if (enchants == null) return class_1269.field_5811;

        // Find any enchantment on the item that matches one of THIS element's
        // enhanced enchants.
        EnhancedEnchant chosen = null;
        int chosenLevel = 1;
        for (class_6880<class_1887> entry : enchants.method_57534()) {
            var key = entry.method_40230().orElse(null);
            if (key == null) continue;
            String path = key.method_29177().method_12832();
            EnhancedEnchant candidate = EnhancedEnchant.match(data.element, path);
            if (candidate != null) {
                chosen = candidate;
                chosenLevel = enchants.method_57536(entry);
                break;
            }
        }

        if (chosen == null) {
            player.method_7353(class_2561.method_43470("This kitsune has no blessing for that item's enchantments.")
                .method_27695(class_124.field_1080, class_124.field_1056), true);
            return class_1269.field_5814;
        }

        // Already blessed with this exact marker?
        if (EnchantMarkers.has(item, chosen.markerId)) {
            player.method_7353(class_2561.method_43470("This item already carries that blessing.")
                .method_27695(class_124.field_1080, class_124.field_1056), true);
            return class_1269.field_5814;
        }

        class_1799 taken = item.method_7972();
        taken.method_7939(1);
        if (taken.method_31574(class_1802.field_8598)) {
            player.method_7353(class_2561.method_43470("Tip: bless the actual gear, not a book — anvils strip the blessing.")
                .method_27695(class_124.field_1054, class_124.field_1056), false);
        }
        if (!player.method_7337()) item.method_7934(1);

        fox.method_5673(net.minecraft.class_1304.field_6173, taken);
        ACTIVE.put(fox.method_5667(), new TransformState(chosen, TRANSFORM_TICKS, taken, chosenLevel));

        world.method_14199(class_2398.field_11215,
            fox.method_23317(), fox.method_23318() + 1, fox.method_23321(), 20, 0.4, 0.4, 0.4, 1.0);
        world.method_43128(null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_15119, class_3419.field_15254, 1.0f, 1.2f);
        player.method_7353(class_2561.method_43470("The kitsune takes it and begins to transform it...")
            .method_27695(chosen.color(), class_124.field_1056), false);
        return class_1269.field_5812;
    }

    private static void completeTransform(class_3218 world, class_4019 fox, TransformState state) {
        EnhancedEnchant ench = state.enchant;
        class_1799 result = state.original.method_7972();

        // Add the stacking marker.
        EnchantMarkers.add(result, ench.markerId, state.level);

        // Rebuild lore from ALL markers now on the item.
        Map<String, Integer> markers = EnchantMarkers.read(result);
        List<class_2561> lore = new ArrayList<>();
        for (Map.Entry<String, Integer> m : markers.entrySet()) {
            EnhancedEnchant e = EnhancedEnchant.byMarker(m.getKey());
            if (e == null) continue;
            String suffix = m.getValue() > 1 ? " " + toRoman(m.getValue()) : "";
            lore.add(class_2561.method_43470("✦ " + e.displayName + suffix).method_27695(e.color(), class_124.field_1067));
            lore.add(class_2561.method_43470("  " + e.loreDescription).method_27695(class_124.field_1063, class_124.field_1056));
        }
        result.method_57379(class_9334.field_49632, new class_9290(lore));

        fox.method_5673(net.minecraft.class_1304.field_6173, class_1799.field_8037);

        class_1542 drop = new class_1542(world, fox.method_23317(), fox.method_23318() + 0.5, fox.method_23321(), result);
        drop.method_6982(10);
        world.method_8649(drop);

        world.method_14199(class_2398.field_11220,
            fox.method_23317(), fox.method_23318() + 1, fox.method_23321(), 30, 0.5, 0.5, 0.5, 0.3);
        world.method_43128(null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_14703, class_3419.field_15254, 1.0f, 1.5f);
    }

    private static final class TransformState {
        final EnhancedEnchant enchant;
        int ticksRemaining;
        final class_1799 original;
        final int level;

        TransformState(EnhancedEnchant enchant, int ticksRemaining, class_1799 original, int level) {
            this.enchant = enchant;
            this.ticksRemaining = ticksRemaining;
            this.original = original;
            this.level = level;
        }
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I"; case 2 -> "II"; case 3 -> "III";
            case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n);
        };
    }
}
