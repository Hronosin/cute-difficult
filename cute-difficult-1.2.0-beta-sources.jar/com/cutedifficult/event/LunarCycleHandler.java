package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.SpecialMoon;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Random;

/**
 * Special-moon system. Each night, rolled at dusk, may become one of nine
 * {@link SpecialMoon} events — each with a paired downside and upside.
 * Admins/testers can force a specific moon via {@code /cd moon <type>}.
 *
 * <p>Roughly 45% of nights are "ordinary"; the rest roll a weighted lottery
 * among the nine moons. The chosen moon lasts the night and clears at dawn.
 */
public final class LunarCycleHandler {

    private static final Random RANDOM = new Random();

    /** The moon active tonight, or null for an ordinary night. */
    private static SpecialMoon activeMoon = null;
    /** An admin-forced moon for the NEXT dusk roll (overrides the lottery). */
    private static SpecialMoon forcedMoon = null;
    private static boolean forcedClear = false;

    private static boolean announcedTonight = false;
    private static long lastCheckedDay = -1;

    /** Chance that a night becomes special at all. */
    private static final double SPECIAL_NIGHT_CHANCE = 0.55;

    private LunarCycleHandler() {}

    // ===== Public state accessors (used by other systems) =====
    public static SpecialMoon getActiveMoon() { return activeMoon; }
    /** Public API for upcoming weather/astrology systems; not all callers exist yet. */
    @SuppressWarnings("unused")
    public static boolean isActive(SpecialMoon m) { return activeMoon == m; }
    public static boolean isBloodMoon() { return activeMoon == SpecialMoon.BLOOD; }
    public static boolean isNewMoon(class_3218 world) { return world.method_30273() == 4; }
    /** Public API for upcoming systems; not yet called internally. */
    @SuppressWarnings("unused")
    public static boolean isFullMoon(class_3218 world) { return world.method_30273() == 0; }

    // ===== Command hooks =====
    /** Force a specific moon at the next dusk (or immediately if already night). */
    public static void forceMoon(MinecraftServer server, SpecialMoon moon) {
        activeMoon = moon;
        forcedMoon = null;
        forcedClear = false;
        announcedTonight = false;
        announce(server);
    }

    public static void clearMoon() {
        activeMoon = null;
        forcedMoon = null;
        forcedClear = true;
    }

    public static void register() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (activeMoon == null) return;
            if (!(world instanceof class_3218 sw)) return;
            if (!sw.method_23886()) return;
            if (entity instanceof class_1588 hostile) {
                applyMoonSpawnBuffs(hostile);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            class_3218 overworld = server.method_30002();
            if (overworld == null) return;

            long timeOfDay = overworld.method_8532() % 24000L;
            long day = overworld.method_8532() / 24000L;

            // Dusk roll, once per night.
            if (timeOfDay >= 13000 && timeOfDay < 13100 && day != lastCheckedDay) {
                lastCheckedDay = day;
                announcedTonight = false;
                rollNight(server);
            }

            // Dawn clear.
            if (timeOfDay >= 23500 && activeMoon != null) {
                activeMoon = null;
            }

            // Per-tick ambient + ongoing effects for the active moon.
            if (activeMoon != null) {
                tickMoonAmbient(server, overworld);
            }
        });

        // Death-based loot bonuses (Blood/Pumpkin/Frost/Wolf etc.).
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (activeMoon == null) return;
            if (!(entity instanceof class_1588)) return;
            if (!(entity.method_37908() instanceof class_3218 sw)) return;
            if (!sw.method_23886()) return;
            if (!(source.method_5529() instanceof class_3222)) return;
            applyMoonDeathLoot(sw, entity);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] LunarCycleHandler registered.");
    }

    private static void rollNight(MinecraftServer server) {
        if (forcedClear) {
            activeMoon = null;
            forcedClear = false;
        } else if (forcedMoon != null) {
            activeMoon = forcedMoon;
            forcedMoon = null;
        } else if (RANDOM.nextDouble() < SPECIAL_NIGHT_CHANCE) {
            activeMoon = weightedPick();
        } else {
            activeMoon = null;
        }
        if (activeMoon != null) announce(server);
    }

    private static SpecialMoon weightedPick() {
        int total = SpecialMoon.totalWeight();
        int roll = RANDOM.nextInt(total);
        int cursor = 0;
        for (SpecialMoon m : SpecialMoon.values()) {
            cursor += m.weight;
            if (roll < cursor) return m;
        }
        return SpecialMoon.BLOOD; // fallback
    }

    private static void announce(MinecraftServer server) {
        if (announcedTonight || activeMoon == null) return;
        announcedTonight = true;
        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_7353(class_2561.method_43470(activeMoon.announcement)
                .method_27695(activeMoon.color, class_124.field_1067), false);
        }
    }

    // ===== Spawn-time buffs =====
    private static void applyMoonSpawnBuffs(class_1588 hostile) {
        switch (activeMoon) {
            case BLOOD -> {
                infinite(hostile, class_1294.field_5910, 0);
                infinite(hostile, class_1294.field_5904, 0);
            }
            case PUMPKIN -> {
                // Masked horrors: give them a pumpkin helmet + slight strength.
                hostile.method_5673(net.minecraft.class_1304.field_6169,
                    new class_1799(class_1802.field_17519));
                infinite(hostile, class_1294.field_5910, 0);
            }
            case FROST -> {
                // Slower but tougher.
                infinite(hostile, class_1294.field_5909, 0);
                infinite(hostile, class_1294.field_5907, 0);
                infinite(hostile, class_1294.field_5914, 1);
            }
            case CURSED -> infinite(hostile, class_1294.field_5910, 0);
            case BLUE -> infinite(hostile, class_1294.field_5907, 0);
            case MIRROR, WOLF, HARVEST, HOLLOW -> { /* handled elsewhere / no spawn buff */ }
        }
    }

    private static void infinite(class_1309 e, net.minecraft.class_6880<net.minecraft.class_1291> effect, int amp) {
        e.method_6092(new class_1293(effect, Integer.MAX_VALUE, amp, false, false, false));
    }

    // ===== Death loot =====
    private static void applyMoonDeathLoot(class_3218 sw, net.minecraft.class_1297 entity) {
        double x = entity.method_23317(), y = entity.method_23318() + 0.5, z = entity.method_23321();
        switch (activeMoon) {
            case BLOOD -> {
                class_1303.method_31493(sw, entity.method_19538(), 8 + RANDOM.nextInt(8));
                sw.method_14199(class_2398.field_28479, x, y, z, 6, 0.3, 0.3, 0.3, 0.02);
            }
            case PUMPKIN -> {
                if (RANDOM.nextInt(3) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8479, 1 + RANDOM.nextInt(2)));
                }
                if (RANDOM.nextInt(8) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8741));
                }
                if (RANDOM.nextInt(20) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8695));
                }
            }
            case FROST -> {
                if (RANDOM.nextInt(4) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8081));
                }
            }
            case WOLF -> {
                if (RANDOM.nextInt(2) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8606, 1 + RANDOM.nextInt(2)));
                }
            }
            case BLUE -> {
                class_1303.method_31493(sw, entity.method_19538(), 15 + RANDOM.nextInt(15));
                if (RANDOM.nextInt(10) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_8477));
                }
            }
            case CURSED -> {
                // Cursed loot: occasional ominous bottle / echo shard.
                if (RANDOM.nextInt(15) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_38746));
                }
            }
            case HOLLOW -> {
                if (RANDOM.nextInt(12) == 0) {
                    dropItem(sw, x, y, z, new class_1799(class_1802.field_21999));
                }
            }
            case MIRROR, HARVEST -> { /* no special death loot */ }
        }
    }

    private static void dropItem(class_3218 sw, double x, double y, double z, class_1799 stack) {
        net.minecraft.class_1542 ie = new net.minecraft.class_1542(sw, x, y, z, stack);
        sw.method_8649(ie);
    }

    // ===== Per-tick ambient & ongoing =====
    private static void tickMoonAmbient(MinecraftServer server, class_3218 overworld) {
        long t = overworld.method_8510();

        for (class_3222 player : server.method_3760().method_14571()) {
            if (!(player.method_37908() instanceof class_3218 pw)) continue;
            if (!pw.method_23886()) continue;

            switch (activeMoon) {
                case BLOOD -> {
                    // force=true guarantees the player sees them even with low
                    // particle settings; tighter spread + higher count = visible.
                    if (t % 20 == 0) pw.method_14166(player, class_2398.field_46763, true,
                        player.method_23317(), player.method_23318() + 2.2, player.method_23321(), 12, 1.5, 1.0, 1.5, 0.01);
                }
                case HARVEST -> {
                    if (t % 60 == 0) {
                        player.method_6092(new class_1293(
                            class_1294.field_5922, 40, 0, false, false, false));
                    }
                    if (t % 20 == 0) accelerateCrops(pw, player);
                    if (t % 20 == 0) pw.method_14166(player, class_2398.field_11211, true,
                        player.method_23317(), player.method_23318() + 1.5, player.method_23321(), 8, 1.5, 1.0, 1.5, 0.0);
                }
                case FROST -> {
                    if (t % 40 == 0 && pw.method_8311(player.method_24515())) {
                        player.method_6092(new class_1293(
                            class_1294.field_5909, 60, 0, false, false, false));
                        player.method_32317(Math.min(player.method_32312() + 30, 140));
                    }
                    if (t % 15 == 0) pw.method_14166(player, class_2398.field_28013, true,
                        player.method_23317(), player.method_23318() + 2.0, player.method_23321(), 10, 1.5, 1.5, 1.5, 0.02);
                }
                case WOLF -> {
                    if (t % 30 == 0) pw.method_14166(player, class_2398.field_11251, true,
                        player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 6, 1.5, 0.5, 1.5, 0.01);
                }
                case MIRROR -> {
                    if (t % 25 == 0) pw.method_14166(player, class_2398.field_28479, true,
                        player.method_23317(), player.method_23318() + 1.5, player.method_23321(), 8, 1.5, 1.0, 1.5, 0.0);
                }
                case HOLLOW -> {
                    if (t % 60 == 0) {
                        player.method_6092(new class_1293(
                            class_1294.field_38092, 80, 0, false, false, false));
                    }
                    if (t % 15 == 0) pw.method_14166(player, class_2398.field_38002, true,
                        player.method_23317(), player.method_23318() + 1.5, player.method_23321(), 8, 1.2, 1.2, 1.2, 0.02);
                }
                case CURSED -> {
                    if (t % 20 == 0) pw.method_14166(player, class_2398.field_11249, true,
                        player.method_23317(), player.method_23318() + 2.0, player.method_23321(), 10, 1.5, 1.2, 1.5, 0.0);
                }
                case BLUE -> {
                    if (t % 20 == 0) pw.method_14166(player, class_2398.field_11207, true,
                        player.method_23317(), player.method_23318() + 2.0, player.method_23321(), 8, 1.5, 1.5, 1.5, 0.01);
                }
                default -> {}
            }
        }
    }

    private static void accelerateCrops(class_3218 world, class_3222 player) {
        net.minecraft.class_2338 center = player.method_24515();
        net.minecraft.class_5819 mc = world.method_8409();
        int r = 5;
        net.minecraft.class_2338.class_2339 cur = new net.minecraft.class_2338.class_2339();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    cur.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    var state = world.method_8320(cur);
                    if (state.method_26204() instanceof net.minecraft.class_2302 && RANDOM.nextInt(4) == 0) {
                        state.method_26199(world, cur.method_10062(), mc);
                    }
                }
            }
        }
    }
}
