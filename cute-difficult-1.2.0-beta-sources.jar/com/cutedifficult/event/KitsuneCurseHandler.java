package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Curses;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.SpiritData;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4019;

/**
 * Defiled players are cursed by nearby kitsune. When a player at DEFILED karma
 * or worse lingers near a kitsune, the offended spirit periodically lays a
 * curse on them — using the element-specific {@link Curses} already defined.
 * The closer to CURSED, the more often it strikes.
 *
 * <p>This complements {@link com.cutedifficult.spirit.FoxHostility}, which makes
 * the same players physically attackable: hatred has both a melee face and a
 * spiritual one.
 */
public final class KitsuneCurseHandler {

    private static long tick = 0;

    private KitsuneCurseHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            if (tick % 100 != 0) return; // check every 5 seconds

            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_7337() || player.method_7325()) continue;
                SpiritData.KarmaTier tier = SpiritData.karmaTier(server, player);
                if (tier != SpiritData.KarmaTier.DEFILED && tier != SpiritData.KarmaTier.CURSED) {
                    continue;
                }
                // CURSED strikes twice as often (skip the gate randomly for DEFILED).
                if (tier == SpiritData.KarmaTier.DEFILED && player.method_59922().method_43056()) {
                    continue;
                }
                if (!(player.method_37908() instanceof class_3218 world)) continue;
                tryCurse(world, player);
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] KitsuneCurseHandler registered.");
    }

    private static void tryCurse(class_3218 world, class_3222 player) {
        // Find the nearest kitsune within 16 blocks.
        var foxes = world.method_8390(class_4019.class,
            player.method_5829().method_1014(16),
            f -> f instanceof com.cutedifficult.entity.KitsuneEntity && f.method_5805());
        if (foxes.isEmpty()) return;

        class_4019 nearest = foxes.get(0);
        double best = nearest.method_5858(player);
        for (class_4019 f : foxes) {
            double d = f.method_5858(player);
            if (d < best) { best = d; nearest = f; }
        }

        KitsuneData data = FoxStorage.peekCache(nearest);
        if (data == null) return;

        // The offended kitsune lays a curse of its element.
        Curses.inflict(player, data.element, data.tails);

        // Visual: a thread of sculk soul from fox to player.
        double fx = nearest.method_23317(), fy = nearest.method_23318() + 0.5, fz = nearest.method_23321();
        double dx = player.method_23317() - fx, dy = (player.method_23318() + 1) - fy, dz = player.method_23321() - fz;
        int steps = 12;
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            world.method_14199(class_2398.field_38002,
                fx + dx * t, fy + dy * t, fz + dz * t, 1, 0.02, 0.02, 0.02, 0.0);
        }
        player.method_7353(net.minecraft.class_2561.method_43470(
            "A nearby kitsune fixes you with a baleful stare. A curse settles over you.")
            .method_27695(net.minecraft.class_124.field_1079, net.minecraft.class_124.field_1056), true);
    }
}
