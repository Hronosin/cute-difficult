package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.spirit.SpiritData.KarmaTier;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Kegare — ritual pollution. The consequences of carrying Karma. The higher the
 * tier, the heavier the world leans against you:
 *
 * <ul>
 *   <li><b>TAINTED (50+)</b> — faint dark particles; occasional bad luck.</li>
 *   <li><b>DEFILED (100+)</b> — passive Unluck; hostile mobs drawn to you;
 *       blessings suppressed (handled where blessings apply).</li>
 *   <li><b>CURSED (150+)</b> — Unluck + Weakness; frequent mob pressure; the
 *       air itself recoils (heavier particles, ambient dread sound).</li>
 * </ul>
 *
 * <p>Offering failure, item-quality penalties, kitsune hatred, and weather/moon
 * bias are applied in their own systems by reading {@link SpiritData#karmaTier};
 * this handler owns the per-tick personal afflictions and the mob pressure.
 */
public final class KarmaEffectsHandler {

    private static long tick = 0;

    private KarmaEffectsHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            if (tick % 40 != 0) return; // twice/sec is plenty for status upkeep
            MinecraftServer srv = server;
            for (class_3222 player : srv.method_3760().method_14571()) {
                if (player.method_7325() || player.method_7337()) continue;
                KarmaTier tier = SpiritData.karmaTier(srv, player);
                if (tier == KarmaTier.PURE) continue;
                applyAfflictions(player, tier);
                if (player.method_37908() instanceof class_3218 sw) {
                    ambient(sw, player, tier);
                }
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] KarmaEffectsHandler registered.");
    }

    private static void applyAfflictions(class_3222 player, KarmaTier tier) {
        // Status durations slightly longer than the 40-tick cadence so they
        // don't visibly flicker (60 ticks).
        switch (tier) {
            case TAINTED -> {
                // Mild: occasional unluck.
                player.method_6092(new class_1293(
                    class_1294.field_5908, 60, 0, true, false, false));
            }
            case DEFILED -> {
                player.method_6092(new class_1293(
                    class_1294.field_5908, 60, 1, true, false, false));
            }
            case CURSED -> {
                player.method_6092(new class_1293(
                    class_1294.field_5908, 60, 2, true, false, false));
                player.method_6092(new class_1293(
                    class_1294.field_5911, 60, 0, true, false, false));
            }
            default -> {}
        }
    }

    private static void ambient(class_3218 world, class_3222 player, KarmaTier tier) {
        int count = switch (tier) {
            case TAINTED -> 2;
            case DEFILED -> 5;
            case CURSED -> 10;
            default -> 0;
        };
        if (count > 0) {
            world.method_14166(player, class_2398.field_38002, false,
                player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
                count, 0.4, 0.6, 0.4, 0.01);
        }
        if (tier == KarmaTier.CURSED && tick % 200 == 0) {
            world.method_8396(null, player.method_24515(),
                net.minecraft.class_3417.field_14564.comp_349(),
                net.minecraft.class_3419.field_15256, 0.6f, 0.5f);
        }
    }

    /** Mob-pressure multiplier for spawn logic to read (1.0 = normal). */
    public static double mobPressure(KarmaTier tier) {
        return switch (tier) {
            case PURE -> 1.0;
            case TAINTED -> 1.15;
            case DEFILED -> 1.4;
            case CURSED -> 1.8;
        };
    }
}
