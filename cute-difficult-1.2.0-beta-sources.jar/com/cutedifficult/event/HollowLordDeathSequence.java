package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import net.minecraft.class_124;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * The cinematic death of the Hollow Lord, played out over ~5 seconds as a
 * timed, multi-stage sequence (one instance per death, ticked by
 * {@link HollowLordCombatHandler}).
 *
 * <p>Stages (tick 0 → DURATION):
 * <ol>
 *   <li><b>Implosion sphere</b> — a shell of sculk/soul-fire particles
 *       collapses inward onto the death point.</li>
 *   <li><b>Rupture blast</b> — an explosion clears the old portal and arena
 *       clutter; the Lord "tears apart."</li>
 *   <li><b>Expanding ring</b> — a huge ring of sculk + soul fire races outward
 *       along the ground, breaking blocks as it goes.</li>
 *   <li><b>New portal</b> — a nine-rayed star portal forms at the centre, and
 *       the reward drops.</li>
 * </ol>
 */
public final class HollowLordDeathSequence {

    private static final int DURATION = 100; // ~5 seconds

    // Stage boundaries (ticks).
    private static final int SPHERE_END = 35;   // implosion sphere
    private static final int BLAST_AT = 36;     // rupture explosion (one-shot)
    private static final int RING_START = 40;   // expanding ring begins
    private static final int RING_END = 85;
    private static final int PORTAL_AT = 88;    // portal forms (one-shot)

    private final class_3218 world;
    private final class_243 center;
    private final com.cutedifficult.entity.HollowLordEntity lord;
    private int tick = 0;
    private boolean blastDone = false;
    private boolean portalDone = false;
    private boolean finished = false;

    public HollowLordDeathSequence(class_3218 world,
                                   com.cutedifficult.entity.HollowLordEntity lord,
                                   class_243 centerPos) {
        this.world = world;
        this.lord = lord;
        this.center = centerPos;
    }

    public boolean isFinished() { return finished; }

    /** Advance one tick of the animation. */
    public void tick() {
        if (finished) return;

        // Keep the (still-alive) Lord pinned at centre and frozen during the show.
        if (lord != null && lord.method_5805()) {
            lord.method_18800(0, 0, 0);
            lord.field_6037 = true;
            lord.method_5859(center.field_1352, center.field_1351, center.field_1350);
            // Fade it out near the rupture, remove it at the blast.
            if (tick >= BLAST_AT) {
                lord.method_31472();
            }
        }

        if (tick <= SPHERE_END) {
            implosionSphere();
        }
        if (tick == BLAST_AT && !blastDone) {
            ruptureBlast();
            blastDone = true;
        }
        if (tick >= RING_START && tick <= RING_END) {
            expandingRing();
        }
        if (tick == PORTAL_AT && !portalDone) {
            dropRewardAndCrystals();
            announce();
            portalDone = true;
        }

        tick++;
        if (tick > DURATION) finished = true;
    }

    /** Stage 1: a particle shell collapsing inward to the centre. */
    private void implosionSphere() {
        double progress = tick / (double) SPHERE_END;     // 0 → 1
        double radius = 8.0 * (1.0 - progress) + 0.5;     // shrinks inward
        int points = 60;
        for (int i = 0; i < points; i++) {
            // Distribute points on a sphere (golden-spiral-ish).
            double phi = Math.acos(1 - 2 * (i + 0.5) / points);
            double theta = Math.PI * (1 + Math.sqrt(5)) * i;
            double sx = center.field_1352 + radius * Math.sin(phi) * Math.cos(theta);
            double sy = center.field_1351 + radius * Math.cos(phi);
            double sz = center.field_1350 + radius * Math.sin(phi) * Math.sin(theta);
            particle(class_2398.field_38002, sx, sy, sz, 1, 0, 0, 0, 0.0);
            if (i % 3 == 0) {
                particle(class_2398.field_22246, sx, sy, sz, 1, 0, 0, 0, 0.0);
            }
        }
        if (tick % 8 == 0) {
            playAt(world, class_2338.method_49638(center),
                class_3417.field_15045, 2.0f, 0.4f);
        }
    }

    /** Stage 2: the rupture — explosion clears old portal/clutter. */
    private void ruptureBlast() {
        particle(class_2398.field_11221, center.field_1352, center.field_1351, center.field_1350, 3, 2, 2, 2, 0);
        particle(class_2398.field_38002, center.field_1352, center.field_1351, center.field_1350, 300, 3, 3, 3, 0.5);
        playAt(world, class_2338.method_49638(center),
            class_3417.field_14773, 5.0f, 0.5f);
        playAt(world, class_2338.method_49638(center),
            class_3417.field_15152, 5.0f, 0.6f);

        // Clear surrounding clutter (ritual obsidian etc.) but NEVER touch the
        // exit portal or the bedrock frame — the player needs the vanilla portal
        // intact to leave.
        class_2338 c = class_2338.method_49638(center);
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -8; dy <= 4; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    class_2338 p = c.method_10069(dx, dy, dz);
                    var st = world.method_8320(p);
                    if (st.method_27852(class_2246.field_10027) || st.method_27852(class_2246.field_9987)) continue;
                    world.method_8501(p, class_2246.field_10124.method_9564());
                }
            }
        }
    }

    /** Stage 3: an expanding ground ring of sculk + soul fire that breaks blocks. */
    private void expandingRing() {
        double t = (tick - RING_START) / (double) (RING_END - RING_START); // 0 → 1
        double radius = 4 + t * 30; // grows from 4 to ~34 blocks
        double groundY = 63; // platform level

        int points = (int) (radius * 6);
        for (int i = 0; i < points; i++) {
            double a = (i / (double) points) * Math.PI * 2;
            double rx = center.field_1352 + Math.cos(a) * radius;
            double rz = center.field_1350 + Math.sin(a) * radius;
            particle(class_2398.field_22246, rx, groundY + 1, rz, 1, 0, 0.1, 0, 0.01);
            if (i % 2 == 0) {
                particle(class_2398.field_38004, rx, groundY + 1, rz, 1, 0, 0, 0, 0.0);
            }

            // Break the surface block at the ring edge for a shockwave feel.
            class_2338 gp = class_2338.method_49637(rx, groundY, rz);
            var state = world.method_8320(gp);
            if (!state.method_26215() && state.method_26214(world, gp) >= 0
                && !state.method_27852(class_2246.field_9987) && !state.method_27852(class_2246.field_10027)) {
                world.method_22352(gp, false);
            }
        }
        if (tick % 6 == 0) {
            playAt(world, class_2338.method_49638(center),
                class_3417.field_38830, 1.5f, 0.7f);
        }
    }

    /** Stage 4: drop the reward (Nether Stars) and 4 End crystals so the player
     *  can restore the exit portal themselves via the vanilla mechanic —
     *  keeping the normal dragon-respawn cycle intact (no custom portal that
     *  would clobber it). */
    private void dropRewardAndCrystals() {
        double cy = 67;
        // Reward: 2 Nether Stars.
        world.method_8649(new class_1542(world, 0.5, cy, 0.5,
            new class_1799(class_1802.field_8137, 2)));
        // Exit kit: 4 End crystals.
        world.method_8649(new class_1542(world, 0.5, cy, 0.5,
            new class_1799(class_1802.field_8301, 4)));

        particle(class_2398.field_11220, 0.5, cy + 1, 0.5, 150, 4, 2, 4, 0.4);
        particle(class_2398.field_23190, 0.5, cy + 1, 0.5, 120, 3, 2, 3, 0.3);
        playAt(world, class_2338.method_49637(0.5, cy, 0.5),
            class_3417.field_14981, 4.0f, 0.8f);
    }

    /**
     * Spawn particles via the player-targeted force=true overload for every
     * nearby player. The broadcast overload is unreliable on default particle
     * settings (this bit us with moons and the cosmos), so force them.
     */
    private void particle(net.minecraft.class_2394 effect,
                          double x, double y, double z, int count,
                          double dx, double dy, double dz, double speed) {
        for (class_3222 p : world.method_18456()) {
            if (p.method_5649(x, y, z) > 128 * 128) continue;
            world.method_14166(p, effect, true, x, y, z, count, dx, dy, dz, speed);
        }
    }

    private void announce() {
        for (class_3222 p : world.method_18456()) {
            p.method_7353(class_2561.method_43470("The Hollow Lord is unmade. Use the crystals to reopen the way home.")
                .method_27695(class_124.field_1065, class_124.field_1067), false);
            // Great purification: −100 karma for players who were in the fight.
            if (p.method_5649(center.field_1352, center.field_1351, center.field_1350) < 200 * 200) {
                RedemptionHandler.greatPurification(world, p);
            }
        }
        CuteDifficult.LOGGER.info("[CuteDifficult] Hollow Lord death sequence complete.");
    }

    /**
     * Play a sound at a position, accepting either a direct {@link net.minecraft.class_3414}
     * or a {@link net.minecraft.class_6880} wrapper — in 1.21.1
     * some SoundEvents fields are one and some the other, and which is which
     * isn't predictable, so we normalize here and never have to care.
     */
    private void playAt(class_3218 world, class_2338 pos, Object sound, float volume, float pitch) {
        net.minecraft.class_3414 event;
        if (sound instanceof net.minecraft.class_3414 se) {
            event = se;
        } else if (sound instanceof net.minecraft.class_6880<?> entry
                   && entry.comp_349() instanceof net.minecraft.class_3414 se) {
            event = se;
        } else {
            return;
        }
        world.method_8396(null, pos, event, class_3419.field_15251, volume, pitch);
    }
}
