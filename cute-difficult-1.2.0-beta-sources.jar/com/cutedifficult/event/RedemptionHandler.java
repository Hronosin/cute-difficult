package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.SpiritData;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1429;
import net.minecraft.class_1646;
import net.minecraft.class_2302;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Redemption — cleansing kegare through peaceful, creative, life-giving acts.
 * Karma can only be lowered by living well, not by more violence:
 *
 * <ul>
 *   <li><b>Harvesting mature crops</b> — small cleanse (−1), the quiet work of
 *       tending the land.</li>
 *   <li><b>Breeding animals</b> — medium cleanse (−3), nurturing new life.</li>
 *   <li><b>Trading with villagers</b> — larger cleanse (−5), restoring bonds
 *       with the community.</li>
 *   <li><b>Slaying the Hollow Lord</b> — −100, a great purification (handled in
 *       the boss death code, which calls {@link #greatPurification}).</li>
 * </ul>
 */
public final class RedemptionHandler {

    private RedemptionHandler() {}

    public static void register() {
        // Harvesting mature crops cleanses a little.
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world.field_9236) return;
            if (!(player instanceof class_3222 sp)) return;
            if (state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
                cleanse(sp, 1, false);
            }
        });

        // Breeding animals cleanses moderately. We detect the moment via the
        // interact callback when feeding breeding food to a love-ready animal.
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.field_9236) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;

            if (entity instanceof class_1646 villager) {
                // Trading: detect when the player opens trade with a villager
                // that has trades. (A light heuristic; full trade-complete hooks
                // need a mixin. Opening commerce already signals peaceful intent.)
                if (!villager.method_6109() && !villager.method_8264().isEmpty()) {
                    // Throttle so holding right-click doesn't spam cleanse.
                    long now = world.method_8510();
                    Long last = LAST_TRADE.get(sp.method_5667());
                    if (last == null || now - last > 100) {
                        LAST_TRADE.put(sp.method_5667(), now);
                        cleanse(sp, 5, true);
                    }
                }
            } else if (entity instanceof class_1429 animal) {
                // Breeding: if the held item is this animal's breeding food and
                // the animal can fall in love, count it as a nurturing act.
                if (!animal.method_6109() && animal.method_6481(sp.method_5998(hand))
                    && animal.method_5618() == 0) {
                    long now = world.method_8510();
                    Long last = LAST_BREED.get(sp.method_5667());
                    if (last == null || now - last > 60) {
                        LAST_BREED.put(sp.method_5667(), now);
                        cleanse(sp, 3, true);
                    }
                }
            }
            return class_1269.field_5811;
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] RedemptionHandler registered.");
    }

    private static final java.util.Map<java.util.UUID, Long> LAST_TRADE =
        new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.Map<java.util.UUID, Long> LAST_BREED =
        new java.util.concurrent.ConcurrentHashMap<>();

    /** Lower karma by {@code amount}; optionally show a small feedback cue. */
    private static void cleanse(class_3222 player, int amount, boolean notify) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;
        int before = SpiritData.getKarma(server, player);
        if (before <= 0) return; // already pure, nothing to cleanse
        SpiritData.addKarma(server, player, -amount);

        if (player.method_37908() instanceof class_3218 sw) {
            sw.method_14166(player, class_2398.field_11211, false,
                player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 5, 0.3, 0.4, 0.3, 0.02);
        }
        if (notify) {
            int after = SpiritData.getKarma(server, player);
            player.method_7353(net.minecraft.class_2561.method_43470(
                "A small weight lifts. (karma " + before + " \u2192 " + after + ")")
                .method_27695(net.minecraft.class_124.field_1060, net.minecraft.class_124.field_1056), true);
        }
    }

    /** Great purification: slaying the Hollow Lord washes away deep stain. */
    public static void greatPurification(class_3218 world, class_3222 player) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;
        int before = SpiritData.getKarma(server, player);
        SpiritData.addKarma(server, player, -100);
        int after = SpiritData.getKarma(server, player);

        world.method_14166(player, class_2398.field_11220, false,
            player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 80, 0.5, 0.8, 0.5, 0.3);
        player.method_7353(net.minecraft.class_2561.method_43470(
            "The Hollow Lord's end purges the stain from your spirit. (karma " + before + " \u2192 " + after + ")")
            .method_27695(net.minecraft.class_124.field_1065, net.minecraft.class_124.field_1067), false);
    }
}
