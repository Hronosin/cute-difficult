package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Blessings;
import com.cutedifficult.spirit.Curses;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxPersonality;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import net.minecraft.server.MinecraftServer;
import java.util.Random;

/**
 * Right-click-fox-with-item interaction. The mechanical core of the
 * spiritual loop.
 *
 * <p>v0.4.1 additions:
 * <ul>
 *   <li>Successful offerings cross trust thresholds → grant element
 *       blessing (vanilla status effects, see {@link Blessings}).</li>
 *   <li>Offensive offerings can also trigger a curse on the player
 *       (see {@link Curses}) if the fox is angry enough.</li>
 *   <li>Trust gates: blessing only granted when trust crosses a
 *       multiple of {@link #BLESSING_TRUST_INTERVAL}, preventing
 *       blessing-spam on every single offering.</li>
 * </ul>
 */
public final class FoxOfferingHandler {

    private static final long FOX_COOLDOWN_TICKS = 200;
    private static final int BASE_SPIRIT_REWARD = 3;
    private static final int MAX_TRUST_GAIN = 8;
    private static final int KARMA_PER_OFFENSE = 5;
    private static final int SPIRIT_PENALTY_OFFENSE = 4;

    /** Grant a blessing every time trust crosses one of these milestones. */
    private static final int BLESSING_TRUST_INTERVAL = 20;

    /** If offending fox has Pride above this AND trust below this, apply curse. */
    private static final int CURSE_PRIDE_THRESHOLD = 70;
    private static final int CURSE_TRUST_CEILING = 20;

    private static final Random RANDOM = new Random();

    private FoxOfferingHandler() {}

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return class_1269.field_5811;
            if (!(entity instanceof class_4019 fox)) return class_1269.field_5811;
            if (!(player instanceof class_3222 serverPlayer)) return class_1269.field_5811;
            if (world.field_9236 || !(world instanceof class_3218 serverWorld)) return class_1269.field_5811;
            if (hand != class_1268.field_5808) return class_1269.field_5811;

            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) return class_1269.field_5811;

            return handleOffering(serverPlayer, serverWorld, fox, stack);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxOfferingHandler registered.");
    }

    private static class_1269 handleOffering(
        class_3222 player, class_3218 world, class_4019 fox, class_1799 stack
    ) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        long now = world.method_8510();

        if (now - data.lastFedTickStamp < FOX_COOLDOWN_TICKS) {
            return class_1269.field_5814;
        }

        MinecraftServer server = player.method_5682();
        if (server == null) return class_1269.field_5811;

        Element element = data.element;
        FoxPersonality personality = data.personality;

        if (element.isAccepted(stack.method_7909())) {
            // Kegare check: a polluted player's offerings are often rejected —
            // the spirits sense the stain. 50% failure at TAINTED and above.
            SpiritData.KarmaTier ktier = SpiritData.karmaTier(server, player);
            if (ktier != SpiritData.KarmaTier.PURE && world.field_9229.method_43057() < 0.5f) {
                world.method_14199(net.minecraft.class_2398.field_11251,
                    fox.method_23317(), fox.method_23318() + 0.5, fox.method_23321(), 10, 0.3, 0.3, 0.3, 0.02);
                player.method_7353(net.minecraft.class_2561.method_43470(
                    "The kitsune recoils from your offering — it senses the stain on you.")
                    .method_27695(net.minecraft.class_124.field_1079, net.minecraft.class_124.field_1056), true);
                stack.method_7934(1); // offering consumed but wasted
                return class_1269.field_5812;
            }
            Element.OfferingTier tier = element.offeringTier(stack.method_7909());
            return handleCorrect(player, world, fox, data, element, personality, stack, server, now, tier);
        } else if (element.isOffended(stack.method_7909())) {
            return handleOffense(player, world, fox, data, element, personality, server, now);
        } else {
            return handleNeutral(player, world, fox);
        }
    }

    private static class_1269 handleCorrect(
        class_3222 player, class_3218 world, class_4019 fox, KitsuneData data,
        Element element, FoxPersonality personality, class_1799 stack,
        MinecraftServer server, long now, Element.OfferingTier tier
    ) {
        boolean satisfied = (now - data.lastFedTickStamp < 24000)
            && (data.trustLevel > 50)
            && (personality.greed() > 60);

        if (satisfied) {
            sendMurmur(player, "The fox sniffs the offering, takes it, but does not look at you.", element);
            stack.method_7934(1);
            FoxStorage.store(fox, data.withLastFed(now));
            return class_1269.field_5812;
        }

        double trustFactor = 0.5 + (data.trustLevel / 100.0);
        double greedFactor = 1.0 - (personality.greed() / 200.0);

        // New moon night: the spirits listen closely — extra spirit gain.
        double lunarFactor = com.cutedifficult.event.LunarCycleHandler.isNewMoon(world) ? 1.5 : 1.0;

        // Astrology: sign-of-day / alignment / comet multiplier for this element.
        double astroFactor = com.cutedifficult.event.AstrologyHandler.spiritMultiplier(element);

        // Retrograde: the spirits may misread a perfectly good offering and
        // take it as an insult. Players will hate this. That's the point.
        // Tense aspect on this element's celestial body may misfire the offering.
        if (com.cutedifficult.event.AstrologyHandler.offeringMisfire(element)) {
            player.method_7353(class_2561.method_43470("The stars are wrong for this element. The kitsune recoils — your gift felt like a slight.")
                .method_27695(class_124.field_1079, class_124.field_1056), true);
            return handleOffense(player, world, fox, data, element, personality, server, now);
        }

        int spiritGain = Math.max(1, (int) Math.round(
            BASE_SPIRIT_REWARD * trustFactor * greedFactor * tier.multiplier * lunarFactor * astroFactor));

        SpiritData.add(server, player, element, spiritGain);

        int trustGain = Math.max(1, (int) Math.round(
            MAX_TRUST_GAIN * (1.0 - personality.trauma() / 200.0) * tier.multiplier));
        int oldTrust = data.trustLevel;
        int newTrust = oldTrust + trustGain;
        KitsuneData updated = data.withTrust(newTrust).withLastFed(now);
        FoxStorage.store(fox, updated);

        stack.method_7934(1);

        // Tier-scaled visual feedback — premium offerings feel special.
        int particleCount = tier == Element.OfferingTier.PREMIUM ? 20
            : (tier == Element.OfferingTier.STANDARD ? 8 : 4);
        world.method_14199(
            class_2398.field_11211,
            fox.method_23317(), fox.method_23318() + 0.6, fox.method_23321(),
            particleCount, 0.3, 0.3, 0.3, 0.1
        );
        if (tier == Element.OfferingTier.PREMIUM) {
            world.method_14199(class_2398.field_11220,
                fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(), 15, 0.4, 0.4, 0.4, 0.2);
        }
        world.method_43128(
            null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_18060,
            class_3419.field_15254,
            1.0f, 1.0f + RANDOM.nextFloat() * 0.2f
        );

        String murmur = switch (tier) {
            case PREMIUM -> "The fox's eyes widen. This is a treasure. It will not forget this.";
            case CHEAP -> "The fox nibbles the humble offering. A small kindness, noted.";
            default -> "The fox accepts your offering. Something in the air shifts.";
        };
        sendMurmur(player, murmur, element);

        // Blessing milestone: cross a multiple of BLESSING_TRUST_INTERVAL.
        int oldMilestone = oldTrust / BLESSING_TRUST_INTERVAL;
        int newMilestone = updated.trustLevel / BLESSING_TRUST_INTERVAL;
        if (newMilestone > oldMilestone) {
            Blessings.grant(player, element, data.tails);
            sendMurmur(player,
                "A warmth settles over you. The kitsune of " + element.kamiName() + " favors you.",
                element
            );
            world.method_43128(
                null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
                class_3417.field_14703,
                class_3419.field_15254,
                0.6f, 1.4f
            );
        }

        return class_1269.field_5812;
    }

    private static class_1269 handleOffense(
        class_3222 player, class_3218 world, class_4019 fox, KitsuneData data,
        Element element, FoxPersonality personality,
        MinecraftServer server, long now
    ) {
        boolean offended = RANDOM.nextInt(100) < personality.pride();
        if (!offended) {
            sendMurmur(player, "The fox sniffs the offering, then walks away.", element);
            FoxStorage.store(fox, data.withLastFed(now));
            return class_1269.field_5811;
        }

        SpiritData.add(server, player, element, -SPIRIT_PENALTY_OFFENSE);
        SpiritData.addKarma(server, player, KARMA_PER_OFFENSE);
        KitsuneData updated = data.withTrust(data.trustLevel - 10).withLastFed(now);
        FoxStorage.store(fox, updated);

        world.method_14199(
            class_2398.field_11231,
            fox.method_23317(), fox.method_23318() + 0.6, fox.method_23321(),
            8, 0.3, 0.3, 0.3, 0.1
        );
        world.method_43128(
            null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_18265,
            class_3419.field_15254,
            1.0f, 0.9f
        );

        sendMurmur(player, "The fox bares its teeth. You have offended it.", element);

        // Curse trigger: only proud, distrustful foxes curse the player.
        if (personality.pride() >= CURSE_PRIDE_THRESHOLD
            && updated.trustLevel <= CURSE_TRUST_CEILING) {
            Curses.inflict(player, element, data.tails);
            sendMurmur(player,
                "You feel something cold settle into your bones. The kitsune has cursed you.",
                element
            );
            world.method_43128(
                null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
                class_3417.field_14688,
                class_3419.field_15254,
                0.7f, 1.2f
            );
        }

        return class_1269.field_5814;
    }

    private static class_1269 handleNeutral(
        class_3222 player, class_3218 world, class_4019 fox
    ) {
        world.method_14199(
            class_2398.field_11251,
            fox.method_23317(), fox.method_23318() + 0.6, fox.method_23321(),
            2, 0.1, 0.1, 0.1, 0.0
        );
        return class_1269.field_5811;
    }

    private static void sendMurmur(class_3222 player, String message, Element element) {
        player.method_7353(
            class_2561.method_43470(message).method_27695(element.color(), class_124.field_1056),
            true
        );
    }
}
