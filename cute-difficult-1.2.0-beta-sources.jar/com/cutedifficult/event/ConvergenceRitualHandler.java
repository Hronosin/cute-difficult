package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The hidden Rite of the Nine. During a {@link AstrologyHandler#isGreatConvergence
 * Great Convergence}, a player who drops one PREMIUM offering of every one of the
 * nine elements together (within a small radius) consummates the rite.
 *
 * <p>This is never documented in-game — it's discovered by the kind of player
 * who tracks the ephemeris, notices the "a rite is possible" line, and
 * experiments. The reward is permanent and significant: the Mark of the Nine,
 * granting a small standing boost to ALL nine spirits at once, repeatable only
 * on future convergences.
 *
 * <p>Detection runs cheaply: only while a convergence is active, and only
 * scans dropped items near players every second.
 */
public final class ConvergenceRitualHandler {

    private static long tickCounter = 0;

    private ConvergenceRitualHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            tickCounter++;
            if (tickCounter % 20 != 0) return; // once a second
            if (!AstrologyHandler.isGreatConvergence(AstrologyHandler.now())) return;

            for (class_3222 player : server.method_3760().method_14571()) {
                if (!(player.method_37908() instanceof class_3218 world)) continue;
                checkRiteNear(world, player);
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] ConvergenceRitualHandler registered.");
    }

    private static void checkRiteNear(class_3218 world, class_3222 player) {
        class_238 box = new class_238(player.method_24515()).method_1014(3);
        var drops = world.method_8390(class_1542.class, box, ie -> true);
        if (drops.isEmpty()) return;

        // Collect which elements' PREMIUM offerings are present among the drops.
        Set<Element> present = new HashSet<>();
        for (class_1542 ie : drops) {
            class_1792 item = ie.method_6983().method_7909();
            for (Element e : Element.values()) {
                if (e.premiumOffering() == item) present.add(e);
            }
        }

        if (present.size() < Element.values().length) return; // need all nine

        // Rite consummated — consume one of each premium offering.
        Set<Element> consumed = new HashSet<>();
        for (class_1542 ie : drops) {
            class_1792 item = ie.method_6983().method_7909();
            for (Element e : Element.values()) {
                if (e.premiumOffering() == item && !consumed.contains(e)) {
                    ie.method_6983().method_7934(1);
                    if (ie.method_6983().method_7960()) ie.method_31472();
                    consumed.add(e);
                }
            }
        }

        grantMarkOfTheNine(world, player);
    }

    private static void grantMarkOfTheNine(class_3218 world, class_3222 player) {
        // Permanent-ish standing boost: +5 spirit to every element at once.
        for (Element e : Element.values()) {
            SpiritData.add(world.method_8503(), player, e, 5);
        }

        // A keepsake item: an enchanted-glint nether star renamed as the Mark.
        class_1799 mark = new class_1799(class_1802.field_8137);
        mark.method_57379(net.minecraft.class_9334.field_49631,
            class_2561.method_43470("Mark of the Nine").method_27695(class_124.field_1065, class_124.field_1067));
        if (!player.method_31548().method_7394(mark)) {
            player.method_7328(mark, false);
        }

        // Blessing burst.
        player.method_6092(new class_1293(
            class_1294.field_5924, 200, 2, false, true, true));
        player.method_6092(new class_1293(
            class_1294.field_5898, 1200, 2, false, true, true));

        world.method_14199(class_2398.field_11220,
            player.method_23317(), player.method_23318() + 1, player.method_23321(), 80, 0.6, 1.0, 0.6, 0.4);
        world.method_8396(null, player.method_24515(),
            class_3417.field_14891, class_3419.field_15248, 1.2f, 1.0f);

        player.method_7353(class_2561.method_43470("THE RITE OF THE NINE IS COMPLETE. Inari's whole house turns to face you.")
            .method_27695(class_124.field_1065, class_124.field_1067), false);
        player.method_7353(class_2561.method_43470("All nine spirits rise a little. The Mark of the Nine is yours.")
            .method_27695(class_124.field_1054, class_124.field_1056), false);

        CuteDifficult.LOGGER.info("[CuteDifficult] {} completed the Rite of the Nine.",
            player.method_5477().getString());
    }
}
