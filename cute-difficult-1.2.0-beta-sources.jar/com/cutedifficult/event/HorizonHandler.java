package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.world.ModDimensions;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8111;
import org.joml.Vector3f;

import java.util.Random;

/**
 * The Horizon's cosmic ambience. Instead of decoration glued to the player, the
 * void is populated with persistent celestial OBJECTS pinned to world space —
 * stars, nebulae, and singularities sit on a deterministic grid, so flying
 * toward one actually approaches it. Comets are the exception: they streak
 * across the player's view.
 *
 * <p>Performance: objects live on a coarse grid (every {@link #GRID} blocks).
 * Each tick we only consider grid cells within {@link #VIEW} of each Horizon
 * player and render the object that cell deterministically contains (if any).
 */
public final class HorizonHandler {

    private static long tick = 0;
    private static final Random COMET_RNG = new Random();

    /** Spacing of the cosmic object grid, in blocks. */
    private static final int GRID = 48;
    /** How far around the player we render objects. */
    private static final int VIEW = 96;

    private HorizonHandler() {}

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity.method_37908().method_27983() != ModDimensions.HORIZON) return true;
            if (source.method_49708(class_8111.field_42345)) return false;
            return true;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            class_3218 horizon = server.method_3847(ModDimensions.HORIZON);
            if (horizon == null) return;
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_37908() != horizon) continue;
                renderCosmos(horizon, player);
                if (tick % 30 == 0 && COMET_RNG.nextInt(3) == 0) {
                    spawnComet(horizon, player);
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] HorizonHandler registered.");
    }

    /** Render all world-pinned cosmic objects near the player. */
    private static void renderCosmos(class_3218 world, class_3222 player) {
        int px = (int) Math.floor(player.method_23317());
        int py = (int) Math.floor(player.method_23318());
        int pz = (int) Math.floor(player.method_23321());

        int gx0 = Math.floorDiv(px - VIEW, GRID);
        int gx1 = Math.floorDiv(px + VIEW, GRID);
        int gy0 = Math.floorDiv(py - VIEW, GRID);
        int gy1 = Math.floorDiv(py + VIEW, GRID);
        int gz0 = Math.floorDiv(pz - VIEW, GRID);
        int gz1 = Math.floorDiv(pz + VIEW, GRID);

        for (int gx = gx0; gx <= gx1; gx++) {
            for (int gy = gy0; gy <= gy1; gy++) {
                for (int gz = gz0; gz <= gz1; gz++) {
                    renderCell(world, player, gx, gy, gz);
                }
            }
        }
    }

    /**
     * A grid cell deterministically either holds nothing or one cosmic object,
     * decided by a hash of its coordinates so the cosmos is stable across
     * visits (and identical for everyone on a server).
     */
    private static void renderCell(class_3218 world, class_3222 player, int gx, int gy, int gz) {
        long seed = hash(gx, gy, gz);
        // ~45% of cells are empty void.
        int kind = (int) (seed % 100);
        if (kind < 45) return;

        // Object centre, jittered within the cell deterministically.
        double ox = gx * GRID + (seed >> 8 & 31);
        double oy = gy * GRID + (seed >> 13 & 31);
        double oz = gz * GRID + (seed >> 18 & 31);

        // Throttle by object type so we don't spam thousands of particles.
        if (kind < 80) {
            // STAR — a single steady mote (most common).
            if (tick % 12 == 0) {
                world.method_14166(player, class_2398.field_11207, true,
                        ox, oy, oz, 1, 0.0, 0.0, 0.0, 0.0);
            }
        } else if (kind < 92) {
            // NEBULA — a soft colored cloud, color seeded by the cell.
            if (tick % 10 == 0) {
                renderNebula(world, player, ox, oy, oz, seed);
            }
        } else {
            // SINGULARITY — a spiral of particles drawn inward to a dark center.
            if (tick % 4 == 0) {
                renderSingularity(world, player, ox, oy, oz);
            }
        }
    }

    private static void renderNebula(class_3218 world, class_3222 player,
                                     double x, double y, double z, long seed) {
        float r = ((seed >> 24 & 0xFF) / 255f) * 0.6f + 0.2f;
        float g = ((seed >> 32 & 0xFF) / 255f) * 0.6f + 0.2f;
        float b = ((seed >> 40 & 0xFF) / 255f) * 0.6f + 0.4f;
        class_2390 dust = new class_2390(new Vector3f(r, g, b), 2.5f);
        world.method_14166(player, dust, true,
                x, y, z, 12, 2.5, 2.5, 2.5, 0.0);
    }

    private static void renderSingularity(class_3218 world, class_3222 player,
                                          double cx, double cy, double cz) {
        // Inward spiral: particles on an Archimedean spiral pulled toward center,
        // with velocity pointing in so they appear to be sucked in.
        double phase = (tick % 80) * (Math.PI / 40.0);
        int arms = 16;
        for (int i = 0; i < arms; i++) {
            double t = i / (double) arms;
            double angle = phase + t * Math.PI * 4;
            double radius = 4.0 * (1.0 - t); // spiral inward
            double sx = cx + Math.cos(angle) * radius;
            double sy = cy + Math.sin(t * Math.PI) * 0.5;
            double sz = cz + Math.sin(angle) * radius;
            // Velocity toward center for the "accretion" feel.
            class_243 toCenter = new class_243(cx - sx, cy - sy, cz - sz).method_1029().method_1021(0.08);
            world.method_14166(player, class_2398.field_11214, true,
                    sx, sy, sz, 0, toCenter.field_1352, toCenter.field_1351, toCenter.field_1350, 1.0);
        }
        // A dark, dense core.
        world.method_14166(player, class_2398.field_11233, true,
                cx, cy, cz, 3, 0.2, 0.2, 0.2, 0.0);
        world.method_14166(player, class_2398.field_23190, true,
                cx, cy, cz, 4, 0.4, 0.4, 0.4, 0.02);
    }

    /** A comet that streaks across the player's view and fades. */
    private static void spawnComet(class_3218 world, class_3222 player) {
        // Start off to one side, high up, and streak past.
        class_243 look = player.method_5720();
        class_243 start = player.method_19538().method_1031(
                (COMET_RNG.nextDouble() - 0.5) * 60,
                20 + COMET_RNG.nextDouble() * 20,
                (COMET_RNG.nextDouble() - 0.5) * 60);
        class_243 dir = new class_243(
                (COMET_RNG.nextDouble() - 0.5),
                -0.3 - COMET_RNG.nextDouble() * 0.3,
                (COMET_RNG.nextDouble() - 0.5)).method_1029();
        // Draw the trail as a line of particles.
        for (int i = 0; i < 24; i++) {
            class_243 p = start.method_1019(dir.method_1021(i * 1.2));
            world.method_14166(player, class_2398.field_11207, true,
                    p.field_1352, p.field_1351, p.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            if (i % 3 == 0) {
                world.method_14166(player, class_2398.field_11248, true,
                        p.field_1352, p.field_1351, p.field_1350, 1, 0.1, 0.1, 0.1, 0.0);
            }
        }
    }

    /** Stable per-cell hash (positive). */
    private static long hash(int x, int y, int z) {
        long h = 1125899906842597L;
        h = 31 * h + x;
        h = 31 * h + y;
        h = 31 * h + z;
        h ^= (h >>> 29);
        h *= 0xBF58476D1CE4E5B9L;
        h ^= (h >>> 32);
        return Math.abs(h);
    }
}