package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kitsune grow tails over time. A kitsune accumulates "growth" each tick; when
 * it crosses a threshold it gains a tail (up to nine — Kyuubi). Growth is
 * passive by default but a recently-fed kitsune grows <b>50% faster</b>, so a
 * cared-for fox reaches Kyuubi in ~10 in-game days versus ~15 left alone.
 *
 * <p>Progress is tracked here (keyed by fox UUID) rather than in KitsuneData, to
 * avoid touching the persisted data schema. A fox's current tail count is the
 * source of truth on reload; in-memory progress simply resumes from the floor
 * of its current tier, so a restart costs at most a fraction of one tail.
 */
public final class KitsuneGrowthHandler {

    /** Effective ticks needed per tail (1.25 in-game days when fed). */
    private static final long TICKS_PER_TAIL = 30000;
    /** A fox counts as "recently fed" for this many ticks after eating. */
    private static final long FED_WINDOW = 6000; // 5 minutes
    /** Growth multiplier while recently fed. */
    private static final double FED_BONUS = 1.5;

    /** Accumulated growth progress per fox (effective ticks). */
    private static final Map<UUID, Double> PROGRESS = new ConcurrentHashMap<>();

    private static long tick = 0;

    private KitsuneGrowthHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tick++;
            // Check growth a few times a second is plenty; accumulate per check.
            if (tick % 10 != 0) return;

            for (class_3218 world : server.method_3738()) {
                for (class_4019 fox : world.method_8390(class_4019.class,
                        new net.minecraft.class_238(
                            -30000000, world.method_31607(), -30000000,
                            30000000, world.method_31600(), 30000000),
                        f -> f instanceof com.cutedifficult.entity.KitsuneEntity && f.method_5805())) {
                    tickFox(world, fox);
                }
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] KitsuneGrowthHandler registered.");
    }

    private static void tickFox(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.peekCache(fox);
        if (data == null) return;
        if (data.tails >= KitsuneData.MAX_TAILS) return; // already Kyuubi

        UUID id = fox.method_5667();
        // Seed progress at the floor of the current tier so a fresh load resumes
        // sensibly (a 3-tail fox starts this session's progress at the 3-tail mark).
        double progress = PROGRESS.computeIfAbsent(id,
            u -> (double) (data.tails - 1) * TICKS_PER_TAIL);

        // We tick every 10 ticks, so add 10 effective ticks (×bonus if fed).
        boolean recentlyFed = (world.method_8510() - data.lastFedTickStamp) < FED_WINDOW
            && data.lastFedTickStamp > 0;
        double gain = 10.0 * (recentlyFed ? FED_BONUS : 1.0);
        progress += gain;
        PROGRESS.put(id, progress);

        // How many tails does this much progress justify?
        int earnedTails = Math.min(KitsuneData.MAX_TAILS, 1 + (int) (progress / TICKS_PER_TAIL));
        if (earnedTails > data.tails) {
            growTail(world, fox, data, earnedTails);
        }
    }

    private static void growTail(class_3218 world, class_4019 fox, KitsuneData data, int newTails) {
        KitsuneData updated = data.withTails(newTails);
        FoxStorage.store(fox, updated);
        com.cutedifficult.spirit.FoxStats.applyHpForTails(fox, newTails);

        // A quiet flourish each time a tail grows.
        world.method_14199(class_2398.field_11211,
            fox.method_23317(), fox.method_23318() + 0.6, fox.method_23321(), 12, 0.3, 0.4, 0.3, 0.05);
        if (newTails >= KitsuneData.MAX_TAILS) {
            // Becoming Kyuubi is a moment.
            world.method_14199(class_2398.field_11220,
                fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(), 40, 0.5, 0.6, 0.5, 0.2);
            world.method_8396(null, fox.method_24515(),
                class_3417.field_14891, class_3419.field_15254, 1.0f, 1.2f);
        } else {
            world.method_8396(null, fox.method_24515(),
                class_3417.field_18056, class_3419.field_15254, 0.8f, 1.3f);
        }
        CuteDifficult.LOGGER.info("[CuteDifficult] Kitsune {} grew to {} tails.",
            fox.method_5667().toString().substring(0, 8), newTails);
    }

    /** Forget progress for a removed fox (called opportunistically). */
    public static void forget(UUID id) {
        PROGRESS.remove(id);
    }
}
