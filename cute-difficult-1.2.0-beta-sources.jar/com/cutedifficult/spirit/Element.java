package com.cutedifficult.spirit;

import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

/**
 * The nine spiritual elements. Each kitsune belongs to exactly one.
 *
 * <p>Each element defines:
 * <ul>
 *   <li>Kami name, short id, flavor text, display color.</li>
 *   <li>Tiered offerings: a CHEAP item (small reward, easy to get), a
 *       STANDARD item (the classic mid reward), and a PREMIUM item (large
 *       reward, an endgame/rare resource). The offering handler scales
 *       trust/spirit gain by the tier multiplier.</li>
 *   <li>Offensive offerings: items that offend this element and apply a
 *       Lesser Mark / trust penalty.</li>
 * </ul>
 */
public enum Element {
    KASAI(
        "Kasai", "fire",
        "The element of consumption, sun, and forge. Foxes of Kasai burn with constant inner heat.",
        class_124.field_1061,
        class_1802.field_8713, class_1802.field_8135, class_1802.field_8894,
        new class_1792[]{class_1802.field_8705, class_1802.field_8426, class_1802.field_8178, class_1802.field_8543}
    ),
    MIZU(
        "Mizu", "water",
        "The element of flow, depths, and reflection. Mizu foxes seek still waters.",
        class_124.field_1075,
        class_1802.field_8429, class_1802.field_8846, class_1802.field_8207,
        new class_1792[]{class_1802.field_8135, class_1802.field_8183, class_1802.field_8054}
    ),
    DAICHI(
        "Daichi", "earth",
        "The element of stone, root, and patience. Daichi foxes are heavy-pawed and slow to anger.",
        class_124.field_1065,
        class_1802.field_27020, class_1802.field_27063, class_1802.field_27065,
        new class_1792[]{class_1802.field_8153, class_1802.field_8614}
    ),
    KAZE(
        "Kaze", "wind",
        "The element of breath, height, and sudden change. Kaze foxes are restless.",
        class_124.field_1068,
        class_1802.field_8153, class_1802.field_8614, class_1802.field_8833,
        new class_1792[]{class_1802.field_20391, class_1802.field_20412, class_1802.field_8831}
    ),
    KAMINARI(
        "Kaminari", "thunder",
        "The element of storms and revelation. Kaminari foxes appear only with rain on the horizon.",
        class_124.field_1054,
        class_1802.field_27022, class_1802.field_27051, class_1802.field_8547,
        new class_1792[]{class_1802.field_8745, class_1802.field_19044, class_1802.field_19059}
    ),
    MORI(
        "Mori", "forest",
        "The element of green life. Mori foxes refuse meat — they remember every grain of pollen.",
        class_124.field_1060,
        class_1802.field_8317, class_1802.field_16998, class_1802.field_28659,
        new class_1792[]{class_1802.field_8046, class_1802.field_8389, class_1802.field_8726, class_1802.field_8748, class_1802.field_8504, class_1802.field_8511}
    ),
    KORI(
        "Kori", "ice",
        "The element of stillness and preservation. Kori foxes do not blink.",
        class_124.field_1078,
        class_1802.field_8543, class_1802.field_8178, class_1802.field_8081,
        new class_1792[]{class_1802.field_8135, class_1802.field_8183, class_1802.field_8187, class_1802.field_8814}
    ),
    YUREI(
        "Yurei", "spirit",
        "The element of memory and what remains. Yurei foxes can only be seen by the awakened.",
        class_124.field_1076,
        class_1802.field_21999, class_1802.field_38746, class_1802.field_38747,
        new class_1792[]{class_1802.field_8463, class_1802.field_8367}
    ),
    TENGOKU(
        "Tengoku", "sky",
        "The element of celestial fire. Tengoku foxes look only at the stars.",
        class_124.field_1075,
        class_1802.field_8601, class_1802.field_8613, class_1802.field_8137,
        new class_1792[]{class_1802.field_8328, class_1802.field_8067, class_1802.field_21999}
    );

    /** Offering quality tier with its reward multiplier. */
    public enum OfferingTier {
        NONE(0.0),
        CHEAP(0.5),
        STANDARD(1.0),
        PREMIUM(2.5);

        public final double multiplier;
        OfferingTier(double multiplier) { this.multiplier = multiplier; }
    }

    private final String kamiName;
    private final String shortName;
    private final String flavor;
    private final class_124 color;
    private final class_1792 cheapOffering;
    private final class_1792 standardOffering;
    private final class_1792 premiumOffering;
    private final class_1792[] offensiveOfferings;

    Element(
        String kamiName,
        String shortName,
        String flavor,
        class_124 color,
        class_1792 cheapOffering,
        class_1792 standardOffering,
        class_1792 premiumOffering,
        class_1792[] offensiveOfferings
    ) {
        this.kamiName = kamiName;
        this.shortName = shortName;
        this.flavor = flavor;
        this.color = color;
        this.cheapOffering = cheapOffering;
        this.standardOffering = standardOffering;
        this.premiumOffering = premiumOffering;
        this.offensiveOfferings = offensiveOfferings;
    }

    public String kamiName() { return kamiName; }
    public String shortName() { return shortName; }
    public String flavor() { return flavor; }
    public class_124 color() { return color; }

    public class_1792 cheapOffering() { return cheapOffering; }
    public class_1792 standardOffering() { return standardOffering; }
    public class_1792 premiumOffering() { return premiumOffering; }

    /** Back-compat: the "canonical" offering shown in codex etc. */
    public class_1792 correctOffering() { return standardOffering; }

    public class_1792[] offensiveOfferings() { return offensiveOfferings; }

    /** Which tier does this item represent for this element? */
    public OfferingTier offeringTier(class_1792 item) {
        if (item == premiumOffering) return OfferingTier.PREMIUM;
        if (item == standardOffering) return OfferingTier.STANDARD;
        if (item == cheapOffering) return OfferingTier.CHEAP;
        return OfferingTier.NONE;
    }

    /** Is this item any accepted offering (cheap/standard/premium)? */
    public boolean isAccepted(class_1792 item) {
        return offeringTier(item) != OfferingTier.NONE;
    }

    public boolean isOffended(class_1792 item) {
        for (class_1792 bad : offensiveOfferings) {
            if (bad == item) return true;
        }
        return false;
    }

    public static Element fromShortName(String name) {
        for (Element e : values()) {
            if (e.shortName.equalsIgnoreCase(name)) return e;
        }
        return null;
    }

    /** Pick a random element using the given RNG. */
    public static Element random(java.util.Random rng) {
        Element[] all = values();
        return all[rng.nextInt(all.length)];
    }
}
