package com.cutedifficult.spirit;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Stores and reads multiple enhanced-enchant markers on a single item.
 *
 * <p>Previously each item could hold only one marker (a single string in
 * CUSTOM_DATA). That stopped a sword from carrying, say, both the Kasai
 * fire-AOE blessing and the Kaminari lightning blessing. Now we store a
 * compound under {@code cd_enhanced} mapping markerId → level, so any
 * number of different-element blessings can stack on one item.
 *
 * <p>Structure inside CUSTOM_DATA:
 * <pre>
 *   cd_enhanced: {
 *     kasai: 2,
 *     kaminari: 1,
 *     ...
 *   }
 * </pre>
 *
 * <p>Same-element re-application overwrites (keeps the higher level).
 */
public final class EnchantMarkers {

    public static final String ROOT_KEY = "cd_enhanced";

    private EnchantMarkers() {}

    /** Read all markers on an item as markerId → level. Empty if none. */
    public static Map<String, Integer> read(class_1799 stack) {
        Map<String, Integer> out = new LinkedHashMap<>();
        if (stack.method_7960()) return out;
        class_9279 custom = stack.method_57824(class_9334.field_49628);
        if (custom == null) return out;
        class_2487 nbt = custom.method_57461();
        if (!nbt.method_10545(ROOT_KEY)) return out;
        class_2487 root = nbt.method_10562(ROOT_KEY);
        for (String key : root.method_10541()) {
            out.put(key, root.method_10550(key));
        }
        return out;
    }

    /** Does the item carry a marker for this element id? */
    public static boolean has(class_1799 stack, String markerId) {
        return read(stack).containsKey(markerId);
    }

    /** Level for a given marker, or 0 if absent. */
    public static int levelOf(class_1799 stack, String markerId) {
        return read(stack).getOrDefault(markerId, 0);
    }

    /**
     * Add or upgrade a marker on the item. If the same element is already
     * present, keeps the higher level. Returns the modified stack (same
     * instance, mutated).
     */
    public static class_1799 add(class_1799 stack, String markerId, int level) {
        class_9279 custom = stack.method_57825(class_9334.field_49628, class_9279.field_49302);
        class_2487 nbt = custom.method_57461();
        class_2487 root = nbt.method_10545(ROOT_KEY) ? nbt.method_10562(ROOT_KEY) : new class_2487();
        int existing = root.method_10545(markerId) ? root.method_10550(markerId) : 0;
        root.method_10569(markerId, Math.max(existing, level));
        nbt.method_10566(ROOT_KEY, root);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(nbt));
        return stack;
    }
}
