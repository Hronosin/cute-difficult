package com.cutedifficult.spirit;

import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_9015;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;

/**
 * Durable storage for player Spirit (9 elements) and Karma, backed by the
 * world's {@link class_18} (saved in the overworld's data folder) rather
 * than scoreboards. Scoreboards were fragile — visible to players, wiped by
 * commands, and easy to clobber. This keeps the same data invisibly and safely.
 *
 * <p>Keyed by holder name (player UUID string for players). Each record holds
 * the nine element values and a karma value.
 */
public class SpiritState extends class_18 {

    private static final String STATE_ID = "cutedifficult_spirit";

    /** name -> record */
    private final Map<String, Record> records = new HashMap<>();

    public static final class Record {
        public final int[] elements = new int[Element.values().length];
        public int karma = 0;
    }

    public SpiritState() {}

    // ===== Access =====

    public Record getOrCreate(String key) {
        return records.computeIfAbsent(key, k -> new Record());
    }

    public Record peek(String key) {
        return records.get(key);
    }

    // ===== Persistence =====

    @Override
    public class_2487 method_75(class_2487 nbt, net.minecraft.class_7225.class_7874 lookup) {
        class_2487 all = new class_2487();
        for (Map.Entry<String, Record> e : records.entrySet()) {
            class_2487 rec = new class_2487();
            Record r = e.getValue();
            for (int i = 0; i < r.elements.length; i++) {
                rec.method_10569("e" + i, r.elements[i]);
            }
            rec.method_10569("karma", r.karma);
            all.method_10566(e.getKey(), rec);
        }
        nbt.method_10566("records", all);
        return nbt;
    }

    public static SpiritState createFromNbt(class_2487 nbt,
            net.minecraft.class_7225.class_7874 lookup) {
        SpiritState state = new SpiritState();
        class_2487 all = nbt.method_10562("records");
        for (String key : all.method_10541()) {
            class_2487 rec = all.method_10562(key);
            Record r = new Record();
            for (int i = 0; i < r.elements.length; i++) {
                r.elements[i] = rec.method_10550("e" + i);
            }
            r.karma = rec.method_10550("karma");
            state.records.put(key, r);
        }
        return state;
    }

    private static final class_18.class_8645<SpiritState> TYPE =
        new class_18.class_8645<>(SpiritState::new, SpiritState::createFromNbt, null);

    /** Fetch the singleton state from the server (stored on the overworld). */
    public static SpiritState get(MinecraftServer server) {
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        class_26 mgr = overworld.method_17983();
        SpiritState state = mgr.method_17924(TYPE, STATE_ID);
        state.method_80();
        return state;
    }

    /** Stable storage key for a score holder (UUID string for players). */
    public static String keyFor(class_9015 holder) {
        return holder.method_5820();
    }
}
