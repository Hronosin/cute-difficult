package com.cutedifficult.command;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxPersonality;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4019;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Random;

/**
 * Comprehensive debug command tree for v0.3.0+.
 *
 * <p>Top-level: {@code /cd}. Subtrees:
 * <ul>
 *   <li>{@code info} — show player spirit matrix.</li>
 *   <li>{@code spirit &lt;element&gt; [set|add] &lt;n&gt;} — per-element manipulation.</li>
 *   <li>{@code karma [set|add] &lt;n&gt;} — karma manipulation.</li>
 *   <li>{@code reset} — reset player to defaults.</li>
 *   <li>{@code godmode} — max all elements.</li>
 *   <li>{@code hollow} — set all elements to -100.</li>
 *   <li>{@code mode &lt;cruel|peace&gt;} — force mode switch.</li>
 *   <li>{@code fox} — nearest-fox manipulation subtree (info, tails, element,
 *       trust, personality, reroll, summon).</li>
 * </ul>
 *
 * <p>Most commands require permission level 2 (op). Read-only commands
 * ({@code info}, {@code fox info}) are open.
 *
 * <p>Fox commands operate on the <b>nearest fox within 16 blocks</b> of
 * the caller. We could let the player target one via raycast or selector,
 * but "nearest" is the fastest dev workflow.
 */
public final class CdCommand {

    private static final double FOX_SEARCH_RADIUS = 16.0;
    private static final Random RANDOM = new Random();

    private static final SuggestionProvider<class_2168> ELEMENT_SUGGESTIONS = (ctx, builder) -> {
        for (Element e : Element.values()) builder.suggest(e.shortName());
        return builder.buildFuture();
    };

    private static final SuggestionProvider<class_2168> PERSONALITY_TRAIT_SUGGESTIONS = (ctx, builder) -> {
        for (String t : new String[]{"pride", "trust", "curiosity", "memory", "greed", "sensitivity", "trauma"}) {
            builder.suggest(t);
        }
        return builder.buildFuture();
    };

    private static final SuggestionProvider<class_2168> MODE_SUGGESTIONS = (ctx, builder) -> {
        builder.suggest("cruel");
        builder.suggest("peace");
        return builder.buildFuture();
    };

    private static final SuggestionProvider<class_2168> MOON_SUGGESTIONS = (ctx, builder) -> {
        for (com.cutedifficult.spirit.SpecialMoon m : com.cutedifficult.spirit.SpecialMoon.values()) {
            builder.suggest(m.id());
        }
        return builder.buildFuture();
    };

    private static final SuggestionProvider<class_2168> WEATHER_SUGGESTIONS = (ctx, builder) -> {
        for (com.cutedifficult.spirit.WeatherEvent w : com.cutedifficult.spirit.WeatherEvent.values()) {
            builder.suggest(w.id());
        }
        return builder.buildFuture();
    };

    private static final SuggestionProvider<class_2168> ENCHANT_SUGGESTIONS = (ctx, builder) -> {
        for (com.cutedifficult.spirit.EnhancedEnchant e : com.cutedifficult.spirit.EnhancedEnchant.values()) {
            builder.suggest(e.markerId);
        }
        return builder.buildFuture();
    };

    private CdCommand() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("cd")
                .then(class_2170.method_9247("info").executes(CdCommand::showPlayerInfo))

                // /cd spirit <element> [show | set <n> | add <n>]
                .then(class_2170.method_9247("spirit")
                    .then(class_2170.method_9244("element", StringArgumentType.word())
                        .suggests(ELEMENT_SUGGESTIONS)
                        .executes(ctx -> {
                            Element el = resolveElement(ctx.getSource(), StringArgumentType.getString(ctx, "element"));
                            return el == null ? 0 : showElement(ctx.getSource(), el);
                        })
                        .then(class_2170.method_9247("set").requires(op())
                            .then(class_2170.method_9244("value", IntegerArgumentType.integer(-100, 100))
                                .executes(ctx -> {
                                    Element el = resolveElement(ctx.getSource(), StringArgumentType.getString(ctx, "element"));
                                    return el == null ? 0 : setElement(ctx.getSource(), el,
                                        IntegerArgumentType.getInteger(ctx, "value"));
                                })))
                        .then(class_2170.method_9247("add").requires(op())
                            .then(class_2170.method_9244("delta", IntegerArgumentType.integer(-200, 200))
                                .executes(ctx -> {
                                    Element el = resolveElement(ctx.getSource(), StringArgumentType.getString(ctx, "element"));
                                    return el == null ? 0 : addElement(ctx.getSource(), el,
                                        IntegerArgumentType.getInteger(ctx, "delta"));
                                })))))

                // /cd karma [show | set <n> | add <n>]
                .then(class_2170.method_9247("karma")
                    .executes(ctx -> showKarma(ctx.getSource()))
                    .then(class_2170.method_9247("set").requires(op())
                        .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                            .executes(ctx -> setKarma(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "value")))))
                    .then(class_2170.method_9247("add").requires(op())
                        .then(class_2170.method_9244("delta", IntegerArgumentType.integer())
                            .executes(ctx -> addKarma(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "delta"))))))

                // /cd reset
                .then(class_2170.method_9247("reset").requires(op())
                    .executes(CdCommand::resetPlayer))

                // /cd godmode
                .then(class_2170.method_9247("godmode").requires(op())
                    .executes(CdCommand::godmodePlayer))

                // /cd hollow
                .then(class_2170.method_9247("hollow").requires(op())
                    .executes(CdCommand::hollowPlayer))

                // /cd mode <cruel|peace>
                .then(class_2170.method_9247("mode").requires(op())
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(MODE_SUGGESTIONS)
                        .executes(ctx -> setMode(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))

                // /cd moon <list | current | clear | <type>>
                .then(class_2170.method_9247("moon")
                    .then(class_2170.method_9247("list").executes(ctx -> moonList(ctx.getSource())))
                    .then(class_2170.method_9247("current").executes(ctx -> moonCurrent(ctx.getSource())))
                    .then(class_2170.method_9247("clear").requires(op())
                        .executes(ctx -> moonClear(ctx.getSource())))
                    .then(class_2170.method_9244("type", StringArgumentType.word()).requires(op())
                        .suggests(MOON_SUGGESTIONS)
                        .executes(ctx -> moonForce(ctx.getSource(), StringArgumentType.getString(ctx, "type")))))

                // /cd weather <list | current | clear | <type>>
                .then(class_2170.method_9247("weather")
                    .then(class_2170.method_9247("list").executes(ctx -> weatherList(ctx.getSource())))
                    .then(class_2170.method_9247("current").executes(ctx -> weatherCurrent(ctx.getSource())))
                    .then(class_2170.method_9247("clear").requires(op())
                        .executes(ctx -> weatherClear(ctx.getSource())))
                    .then(class_2170.method_9244("type", StringArgumentType.word()).requires(op())
                        .suggests(WEATHER_SUGGESTIONS)
                        .executes(ctx -> weatherForce(ctx.getSource(), StringArgumentType.getString(ctx, "type")))))

                // /cd sky  — show the ephemeris (positions, aspects, forecast)
                .then(class_2170.method_9247("sky")
                    .executes(ctx -> showSky(ctx.getSource())))

                // /cd astrology shift <days> | reset  — admin time-shift for testing
                .then(class_2170.method_9247("astrology")
                    .then(class_2170.method_9247("shift").requires(op())
                        .then(class_2170.method_9244("days", IntegerArgumentType.integer(-1000, 1000))
                            .executes(ctx -> astroShift(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "days")))))
                    .then(class_2170.method_9247("reset").requires(op())
                        .executes(ctx -> astroReset(ctx.getSource()))))

                // /cd fox <info | tails N | element X | trust N | personality T N | reroll | summon X N>
                .then(class_2170.method_9247("fox")
                    .then(class_2170.method_9247("info").executes(CdCommand::foxInfo))
                    .then(class_2170.method_9247("stage").executes(CdCommand::foxStage))
                    .then(class_2170.method_9247("tails").requires(op())
                        .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, KitsuneData.MAX_TAILS))
                            .executes(ctx -> foxSetTails(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))))
                    .then(class_2170.method_9247("element").requires(op())
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(ELEMENT_SUGGESTIONS)
                            .executes(ctx -> foxSetElement(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
                    .then(class_2170.method_9247("trust").requires(op())
                        .then(class_2170.method_9244("value", IntegerArgumentType.integer(0, 100))
                            .executes(ctx -> foxSetTrust(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "value")))))
                    .then(class_2170.method_9247("personality").requires(op())
                        .then(class_2170.method_9244("trait", StringArgumentType.word())
                            .suggests(PERSONALITY_TRAIT_SUGGESTIONS)
                            .then(class_2170.method_9244("value", IntegerArgumentType.integer(0, 100))
                                .executes(ctx -> foxSetPersonality(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "trait"),
                                    IntegerArgumentType.getInteger(ctx, "value"))))))
                    .then(class_2170.method_9247("reroll").requires(op())
                        .executes(CdCommand::foxReroll))
                    .then(class_2170.method_9247("summon").requires(op())
                        .then(class_2170.method_9244("element", StringArgumentType.word())
                            .suggests(ELEMENT_SUGGESTIONS)
                            .then(class_2170.method_9244("tails", IntegerArgumentType.integer(1, KitsuneData.MAX_TAILS))
                                .executes(ctx -> foxSummon(ctx.getSource(),
                                    StringArgumentType.getString(ctx, "element"),
                                    IntegerArgumentType.getInteger(ctx, "tails")))))))
                .then(class_2170.method_9247("enchant").requires(op())
                    .then(class_2170.method_9244("marker", StringArgumentType.word())
                        .suggests(ENCHANT_SUGGESTIONS)
                        .executes(ctx -> giveEnchant(ctx.getSource(),
                            StringArgumentType.getString(ctx, "marker"), 1))
                        .then(class_2170.method_9244("level", IntegerArgumentType.integer(1, 5))
                            .executes(ctx -> giveEnchant(ctx.getSource(),
                                StringArgumentType.getString(ctx, "marker"),
                                IntegerArgumentType.getInteger(ctx, "level"))))))
            );
        });
    }

    // ===== Helpers =====

    private static java.util.function.Predicate<class_2168> op() {
        return src -> src.method_9259(2);
    }

    private static Element resolveElement(class_2168 src, String name) {
        for (Element e : Element.values()) {
            if (e.shortName().equalsIgnoreCase(name) || e.name().equalsIgnoreCase(name)) return e;
        }
        src.method_9213(class_2561.method_43470("Unknown element: " + name
            + ". Valid: fire, water, earth, wind, thunder, forest, ice, spirit, sky"));
        return null;
    }

    /** Find the nearest fox to the command sender within FOX_SEARCH_RADIUS. */
    private static class_4019 findNearestFox(class_2168 src) {
        if (!(src.method_9228() instanceof class_3222 player)) {
            src.method_9213(class_2561.method_43470("Must be run as a player."));
            return null;
        }
        class_3218 world = player.method_51469();
        class_238 searchBox = player.method_5829().method_1014(FOX_SEARCH_RADIUS);
        List<class_4019> nearby = world.method_8390(class_4019.class, searchBox, f -> f.method_5805());
        if (nearby.isEmpty()) {
            src.method_9213(class_2561.method_43470("No fox within " + (int)FOX_SEARCH_RADIUS + " blocks."));
            return null;
        }
        class_4019 nearest = nearby.get(0);
        double bestDist = nearest.method_5858(player);
        for (class_4019 f : nearby) {
            double d = f.method_5858(player);
            if (d < bestDist) {
                bestDist = d;
                nearest = f;
            }
        }
        return nearest;
    }

    // ===== Player info / spirit =====

    private static int showPlayerInfo(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) {
            src.method_9213(class_2561.method_43470("Must be run as a player."));
            return 0;
        }
        MinecraftServer server = src.method_9211();

        src.method_9226(() -> class_2561.method_43470("=== Spirit Matrix ===").method_27692(class_124.field_1065), false);
        for (Element e : Element.values()) {
            int v = SpiritData.get(server, player, e);
            src.method_9226(() -> class_2561.method_43470("  " + e.kamiName() + ": ").method_27692(e.color())
                .method_10852(class_2561.method_43470(String.valueOf(v)).method_27692(class_124.field_1068)), false);
        }
        int total = SpiritData.totalSpirit(server, player);
        int reson = SpiritData.resonance(server, player);
        double pur = SpiritData.purity(server, player);
        int karma = SpiritData.getKarma(server, player);

        src.method_9226(() -> class_2561.method_43470("Total: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(total + " (" + tierFor(total) + ")").method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Resonance: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(reson + " / 9").method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Purity: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(String.format("%.1f%%", pur * 100)).method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Karma: ").method_27692(class_124.field_1061)
            .method_10852(class_2561.method_43470(String.valueOf(karma)).method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Mode: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(CuteDifficult.currentMode.name()).method_27692(class_124.field_1068)), false);
        return 1;
    }

    private static int showElement(class_2168 src, Element element) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        int v = SpiritData.get(src.method_9211(), player, element);
        src.method_9226(() -> class_2561.method_43470(element.kamiName() + ": " + v).method_27692(element.color()), false);
        return v;
    }

    private static int setElement(class_2168 src, Element element, int value) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        SpiritData.set(src.method_9211(), player, element, value);
        src.method_9226(() -> class_2561.method_43470(element.kamiName() + " = " + value).method_27692(element.color()), true);
        return 1;
    }

    private static int addElement(class_2168 src, Element element, int delta) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        SpiritData.add(src.method_9211(), player, element, delta);
        int now = SpiritData.get(src.method_9211(), player, element);
        src.method_9226(() -> class_2561.method_43470(element.kamiName() + " "
            + (delta >= 0 ? "+" : "") + delta + " → " + now).method_27692(element.color()), true);
        return 1;
    }

    // ===== Karma =====

    private static int showKarma(class_2168 src) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        int k = SpiritData.getKarma(src.method_9211(), player);
        src.method_9226(() -> class_2561.method_43470("Karma: " + k).method_27692(class_124.field_1061), false);
        return k;
    }

    private static int setKarma(class_2168 src, int value) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        int current = SpiritData.getKarma(src.method_9211(), player);
        SpiritData.addKarma(src.method_9211(), player, value - current);
        src.method_9226(() -> class_2561.method_43470("Karma = " + value).method_27692(class_124.field_1061), true);
        return 1;
    }

    private static int addKarma(class_2168 src, int delta) {
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        SpiritData.addKarma(src.method_9211(), player, delta);
        int now = SpiritData.getKarma(src.method_9211(), player);
        src.method_9226(() -> class_2561.method_43470("Karma "
            + (delta >= 0 ? "+" : "") + delta + " → " + now).method_27692(class_124.field_1061), true);
        return 1;
    }

    // ===== Player bulk ops =====

    private static int resetPlayer(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        for (Element e : Element.values()) SpiritData.set(src.method_9211(), player, e, SpiritData.DEFAULT_PER_ELEMENT);
        SpiritData.addKarma(src.method_9211(), player, -SpiritData.getKarma(src.method_9211(), player));
        src.method_9226(() -> class_2561.method_43470("Spirit & Karma reset to defaults.").method_27692(class_124.field_1060), true);
        return 1;
    }

    private static int godmodePlayer(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        for (Element e : Element.values()) SpiritData.set(src.method_9211(), player, e, 100);
        src.method_9226(() -> class_2561.method_43470("All Spirits → 100. One With Spirits.").method_27692(class_124.field_1065), true);
        return 1;
    }

    private static int hollowPlayer(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player = src.method_44023();
        if (player == null || src.method_9211() == null) return 0;
        for (Element e : Element.values()) SpiritData.set(src.method_9211(), player, e, -100);
        src.method_9226(() -> class_2561.method_43470("All Spirits → -100. Hollow.").method_27692(class_124.field_1064), true);
        return 1;
    }

    // ===== Mode =====

    private static int setMode(class_2168 src, String name) {
        switch (name.toLowerCase()) {
            case "cruel" -> {
                CuteDifficult.currentMode = DifficultyMode.CRUEL;
                src.method_9226(() -> class_2561.method_43470("Mode = CRUEL").method_27692(class_124.field_1061), true);
            }
            case "peace" -> {
                CuteDifficult.currentMode = DifficultyMode.PATH_OF_PEACE;
                src.method_9226(() -> class_2561.method_43470("Mode = PATH_OF_PEACE").method_27692(class_124.field_1080), true);
            }
            default -> {
                src.method_9213(class_2561.method_43470("Unknown mode: " + name + ". Use 'cruel' or 'peace'."));
                return 0;
            }
        }
        return 1;
    }

    // ===== Moon commands =====

    private static int moonList(class_2168 src) {
        src.method_9226(() -> class_2561.method_43470("=== Special Moons ===").method_27692(class_124.field_1065), false);
        for (com.cutedifficult.spirit.SpecialMoon m : com.cutedifficult.spirit.SpecialMoon.values()) {
            src.method_9226(() -> class_2561.method_43470(m.id() + " — " + m.displayName)
                .method_27692(m.color), false);
        }
        return 1;
    }

    private static int moonCurrent(class_2168 src) {
        com.cutedifficult.spirit.SpecialMoon active =
            com.cutedifficult.event.LunarCycleHandler.getActiveMoon();
        if (active == null) {
            src.method_9226(() -> class_2561.method_43470("Tonight is an ordinary night.")
                .method_27692(class_124.field_1080), false);
        } else {
            src.method_9226(() -> class_2561.method_43470("Active: " + active.displayName)
                .method_27695(active.color, class_124.field_1067), false);
        }
        return 1;
    }

    private static int moonClear(class_2168 src) {
        com.cutedifficult.event.LunarCycleHandler.clearMoon();
        src.method_9226(() -> class_2561.method_43470("Moon cleared. The night is ordinary now.")
            .method_27692(class_124.field_1080), true);
        return 1;
    }

    private static int moonForce(class_2168 src, String type) {
        com.cutedifficult.spirit.SpecialMoon moon = com.cutedifficult.spirit.SpecialMoon.byId(type);
        if (moon == null) {
            src.method_9213(class_2561.method_43470("Unknown moon: " + type + ". Use /cd moon list."));
            return 0;
        }
        if (src.method_9211() == null) {
            src.method_9213(class_2561.method_43470("No server context."));
            return 0;
        }
        com.cutedifficult.event.LunarCycleHandler.forceMoon(src.method_9211(), moon);
        src.method_9226(() -> class_2561.method_43470("Forced " + moon.displayName + " for tonight.")
            .method_27695(moon.color, class_124.field_1067), true);
        return 1;
    }

    // ===== Weather commands =====

    private static int weatherList(class_2168 src) {
        src.method_9226(() -> class_2561.method_43470("=== Weather Events ===").method_27692(class_124.field_1065), false);
        for (com.cutedifficult.spirit.WeatherEvent w : com.cutedifficult.spirit.WeatherEvent.values()) {
            src.method_9226(() -> class_2561.method_43470(w.id() + " — " + w.displayName)
                .method_27692(w.color), false);
        }
        return 1;
    }

    private static int weatherCurrent(class_2168 src) {
        com.cutedifficult.spirit.WeatherEvent active =
            com.cutedifficult.event.WeatherEventHandler.getActive();
        if (active == null) {
            src.method_9226(() -> class_2561.method_43470("The weather is ordinary today.")
                .method_27692(class_124.field_1080), false);
        } else {
            src.method_9226(() -> class_2561.method_43470("Active: " + active.displayName)
                .method_27695(active.color, class_124.field_1067), false);
        }
        return 1;
    }

    private static int weatherClear(class_2168 src) {
        if (src.method_9211() == null) { src.method_9213(class_2561.method_43470("No server context.")); return 0; }
        com.cutedifficult.event.WeatherEventHandler.clearWeather(src.method_9211());
        src.method_9226(() -> class_2561.method_43470("Weather cleared.").method_27692(class_124.field_1080), true);
        return 1;
    }

    private static int weatherForce(class_2168 src, String type) {
        com.cutedifficult.spirit.WeatherEvent w = com.cutedifficult.spirit.WeatherEvent.byId(type);
        if (w == null) {
            src.method_9213(class_2561.method_43470("Unknown weather: " + type + ". Use /cd weather list."));
            return 0;
        }
        if (src.method_9211() == null) { src.method_9213(class_2561.method_43470("No server context.")); return 0; }
        com.cutedifficult.event.WeatherEventHandler.forceWeather(src.method_9211(), w);
        src.method_9226(() -> class_2561.method_43470("Forced " + w.displayName + " today.")
            .method_27695(w.color, class_124.field_1067), true);
        return 1;
    }

    // ===== Astrology / sky commands =====

    private static int showSky(class_2168 src) {
        long day = com.cutedifficult.event.AstrologyHandler.today();
        for (class_2561 line : com.cutedifficult.event.AstrologyHandler.ephemerisReport(day)) {
            src.method_9226(() -> line, false);
        }
        return 1;
    }

    private static int astroShift(class_2168 src, int days) {
        if (src.method_9211() == null) { src.method_9213(class_2561.method_43470("No server context.")); return 0; }
        com.cutedifficult.event.AstrologyHandler.shiftDays(src.method_9211(), days);
        src.method_9226(() -> class_2561.method_43470("Sky shifted by " + days + " days. Use /cd sky to view.")
            .method_27692(class_124.field_1075), true);
        return 1;
    }

    private static int astroReset(class_2168 src) {
        if (src.method_9211() == null) { src.method_9213(class_2561.method_43470("No server context.")); return 0; }
        com.cutedifficult.event.AstrologyHandler.resetShift(src.method_9211());
        src.method_9226(() -> class_2561.method_43470("Sky shift reset to real day.")
            .method_27692(class_124.field_1080), true);
        return 1;
    }

    // ===== Fox commands =====

    /** Public (non-op) command: show the nearest kitsune's growth stage. */
    private static int foxStage(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_4019 fox = findNearestFox(src);
        if (fox == null) {
            src.method_9213(class_2561.method_43470("No kitsune nearby. Stand closer to one."));
            return 0;
        }
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        String stage = com.cutedifficult.item.ScrollOfInquiryItem.tailTier(data.tails);
        String flavor = switch (stage) {
            case "young" -> "A young spirit, still finding its paws.";
            case "matured" -> "A matured kitsune, its power growing.";
            case "venerable" -> "A venerable spirit, wise and strong.";
            case "ancient" -> "An ancient kitsune — few live to see this.";
            default -> "A Kyuubi. Nine tails. A living legend.";
        };
        final String fStage = stage, fFlavor = flavor;
        src.method_9226(() -> class_2561.method_43470(data.element.kamiName() + " kitsune — ")
            .method_27692(data.element.color())
            .method_10852(class_2561.method_43470(fStage).method_27695(class_124.field_1065, class_124.field_1067))
            .method_10852(class_2561.method_43470("  (" + data.tails + " tails)").method_27692(class_124.field_1080)), false);
        src.method_9226(() -> class_2561.method_43470(fFlavor)
            .method_27695(class_124.field_1063, class_124.field_1056), false);
        return 1;
    }

    private static int foxInfo(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;

        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        FoxPersonality p = data.personality;

        src.method_9226(() -> class_2561.method_43470("=== Fox " + fox.method_5667().toString().substring(0, 8)
            + " ===").method_27692(class_124.field_1065), false);
        src.method_9226(() -> class_2561.method_43470("Element: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(data.element.kamiName()).method_27692(data.element.color())), false);
        src.method_9226(() -> class_2561.method_43470("Tails: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(data.tails + " / " + KitsuneData.MAX_TAILS).method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Trust: ").method_27692(class_124.field_1080)
            .method_10852(class_2561.method_43470(data.trustLevel + " / 100").method_27692(class_124.field_1068)), false);
        src.method_9226(() -> class_2561.method_43470("Personality:").method_27692(class_124.field_1080), false);
        src.method_9226(() -> class_2561.method_43470("  Pride: " + p.pride() + "  Trust: " + p.trust()
            + "  Curiosity: " + p.curiosity()).method_27692(class_124.field_1063), false);
        src.method_9226(() -> class_2561.method_43470("  Memory: " + p.memory() + "  Greed: " + p.greed()
            + "  Sensitivity: " + p.sensitivity() + "  Trauma: " + p.trauma()).method_27692(class_124.field_1063), false);
        src.method_9226(() -> class_2561.method_43470("Last fed at tick: " + data.lastFedTickStamp).method_27692(class_124.field_1063), false);
        return 1;
    }

    private static int foxSetTails(class_2168 src, int count) {
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        FoxStorage.store(fox, data.withTails(count));
        src.method_9226(() -> class_2561.method_43470("Fox tails = " + count).method_27692(class_124.field_1060), true);
        return 1;
    }

    private static int foxSetElement(class_2168 src, String name) {
        Element el = resolveElement(src, name);
        if (el == null) return 0;
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        KitsuneData updated = KitsuneData.of6(el, data.personality, data.tails,
            data.trustLevel, data.lastFedTickStamp, 0);
        FoxStorage.store(fox, updated);
        src.method_9226(() -> class_2561.method_43470("Fox element = " + el.kamiName()).method_27692(el.color()), true);
        return 1;
    }

    private static int foxSetTrust(class_2168 src, int value) {
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        FoxStorage.store(fox, data.withTrust(value));
        src.method_9226(() -> class_2561.method_43470("Fox trust = " + value).method_27692(class_124.field_1060), true);
        return 1;
    }

    private static int foxSetPersonality(class_2168 src, String trait, int value) {
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        FoxPersonality p = data.personality;
        FoxPersonality updated = switch (trait.toLowerCase()) {
            case "pride" -> new FoxPersonality(value, p.trust(), p.curiosity(), p.memory(), p.greed(), p.sensitivity(), p.trauma());
            case "trust" -> new FoxPersonality(p.pride(), value, p.curiosity(), p.memory(), p.greed(), p.sensitivity(), p.trauma());
            case "curiosity" -> new FoxPersonality(p.pride(), p.trust(), value, p.memory(), p.greed(), p.sensitivity(), p.trauma());
            case "memory" -> new FoxPersonality(p.pride(), p.trust(), p.curiosity(), value, p.greed(), p.sensitivity(), p.trauma());
            case "greed" -> new FoxPersonality(p.pride(), p.trust(), p.curiosity(), p.memory(), value, p.sensitivity(), p.trauma());
            case "sensitivity" -> new FoxPersonality(p.pride(), p.trust(), p.curiosity(), p.memory(), p.greed(), value, p.trauma());
            case "trauma" -> new FoxPersonality(p.pride(), p.trust(), p.curiosity(), p.memory(), p.greed(), p.sensitivity(), value);
            default -> {
                src.method_9213(class_2561.method_43470("Unknown trait: " + trait
                    + ". Valid: pride, trust, curiosity, memory, greed, sensitivity, trauma"));
                yield null;
            }
        };
        if (updated == null) return 0;
        KitsuneData stored = KitsuneData.of6(data.element, updated, data.tails,
            data.trustLevel, data.lastFedTickStamp, 0);
        FoxStorage.store(fox, stored);
        src.method_9226(() -> class_2561.method_43470("Fox " + trait + " = " + value).method_27692(class_124.field_1060), true);
        return 1;
    }

    private static int foxReroll(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_4019 fox = findNearestFox(src);
        if (fox == null) return 0;
        KitsuneData fresh = FoxStorage.generate(RANDOM);
        FoxStorage.store(fox, fresh);
        src.method_9226(() -> class_2561.method_43470("Fox rerolled: " + fresh.element.kamiName()
            + ", " + fresh.tails + " tails").method_27692(fresh.element.color()), true);
        return 1;
    }

    private static int foxSummon(class_2168 src, String name, int tails) {
        Element el = resolveElement(src, name);
        if (el == null) return 0;
        if (!(src.method_9228() instanceof class_3222 player)) {
            src.method_9213(class_2561.method_43470("Must be run as a player."));
            return 0;
        }
        class_3218 world = player.method_51469();
        // v0.9.6: spawn KitsuneEntity directly. Previously we spawned a
        // vanilla FoxEntity which triggered FoxSpawnHandler to replace it
        // with a freshly-randomized kitsune — overwriting the element and
        // tail count the player requested. This caused /cd fox summon to
        // silently produce wrong-element / wrong-tails kitsune.
        com.cutedifficult.entity.KitsuneEntity kitsune =
            com.cutedifficult.entity.ModEntities.KITSUNE.method_5883(world);
        if (kitsune == null) {
            src.method_9213(class_2561.method_43470("Failed to spawn kitsune."));
            return 0;
        }
        kitsune.method_5808(
            player.method_23317(), player.method_23318(), player.method_23321(),
            player.method_36454(), player.method_36455());
        KitsuneData data = KitsuneData.of6(el, FoxPersonality.random(RANDOM), tails, 0, 0L, 0);
        FoxStorage.store(kitsune, data);
        com.cutedifficult.spirit.FoxStats.applyHpForTails(kitsune, tails);
        world.method_8649(kitsune);
        src.method_9226(() -> class_2561.method_43470("Summoned " + el.kamiName() + " kitsune with "
            + tails + " tails").method_27692(el.color()), true);
        return 1;
    }

    // ===== Enchant =====

    /** Apply a custom enhanced-enchant marker to the item in the player's main
     *  hand, rebuilding the meme-name lore from all markers present. */
    private static int giveEnchant(class_2168 src, String markerId, int level) {
        class_3222 player = src.method_44023();
        if (player == null) {
            src.method_9213(class_2561.method_43470("Must be run by a player."));
            return 0;
        }
        com.cutedifficult.spirit.EnhancedEnchant ench =
            com.cutedifficult.spirit.EnhancedEnchant.byMarker(markerId);
        if (ench == null) {
            src.method_9213(class_2561.method_43470("Unknown enchant marker: " + markerId));
            return 0;
        }
        net.minecraft.class_1799 held = player.method_6047();
        if (held.method_7960()) {
            src.method_9213(class_2561.method_43470("Hold an item in your main hand."));
            return 0;
        }

        // Apply the stacking marker, then rebuild lore from ALL markers.
        com.cutedifficult.spirit.EnchantMarkers.add(held, ench.markerId, level);
        java.util.Map<String, Integer> markers =
            com.cutedifficult.spirit.EnchantMarkers.read(held);
        java.util.List<class_2561> lore = new java.util.ArrayList<>();
        for (java.util.Map.Entry<String, Integer> m : markers.entrySet()) {
            com.cutedifficult.spirit.EnhancedEnchant e =
                com.cutedifficult.spirit.EnhancedEnchant.byMarker(m.getKey());
            if (e == null) continue;
            String suffix = m.getValue() > 1 ? " " + toRoman(m.getValue()) : "";
            lore.add(class_2561.method_43470("\u2726 " + e.displayName + suffix)
                .method_27695(e.color(), class_124.field_1067));
            lore.add(class_2561.method_43470("  " + e.loreDescription)
                .method_27695(class_124.field_1063, class_124.field_1056));
        }
        held.method_57379(net.minecraft.class_9334.field_49632,
            new net.minecraft.class_9290(lore));

        final com.cutedifficult.spirit.EnhancedEnchant fe = ench;
        src.method_9226(() -> class_2561.method_43470("Applied " + fe.displayName + " (level " + level + ")")
            .method_27692(fe.color()), true);
        return 1;
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I"; case 2 -> "II"; case 3 -> "III";
            case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n);
        };
    }

    // ===== Tier =====

    private static String tierFor(int totalSpirit) {
        if (totalSpirit < 0) return "Hollow";
        if (totalSpirit < 15) return "Mortal";
        if (totalSpirit < 50) return "Awakened";
        if (totalSpirit < 150) return "Enlightened";
        if (totalSpirit < 400) return "Sage";
        return "One With Spirits";
    }
}
