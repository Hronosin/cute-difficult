package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1593;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

/**
 * FPV phantom drones with fairness pass (v0.1.5).
 *
 * <p><b>Changes from v0.1.1:</b>
 * <ul>
 *   <li>Phantoms now require line-of-sight to acquire and keep a target —
 *       raycast against block colliders. Hide behind a wall = phantom loses
 *       lock, drops to vanilla AI behavior (bobbing/swooping).</li>
 *   <li>Smoke trail respects LOS implicitly: trail only spawns while the
 *       phantom has a player target, so the player never sees a trail
 *       crossing through walls.</li>
 *   <li>Phantoms that collide with a block while charging (high velocity)
 *       detonate on impact. The explosion now leaves fire. This creates
 *       the "phantom slams into the wall you're hiding behind" moment —
 *       wall explodes inward, you may still die, but you got a chance.</li>
 * </ul>
 *
 * <p><b>Design rationale:</b> the old "phantoms see through everything"
 * behavior was unfair in a way that broke the mod's tone. Cute Difficult
 * is cruel, but every cruelty should be readable — player should always
 * understand why they died. LOS-respecting phantoms give the player a
 * legible counter (cover) without making the mechanic toothless: the
 * explosion-on-impact rule punishes panic-hiding inside thin walls.
 *
 * <p><b>The collision-detonation speed threshold</b> ({@code COLLIDE_SPEED_SQ})
 * exists so that idle phantoms which gently brush a ceiling or wall while
 * drifting don't randomly explode. Only phantoms travelling at our drone
 * speed (set by piloting) trip the rule.
 */
public final class PhantomDroneHandler {
    private static final double DETECTION_RADIUS = 64.0;
    private static final double DRONE_SPEED = 0.55;
    private static final double DETONATION_DISTANCE = 1.8;
    private static final float EXPLOSION_POWER = 2.5f;
    private static final int MAX_TRAIL_PARTICLES = 24;

    /** Squared speed above which a collision counts as a "charge impact". */
    private static final double COLLIDE_SPEED_SQ = 0.16; // (0.4)^2

    private PhantomDroneHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_1593 phantom && phantom.method_5805()) {
                        pilotPhantom(world, phantom);
                    }
                }
            }
        });
    }

    private static void pilotPhantom(class_3218 world, class_1593 phantom) {
        // === Step 1: if the phantom was charging and hit a block, detonate. ===
        // Vanilla sets these flags during move() which runs before our tick.
        boolean collided = phantom.field_5976 || phantom.field_5992;
        double speedSq = phantom.method_18798().method_1027();
        if (collided && speedSq > COLLIDE_SPEED_SQ) {
            detonate(world, phantom);
            return;
        }

        // === Step 2: find nearest valid player in range. ===
        var nearest = world.method_8604(
            phantom.method_23317(), phantom.method_23318(), phantom.method_23321(),
            DETECTION_RADIUS,
            player -> player instanceof class_3222 sp
                && !sp.method_7337()
                && !sp.method_7325()
                && sp.method_5805()
        );

        if (!(nearest instanceof class_3222 target)) return;

        // === Step 3: line-of-sight check. ===
        class_243 aimPoint = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
        class_243 phantomCenter = phantom.method_19538().method_1031(0, phantom.method_17682() * 0.5, 0);

        if (!hasLineOfSight(world, phantomCenter, aimPoint, phantom)) {
            // Player is behind cover. Phantom drops to vanilla AI this tick.
            // Importantly: we don't zero its velocity — it keeps any momentum
            // from a prior charge, which means panic-hiding in thin cover
            // can result in the phantom slamming the wall (handled in step 1
            // on the next tick).
            return;
        }

        // === Step 4: pilot. ===
        class_243 toTarget = aimPoint.method_1020(phantomCenter);
        double distance = toTarget.method_1033();
        if (distance < 0.01) return;

        class_243 velocity = toTarget.method_1029().method_1021(DRONE_SPEED);
        phantom.method_18799(velocity);
        phantom.field_6037 = true;

        // Detonate on direct hit.
        if (distance < DETONATION_DISTANCE) {
            detonate(world, phantom);
            return;
        }

        // Visual warning. Only spawned while LOS is clear, which is the
        // fairness property: if you've broken LOS you don't see the trail.
        spawnWarningTrail(world, phantomCenter, aimPoint, distance);
        spawnDroneMarker(world, phantomCenter);
    }

    /**
     * Raycast from phantom to target. Returns true if no block obstructs
     * the line. Uses COLLIDER shape (solid blocks block sight, transparent
     * things like grass do not) and ignores fluids.
     */
    private static boolean hasLineOfSight(class_3218 world, class_243 from, class_243 to, class_1593 phantom) {
        class_3959 context = new class_3959(
            from,
            to,
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            phantom
        );
        class_3965 hit = world.method_17742(context);
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    private static void spawnWarningTrail(class_3218 world, class_243 from, class_243 to, double distance) {
        int particleCount = (int) Math.min(MAX_TRAIL_PARTICLES, Math.max(4, distance / 2.0));
        class_243 step = to.method_1020(from).method_1021(1.0 / particleCount);

        for (int i = 1; i <= particleCount; i++) {
            class_243 point = from.method_1019(step.method_1021(i));
            world.method_14199(
                class_2398.field_11251,
                point.field_1352, point.field_1351, point.field_1350,
                1,
                0.05, 0.05, 0.05,
                0.0
            );
        }
    }

    private static void spawnDroneMarker(class_3218 world, class_243 center) {
        world.method_14199(
            class_2398.field_22246,
            center.field_1352, center.field_1351, center.field_1350,
            3,
            0.3, 0.3, 0.3,
            0.01
        );
    }

    private static void detonate(class_3218 world, class_1593 phantom) {
        world.method_8537(
            phantom,
            phantom.method_23317(), phantom.method_23318(), phantom.method_23321(),
            EXPLOSION_POWER,
            true,  // createFire — leaves fire behind, per v0.1.5 fairness pass
            class_1937.class_7867.field_40890
        );
        phantom.method_31472();
    }
}
