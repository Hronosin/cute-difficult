package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1589;
import net.minecraft.class_1621;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Slimes and magma cubes leave a slowing pool on death. The pool persists
 * for {@link #POOL_DURATION_TICKS} (8 seconds) and slows any LivingEntity
 * that walks into its radius.
 *
 * <p>Each pool is a transient entry in a list, ticked down each server
 * tick. No entity is actually placed in the world — pools are just
 * data + visual particles.
 *
 * <p>For magma cubes, the pool also briefly sets enemies on fire.
 */
public final class SlimeOilPoolHandler {

    private static final int POOL_DURATION_TICKS = 160; // 8s
    private static final double POOL_RADIUS = 1.8;

    private record Pool(class_3218 world, class_243 center, long expireTick, boolean fiery) {}

    private static final List<Pool> POOLS = new ArrayList<>();

    private SlimeOilPoolHandler() {}

    public static void register() {
        // On entity death, register a pool if it was a slime/magma cube.
        ServerLivingEntityEvents.AFTER_DEATH.register((victim, source) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(victim.method_37908() instanceof class_3218 world)) return;

            if (victim instanceof class_1589 mc && mc.method_7152() >= 2) {
                POOLS.add(new Pool(world, mc.method_19538(), world.method_8510() + POOL_DURATION_TICKS, true));
            } else if (victim instanceof class_1621 slime && slime.method_7152() >= 2) {
                POOLS.add(new Pool(world, slime.method_19538(), world.method_8510() + POOL_DURATION_TICKS, false));
            }
        });

        // Tick all pools.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (POOLS.isEmpty()) return;
            long now = server.method_30002().method_8510();
            Iterator<Pool> it = POOLS.iterator();
            while (it.hasNext()) {
                Pool pool = it.next();
                if (now >= pool.expireTick) {
                    it.remove();
                    continue;
                }
                tickPool(pool);
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] SlimeOilPoolHandler registered.");
    }

    private static void tickPool(Pool pool) {
        // Particles — bubbles for slime, lava drips for magma.
        if (pool.world.method_8510() % 5 == 0) {
            for (int i = 0; i < 3; i++) {
                double angle = pool.world.field_9229.method_43058() * Math.PI * 2;
                double r = pool.world.field_9229.method_43058() * POOL_RADIUS;
                double px = pool.center.field_1352 + Math.cos(angle) * r;
                double pz = pool.center.field_1350 + Math.sin(angle) * r;
                pool.world.method_14199(
                    pool.fiery ? class_2398.field_11239 : class_2398.field_11246,
                    px, pool.center.field_1351 + 0.1, pz, 1, 0.1, 0.05, 0.1, 0.01
                );
            }
        }

        // Affect entities standing in the pool.
        var box = pool.world.method_8333(null,
            new net.minecraft.class_238(
                pool.center.field_1352 - POOL_RADIUS, pool.center.field_1351 - 0.5, pool.center.field_1350 - POOL_RADIUS,
                pool.center.field_1352 + POOL_RADIUS, pool.center.field_1351 + 1.5, pool.center.field_1350 + POOL_RADIUS
            ),
            e -> e instanceof class_1309 && !(e instanceof class_1621) && !(e instanceof class_1589)
        );
        for (class_1297 e : box) {
            if (!(e instanceof class_1309 living)) continue;
            living.method_6092(new class_1293(
                class_1294.field_5909, 30, 2, false, false, true));
            if (pool.fiery) {
                living.method_5639(2);
            }
        }
    }
}
