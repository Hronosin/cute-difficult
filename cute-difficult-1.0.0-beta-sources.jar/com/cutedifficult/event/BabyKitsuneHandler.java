package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.entity.ModEntities;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxPersonality;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.UUID;

/**
 * Baby kitsune (kits) — both spawn and mourning logic.
 *
 * <p><b>Spawn:</b> when a kitsune is loaded with trust ≥ {@link #BABY_TRUST_THRESHOLD},
 * there's a {@link #BABY_SPAWN_CHANCE}% chance per fox-per-load to spawn
 * a baby kitsune at her side. The baby inherits the parent's element
 * and a copy of her personality (but with reduced trauma — kits are
 * trauma-free until life teaches them).
 *
 * <p>Baby kitsune use vanilla fox baby age (-24000), which gives the
 * smaller scaled model. They grow up naturally over 1 in-game day
 * because we leave vanilla's age-progression alone.
 *
 * <p><b>Mourning:</b> when an adult kitsune dies, any baby kitsune
 * within {@link #MOURNING_RADIUS} sit at her body. They emit blue
 * "tears" particles for {@link #MOURNING_TICKS} (30 seconds), then
 * stand up and flee. This is a visual-only thing — no gameplay impact —
 * but the emotional weight matters.
 *
 * <p>To avoid exponentially repeating spawns on chunk-loads, we track
 * "babies spawned for this parent" using a set keyed by parent UUID,
 * which lives for the server session. New mothers in fresh chunks
 * always roll the chance, but the same loaded mother won't spawn
 * additional babies on subsequent loads.
 */
public final class BabyKitsuneHandler {

    private static final int BABY_TRUST_THRESHOLD = 50;
    private static final int BABY_SPAWN_CHANCE = 30; // percent

    private static final double MOURNING_RADIUS = 8.0;
    private static final int MOURNING_TICKS = 600; // 30s

    /** Parent UUIDs we've already rolled — prevents repeat rolls. */
    private static final java.util.Set<UUID> ALREADY_ROLLED = java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** Active mourners: baby UUID → ticks remaining. */
    private static final Map<UUID, Integer> MOURNERS = new HashMap<>();

    private static final Random RANDOM = new Random();

    private BabyKitsuneHandler() {}

    public static void register() {
        // Per-load chance to spawn a baby for an eligible adult.
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(entity instanceof KitsuneEntity adult)) return;
            if (adult.method_6109()) return;
            UUID id = adult.method_5667();
            if (ALREADY_ROLLED.contains(id)) return;
            ALREADY_ROLLED.add(id);

            KitsuneData data = FoxStorage.peekCache(adult);
            if (data == null || data.trustLevel < BABY_TRUST_THRESHOLD) return;
            if (RANDOM.nextInt(100) >= BABY_SPAWN_CHANCE) return;

            spawnBaby(world, adult, data);
        });

        // When an adult kitsune dies, mark nearby babies as mourners.
        ServerLivingEntityEvents.AFTER_DEATH.register((victim, source) -> {
            if (!(victim instanceof KitsuneEntity dead)) return;
            if (dead.method_6109()) return;
            if (!(dead.method_37908() instanceof class_3218 world)) return;
            markMourners(world, dead);
        });

        // Tick mourners: emit tears, decrement, eventually free them.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (MOURNERS.isEmpty()) return;
            var it = MOURNERS.entrySet().iterator();
            while (it.hasNext()) {
                var entry = it.next();
                int remaining = entry.getValue() - 1;
                if (remaining <= 0) {
                    it.remove();
                    continue;
                }
                entry.setValue(remaining);
                emitTears(server, entry.getKey());
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] BabyKitsuneHandler registered.");
    }

    private static void spawnBaby(class_3218 world, KitsuneEntity adult, KitsuneData adultData) {
        KitsuneEntity baby = ModEntities.KITSUNE.method_5883(world);
        if (baby == null) return;

        double dx = (RANDOM.nextDouble() - 0.5) * 2;
        double dz = (RANDOM.nextDouble() - 0.5) * 2;
        baby.method_5808(adult.method_23317() + dx, adult.method_23318(), adult.method_23321() + dz,
            adult.method_36454(), 0);
        baby.method_5614(-24000); // 1 in-game day to grow up
        world.method_8649(baby);

        // Inherit parent's element + personality (with reduced trauma).
        FoxPersonality parentPers = adultData.personality;
        FoxPersonality babyPers = new FoxPersonality(
            parentPers.pride(),
            Math.min(100, parentPers.trust() + 10), // kits are trustful
            Math.min(100, parentPers.curiosity() + 15), // and curious
            parentPers.memory(),
            parentPers.greed(),
            parentPers.sensitivity(),
            Math.max(0, parentPers.trauma() - 30) // less trauma
        );
        KitsuneData babyData = new KitsuneData(
            adultData.element,
            babyPers,
            1, // start with 1 tail
            0, 0L, 0, "", 0L
        );
        FoxStorage.injectIntoCache(baby, babyData);

        world.method_14199(net.minecraft.class_2398.field_11201,
            baby.method_23317(), baby.method_23318() + 0.5, baby.method_23321(),
            5, 0.3, 0.3, 0.3, 0.1);
        world.method_43128(null, baby.method_23317(), baby.method_23318(), baby.method_23321(),
            class_3417.field_18056, class_3419.field_15254, 0.8f, 1.6f);
    }

    private static void markMourners(class_3218 world, KitsuneEntity dead) {
        var box = new net.minecraft.class_238(
            dead.method_23317() - MOURNING_RADIUS, dead.method_23318() - MOURNING_RADIUS, dead.method_23321() - MOURNING_RADIUS,
            dead.method_23317() + MOURNING_RADIUS, dead.method_23318() + MOURNING_RADIUS, dead.method_23321() + MOURNING_RADIUS
        );
        var nearbyBabies = world.method_8390(KitsuneEntity.class, box,
            f -> f.method_6109() && f.method_5805());
        for (KitsuneEntity baby : nearbyBabies) {
            MOURNERS.put(baby.method_5667(), MOURNING_TICKS);
            // Stop the baby in place to "sit at" the body.
            baby.method_5942().method_6340();
            baby.method_18294(true);
        }
    }

    private static void emitTears(net.minecraft.server.MinecraftServer server, UUID babyId) {
        for (class_3218 world : server.method_3738()) {
            class_1297 e = world.method_14190(babyId);
            if (!(e instanceof KitsuneEntity baby) || !baby.method_5805()) continue;
            if (world.method_8510() % 6 != 0) continue;
            world.method_14199(class_2398.field_11202,
                baby.method_23317(), baby.method_23318() + 0.4, baby.method_23321(),
                1, 0.1, 0.05, 0.1, 0.02);
        }
    }
}
