package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Hostile mobs jump over single-block obstacles and small gaps.
 *
 * <p>Vanilla mobs are usually too stupid to handle this themselves —
 * they just walk into walls and get stuck. We patch that by ticking
 * every {@link class_1588}: if it has a target, is on the ground,
 * and there's a one-block-high obstacle in front of it (or a one-block
 * gap to cross), apply an upward velocity impulse.
 *
 * <p>Cooldown per mob ({@link #JUMP_COOLDOWN_TICKS}) so they don't
 * spam-bounce. The check is cheap: read the block in front + above
 * the mob's foot level.
 *
 * <p>This single change makes ALL hostile mobs (zombies, skeletons,
 * pillagers, creepers, spiders if they're not already, husks, drowned,
 * piglins, etc.) much harder to escape by exploiting terrain. No more
 * jumping on a 1-block ledge to safely shoot zombies forever.
 */
public final class JumpingMobsHandler {

    private static final int JUMP_COOLDOWN_TICKS = 20;
    private static final double JUMP_VELOCITY = 0.42;
    /** Don't trigger if target is too far — saves CPU. */
    private static final double TARGET_RANGE_SQUARED = 32 * 32;

    private static final WeakHashMap<UUID, Long> LAST_JUMP = new WeakHashMap<>();

    private JumpingMobsHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (!(entity instanceof class_1588 hostile)) continue;
                    if (!hostile.method_5805() || !hostile.method_24828()) continue;
                    tickHostile(world, hostile);
                }
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] JumpingMobsHandler registered.");
    }

    private static void tickHostile(class_3218 world, class_1588 mob) {
        class_1309 target = mob.method_5968();
        if (target == null) return;
        if (mob.method_5858(target) > TARGET_RANGE_SQUARED) return;

        UUID id = mob.method_5667();
        long now = world.method_8510();
        Long lastJump = LAST_JUMP.get(id);
        if (lastJump != null && now - lastJump < JUMP_COOLDOWN_TICKS) return;

        // Check: is there an obstacle one block ahead, at foot level?
        class_243 forward = directionTo(mob, target);
        class_2338 footAhead = class_2338.method_49637(
            mob.method_23317() + forward.field_1352 * 0.8,
            mob.method_23318(),
            mob.method_23321() + forward.field_1350 * 0.8
        );
        class_2338 headAhead = footAhead.method_10084();

        boolean blockedAtFoot = !world.method_8320(footAhead).method_26220(world, footAhead).method_1110();
        boolean clearAtHead = world.method_8320(headAhead).method_26220(world, headAhead).method_1110();
        class_2338 aboveHead = headAhead.method_10084();
        boolean clearAboveHead = world.method_8320(aboveHead).method_26220(world, aboveHead).method_1110();

        // Only jump if obstacle exists AND there's space above to land in.
        if (blockedAtFoot && clearAtHead && clearAboveHead) {
            mob.method_18800(mob.method_18798().field_1352, JUMP_VELOCITY, mob.method_18798().field_1350);
            mob.field_6037 = true;
            LAST_JUMP.put(id, now);
            return;
        }

        // Also jump if the target is significantly above (e.g. on a hill).
        double dy = target.method_23318() - mob.method_23318();
        if (dy > 0.8 && dy < 2.5 && blockedAtFoot) {
            mob.method_18800(mob.method_18798().field_1352, JUMP_VELOCITY, mob.method_18798().field_1350);
            mob.field_6037 = true;
            LAST_JUMP.put(id, now);
        }
    }

    private static class_243 directionTo(class_1297 from, class_1297 to) {
        class_243 d = to.method_19538().method_1020(from.method_19538());
        double len = d.method_1033();
        return len < 0.01 ? new class_243(1, 0, 0) : d.method_1021(1.0 / len);
    }
}
