package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxHostility;
import com.cutedifficult.spirit.FoxStats;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import org.joml.Vector3f;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Combat retaliation + central elemental-ability dispatch.
 *
 * <p><b>v0.6.3 expansion:</b> each element now has THREE attack moves:
 * a basic single-target attack, an area-of-effect (AOE) attack, and a
 * piercing beam. {@link #castElementalAbility} randomly picks among them
 * (weighted toward basic), giving combat encounters more variety.
 *
 * <p>All attacks now go through {@link FoxHostility#canAttackWithLineOfSight}
 * before firing — no more wall-piercing damage, and friendly foxes never
 * attack regardless of which handler is calling.
 */
public final class FoxAbilityHandler {

    private static final WeakHashMap<UUID, Float> LAST_HP = new WeakHashMap<>();
    private static final WeakHashMap<UUID, Long> LAST_REACTIVE_CAST = new WeakHashMap<>();

    private static final double TARGET_RADIUS = 16.0;
    private static final int ABILITY_MIN_TAILS = 2;

    /** AOE radius for elemental burst attacks. */
    private static final double AOE_RADIUS = 4.0;

    /** Piercing beam: how far it extends past the target. */
    private static final double BEAM_RANGE = 14.0;
    /** Piercing beam: how wide the damage cone is (block radius around line). */
    private static final double BEAM_WIDTH = 1.0;

    private static final Random RANDOM = new Random();

    private FoxAbilityHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_4019 fox && fox.method_5805()) {
                        tickFox(world, fox);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxAbilityHandler registered.");
    }

    private static void tickFox(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        if (data.tails < ABILITY_MIN_TAILS) return;

        UUID id = fox.method_5667();
        float currentHp = fox.method_6032();
        Float previousHp = LAST_HP.get(id);
        LAST_HP.put(id, currentHp);

        if (previousHp == null) return;
        if (currentHp >= previousHp) return;

        long now = world.method_8510();
        Long lastCast = LAST_REACTIVE_CAST.get(id);
        int cooldown = FoxStats.abilityCooldownTicks(data.tails);
        if (lastCast != null && now - lastCast < cooldown) return;

        class_3222 target = (class_3222) world.method_8604(
            fox.method_23317(), fox.method_23318(), fox.method_23321(),
            TARGET_RADIUS,
            p -> p instanceof class_3222 sp && !sp.method_7337() && !sp.method_7325() && sp.method_5805()
        );
        if (target == null) return;

        if (!FoxHostility.canAttackWithLineOfSight(fox, target)) return;

        castElementalAbility(world, fox, data, target);
        LAST_REACTIVE_CAST.put(id, now);
    }

    /**
     * Public elemental dispatch. Called from this handler (reactive),
     * {@link FoxAggressionHandler} (proactive), and from the
     * {@link com.cutedifficult.entity.ai.KitsuneAttackGoal}.
     *
     * <p>Selects randomly among basic / AOE / beam variants, weighted
     * toward basic. Higher-tail foxes are MORE likely to use the
     * spectacular variants (AOE and beam).
     */
    public static void castElementalAbility(
        class_3218 world, class_4019 fox, KitsuneData data, class_3222 target
    ) {
        // Final gate — never cast on a friendly/blocked target.
        if (!FoxHostility.canAttackWithLineOfSight(fox, target)) return;

        Element element = data.element;
        double power = data.tails / 9.0;

        // Roll attack variant. Weights:
        //   Basic: 60% always
        //   AOE: 25% (scaled up with tails)
        //   Beam: 15% (scaled up with tails)
        double roll = RANDOM.nextDouble();
        double aoeWeight = 0.25 * (0.5 + power * 0.5);
        double beamWeight = 0.15 * (0.5 + power * 0.5);

        AttackVariant variant;
        if (roll < beamWeight) variant = AttackVariant.BEAM;
        else if (roll < beamWeight + aoeWeight) variant = AttackVariant.AOE;
        else variant = AttackVariant.BASIC;

        switch (variant) {
            case BASIC -> castBasic(world, fox, target, element, power);
            case AOE -> castAoe(world, fox, target, element, power);
            case BEAM -> castBeam(world, fox, target, element, power);
        }

        world.method_43128(
            null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_18265,
            class_3419.field_15251,
            1.2f, 0.7f + (float) power * 0.5f
        );
    }

    private enum AttackVariant { BASIC, AOE, BEAM }

    // === BASIC (original single-target) ===

    private static void castBasic(class_3218 world, class_4019 fox, class_3222 target, Element element, double power) {
        switch (element) {
            case KASAI -> {
                drawLine(world, fox, target, class_2398.field_11240, 16);
                target.method_5643(world.method_48963().method_48813(), (float) (4.0 * power));
                target.method_5639((int) Math.max(1, 3 * power));
            }
            case MIZU -> {
                drawLine(world, fox, target, class_2398.field_11202, 20);
                target.method_5643(world.method_48963().method_48824(), (float) (3.0 * power));
                target.method_6092(new class_1293(class_1294.field_5909, Math.max(20, (int) (60 * power)), 1));
            }
            case DAICHI -> {
                class_243 hitPos = target.method_19538();
                world.method_14199(class_2398.field_11205, hitPos.field_1352, hitPos.field_1351 + 0.3, hitPos.field_1350, 30, 0.5, 0.8, 0.5, 0.4);
                target.method_5643(world.method_48963().method_48830(), (float) (5.0 * power));
                target.method_6092(new class_1293(class_1294.field_5909, 30, 1));
            }
            case KAZE -> {
                class_243 away = target.method_19538().method_1020(fox.method_19538());
                double len = away.method_1033();
                if (len < 0.01) away = new class_243(1, 0, 0); else away = away.method_1021(1.0 / len);
                class_243 kb = new class_243(away.field_1352 * 1.5 * power, 0.6 * power, away.field_1350 * 1.5 * power);
                target.method_18799(target.method_18798().method_1019(kb));
                target.field_6037 = true;
                world.method_14199(class_2398.field_11204, target.method_23317(), target.method_23318() + 1, target.method_23321(), 16, 0.5, 0.5, 0.5, 0.1);
                target.method_5643(world.method_48963().method_48830(), (float) (2.0 * power));
            }
            case KAMINARI -> {
                class_1538 bolt = class_1299.field_6112.method_5883(world);
                if (bolt != null) {
                    bolt.method_24203(target.method_23317(), target.method_23318(), target.method_23321());
                    world.method_8649(bolt);
                }
            }
            case MORI -> {
                drawLine(world, fox, target, class_2398.field_11211, 16);
                target.method_5643(world.method_48963().method_48830(), (float) (2.0 * power));
                target.method_6092(new class_1293(class_1294.field_5899, Math.max(20, (int) (80 * power)), 1));
            }
            case KORI -> {
                drawLine(world, fox, target, class_2398.field_28013, 20);
                target.method_5643(world.method_48963().method_48836(), (float) (3.5 * power));
                target.method_6092(new class_1293(class_1294.field_5909, Math.max(20, (int) (80 * power)), 2));
            }
            case YUREI -> {
                class_243 behindDir = target.method_5828(1.0f).method_1021(-1).method_1029();
                class_243 teleportTo = target.method_19538().method_1019(behindDir.method_1021(1.5));
                fox.method_24203(teleportTo.field_1352, teleportTo.field_1351, teleportTo.field_1350);
                for (int i = 0; i < 20; i++) {
                    world.method_14199(
                        new class_2390(new Vector3f(0.8f, 0.4f, 1.0f), 1.5f),
                        fox.method_23317() + (RANDOM.nextDouble() - 0.5) * 1.5,
                        fox.method_23318() + RANDOM.nextDouble() * 1.5,
                        fox.method_23321() + (RANDOM.nextDouble() - 0.5) * 1.5,
                        1, 0, 0, 0, 0);
                }
                target.method_5643(world.method_48963().method_48831(), (float) (6.0 * power));
                target.method_6092(new class_1293(class_1294.field_5911, Math.max(20, (int) (100 * power)), 0));
            }
            case TENGOKU -> {
                drawLine(world, fox, target, class_2398.field_11207, 24);
                target.method_5643(world.method_48963().method_48831(), (float) (8.0 * power));
                target.method_6092(new class_1293(class_1294.field_5912, 60, 0));
                target.method_5639((int) Math.max(1, 2 * power));
            }
        }
    }

    // === AOE (area-of-effect, damages all enemies in a radius around the target) ===

    private static void castAoe(class_3218 world, class_4019 fox, class_3222 target, Element element, double power) {
        class_243 center = target.method_19538();
        class_238 box = new class_238(
            center.field_1352 - AOE_RADIUS, center.field_1351 - 2, center.field_1350 - AOE_RADIUS,
            center.field_1352 + AOE_RADIUS, center.field_1351 + 4, center.field_1350 + AOE_RADIUS
        );
        List<class_1309> victims = world.method_8390(class_1309.class, box,
            e -> e != fox && e.method_5805() && e.method_5739(target) <= AOE_RADIUS + 1);

        // Element-specific AOE visuals + effects.
        switch (element) {
            case KASAI -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11240, 60);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48813(), (float) (6.0 * power));
                    v.method_5639((int) Math.max(2, 5 * power));
                }
            }
            case MIZU -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11202, 80);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48824(), (float) (4.0 * power));
                    if (v instanceof class_3222 p) p.method_6092(
                        new class_1293(class_1294.field_5909, 80, 2));
                }
            }
            case DAICHI -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11205, 100);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48830(), (float) (7.0 * power));
                    if (v instanceof class_3222 p) p.method_6092(
                        new class_1293(class_1294.field_5909, 60, 2));
                }
            }
            case KAZE -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11204, 80);
                for (class_1309 v : victims) {
                    class_243 away = v.method_19538().method_1020(center);
                    double len = away.method_1033();
                    if (len > 0.01) {
                        class_243 kb = away.method_1021(1.5 * power / len);
                        v.method_18799(v.method_18798().method_1031(kb.field_1352, 0.8 * power, kb.field_1350));
                        v.field_6037 = true;
                    }
                    v.method_5643(world.method_48963().method_48830(), (float) (3.0 * power));
                }
            }
            case KAMINARI -> {
                // Multiple lightning bolts in a circle around target.
                for (int i = 0; i < 4; i++) {
                    double angle = i * Math.PI / 2 + RANDOM.nextDouble() * 0.5;
                    double bx = center.field_1352 + Math.cos(angle) * AOE_RADIUS * 0.7;
                    double bz = center.field_1350 + Math.sin(angle) * AOE_RADIUS * 0.7;
                    class_1538 bolt = class_1299.field_6112.method_5883(world);
                    if (bolt != null) {
                        bolt.method_24203(bx, center.field_1351, bz);
                        world.method_8649(bolt);
                    }
                }
            }
            case MORI -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11211, 80);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48830(), (float) (3.0 * power));
                    if (v instanceof class_3222 p) {
                        p.method_6092(new class_1293(class_1294.field_5899, 120, 1));
                        p.method_6092(new class_1293(class_1294.field_5903, 100, 1));
                    }
                }
            }
            case KORI -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_28013, 100);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48836(), (float) (5.0 * power));
                    if (v instanceof class_3222 p) p.method_6092(
                        new class_1293(class_1294.field_5909, 120, 3));
                }
            }
            case YUREI -> {
                spawnRing(world, center, AOE_RADIUS,
                    new class_2390(new Vector3f(0.8f, 0.4f, 1.0f), 1.5f), 100);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48831(), (float) (8.0 * power));
                    if (v instanceof class_3222 p) {
                        p.method_6092(new class_1293(class_1294.field_5911, 120, 1));
                        p.method_6092(new class_1293(class_1294.field_38092, 80, 0));
                    }
                }
            }
            case TENGOKU -> {
                spawnRing(world, center, AOE_RADIUS, class_2398.field_11207, 100);
                for (class_1309 v : victims) {
                    v.method_5643(world.method_48963().method_48831(), (float) (10.0 * power));
                    v.method_5639((int) Math.max(2, 3 * power));
                    if (v instanceof class_3222 p) p.method_6092(
                        new class_1293(class_1294.field_5912, 120, 0));
                }
            }
        }
    }

    // === BEAM (piercing line attack that hits multiple targets in line) ===

    private static void castBeam(class_3218 world, class_4019 fox, class_3222 target, Element element, double power) {
        class_243 from = fox.method_19538().method_1031(0, fox.method_17682() * 0.6, 0);
        class_243 dir = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0).method_1020(from).method_1029();
        class_243 to = from.method_1019(dir.method_1021(BEAM_RANGE));

        // Particle visualization.
        class_2394 beamParticle = beamParticleFor(element);
        int segments = 40;
        for (int i = 1; i <= segments; i++) {
            class_243 p = from.method_1019(dir.method_1021(BEAM_RANGE * i / segments));
            world.method_14199(beamParticle, p.field_1352, p.field_1351, p.field_1350, 2, 0.05, 0.05, 0.05, 0.0);
        }

        // Damage all living entities within BEAM_WIDTH of the beam line.
        class_238 scanBox = new class_238(
            Math.min(from.field_1352, to.field_1352) - BEAM_WIDTH, Math.min(from.field_1351, to.field_1351) - BEAM_WIDTH, Math.min(from.field_1350, to.field_1350) - BEAM_WIDTH,
            Math.max(from.field_1352, to.field_1352) + BEAM_WIDTH, Math.max(from.field_1351, to.field_1351) + BEAM_WIDTH, Math.max(from.field_1350, to.field_1350) + BEAM_WIDTH
        );
        List<class_1309> candidates = world.method_8390(class_1309.class, scanBox, e -> e != fox && e.method_5805());
        for (class_1309 entity : candidates) {
            class_243 entityPos = entity.method_19538().method_1031(0, entity.method_17682() * 0.5, 0);
            // Distance from point to line.
            class_243 toEntity = entityPos.method_1020(from);
            double projection = toEntity.method_1026(dir);
            if (projection < 0 || projection > BEAM_RANGE) continue;
            class_243 closest = from.method_1019(dir.method_1021(projection));
            double distFromLine = entityPos.method_1022(closest);
            if (distFromLine > BEAM_WIDTH) continue;

            applyBeamDamage(world, entity, element, power);
        }
    }

    private static void applyBeamDamage(class_3218 world, class_1309 victim, Element element, double power) {
        double dmg = 7.0 * power; // Beam hits hard but cooldown applies.
        switch (element) {
            case KASAI -> { victim.method_5643(world.method_48963().method_48813(), (float) dmg); victim.method_5639((int)(4 * power)); }
            case MIZU -> victim.method_5643(world.method_48963().method_48824(), (float) dmg);
            case DAICHI -> victim.method_5643(world.method_48963().method_48830(), (float)(dmg * 1.2));
            case KAZE -> victim.method_5643(world.method_48963().method_48830(), (float) dmg);
            case KAMINARI -> {
                victim.method_5643(world.method_48963().method_48809(), (float)(dmg * 1.1));
            }
            case MORI -> {
                victim.method_5643(world.method_48963().method_48830(), (float) dmg);
                if (victim instanceof class_3222 p) p.method_6092(
                    new class_1293(class_1294.field_5899, 100, 2));
            }
            case KORI -> {
                victim.method_5643(world.method_48963().method_48836(), (float) dmg);
                if (victim instanceof class_3222 p) p.method_6092(
                    new class_1293(class_1294.field_5909, 80, 3));
            }
            case YUREI -> {
                victim.method_5643(world.method_48963().method_48831(), (float)(dmg * 1.2));
                if (victim instanceof class_3222 p) p.method_6092(
                    new class_1293(class_1294.field_5920, 80, 0));
            }
            case TENGOKU -> {
                victim.method_5643(world.method_48963().method_48831(), (float)(dmg * 1.3));
                victim.method_5639((int)(3 * power));
                if (victim instanceof class_3222 p) p.method_6092(
                    new class_1293(class_1294.field_5912, 100, 0));
            }
        }
    }

    private static class_2394 beamParticleFor(Element element) {
        return switch (element) {
            case KASAI -> class_2398.field_11240;
            case MIZU -> class_2398.field_11202;
            case DAICHI -> class_2398.field_11205;
            case KAZE -> class_2398.field_11204;
            case KAMINARI -> class_2398.field_29644;
            case MORI -> class_2398.field_11211;
            case KORI -> class_2398.field_28013;
            case YUREI -> new class_2390(new Vector3f(0.8f, 0.4f, 1.0f), 1.5f);
            case TENGOKU -> class_2398.field_11207;
        };
    }

    private static void spawnRing(class_3218 world, class_243 center, double radius, class_2394 particle, int count) {
        for (int i = 0; i < count; i++) {
            double angle = i * 2 * Math.PI / count;
            double x = center.field_1352 + Math.cos(angle) * radius;
            double z = center.field_1350 + Math.sin(angle) * radius;
            world.method_14199(particle, x, center.field_1351 + 0.5, z, 1, 0.1, 0.3, 0.1, 0.05);
        }
    }

    private static void drawLine(class_3218 world, class_4019 fox, class_3222 target, class_2394 particle, int segments) {
        class_243 from = fox.method_19538().method_1031(0, fox.method_17682() * 0.6, 0);
        class_243 to = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);
        class_243 step = to.method_1020(from).method_1021(1.0 / segments);
        for (int i = 1; i <= segments; i++) {
            class_243 point = from.method_1019(step.method_1021(i));
            world.method_14199(particle, point.field_1352, point.field_1351, point.field_1350, 1, 0.1, 0.1, 0.1, 0.0);
        }
    }
}
