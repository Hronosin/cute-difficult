package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import java.util.Random;

/**
 * Two milestones of the friendship arc:
 *
 * <p><b>Sleeping pose:</b> at night and with trust ≥ {@link #SLEEP_TRUST},
 * a friendly kitsune curls up near the player. Implementation: forces
 * the sitting flag at night for eligible foxes, with little "zzz" smoke
 * particles above them periodically.
 *
 * <p><b>Petting:</b> right-click an eligible fox with an empty hand to
 * give it a pet. Each pet grants +1 trust, but only one per
 * {@link #PET_COOLDOWN_TICKS} per fox to keep it from being a grind
 * farm. Particles + a soft ambient sound.
 *
 * <p>The cooldown is per-fox (stored in KitsuneData.lastPettedTickStamp),
 * not per-player, so multiple players can pet the same fox without
 * stepping on each other but each fox limits its own affection budget.
 */
public final class FoxSleepAndPetHandler {

    private static final int SLEEP_TRUST = 50;
    /** 24000 ticks per Minecraft day; night is roughly 13000-23000. */
    private static final long NIGHT_START = 13000;
    private static final long NIGHT_END = 23000;

    private static final int PET_COOLDOWN_TICKS = 72000; // 1 hour real time
    private static final int PET_TRUST_GAIN = 1;

    /** How close the player must be for the fox to consider sleeping. */
    private static final double SLEEP_PLAYER_DISTANCE = 6.0;

    private static final Random RANDOM = new Random();

    private FoxSleepAndPetHandler() {}

    public static void register() {
        // Tick: manage sleeping pose for eligible foxes.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            for (class_3218 world : server.method_3738()) {
                long timeOfDay = world.method_8532() % 24000;
                boolean isNight = timeOfDay >= NIGHT_START && timeOfDay <= NIGHT_END;
                if (!isNight) continue;
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_4019 fox && fox.method_5805()) {
                        tickSleep(world, fox);
                    }
                }
            }
        });

        // Petting: empty-hand right-click on eligible fox.
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!(entity instanceof class_4019 fox)) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5811;
            if (hand != class_1268.field_5808) return class_1269.field_5811;
            if (!player.method_5998(hand).method_7960()) return class_1269.field_5811;

            return handlePet(serverWorld, sp, fox);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxSleepAndPetHandler registered.");
    }

    private static void tickSleep(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.peekCache(fox);
        if (data == null || data.trustLevel < SLEEP_TRUST) {
            return;
        }
        // Is a friendly player nearby?
        var nearest = world.method_8604(fox.method_23317(), fox.method_23318(), fox.method_23321(),
            SLEEP_PLAYER_DISTANCE,
            p -> p instanceof class_3222 sp && !sp.method_7325());
        if (nearest == null) return;

        // Set the sitting flag to use vanilla sleeping-fox pose.
        if (!fox.method_18272()) {
            fox.method_18294(true);
        }
        fox.method_5942().method_6340();

        // Occasionally spawn zzz smoke particles above the fox.
        if (world.method_8510() % 30 == 0 && RANDOM.nextInt(3) == 0) {
            world.method_14199(class_2398.field_11203,
                fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(),
                1, 0.05, 0.1, 0.05, 0.01);
        }
    }

    private static class_1269 handlePet(class_3218 world, class_3222 player, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        // Only pet eligible foxes — must have some baseline trust to enjoy it.
        if (data.trustLevel < 30) {
            player.method_7353(
                class_2561.method_43470("The kitsune flinches away. You haven't earned its trust.")
                    .method_27695(class_124.field_1063, class_124.field_1056),
                true
            );
            return class_1269.field_5814;
        }

        long now = world.method_8510();
        if (now - data.lastPettedTickStamp < PET_COOLDOWN_TICKS) {
            // Show particles anyway for the cuddle feeling, but no trust gain.
            world.method_14199(class_2398.field_11201,
                fox.method_23317(), fox.method_23318() + 0.6, fox.method_23321(),
                3, 0.2, 0.2, 0.2, 0.05);
            return class_1269.field_5812;
        }

        // Apply pet.
        KitsuneData updated = data.withTrust(data.trustLevel + PET_TRUST_GAIN)
                               .withLastPetted(now);
        FoxStorage.store(fox, updated);

        world.method_14199(class_2398.field_11201,
            fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(),
            5, 0.3, 0.3, 0.3, 0.1);
        world.method_43128(null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_18056, class_3419.field_15254, 0.7f, 1.5f);

        String displayName = data.customName.isEmpty()
            ? data.element.kamiName() + " kitsune"
            : data.customName;
        player.method_7353(
            class_2561.method_43470("You pet ")
                .method_27692(class_124.field_1076)
                .method_10852(class_2561.method_43470(displayName).method_27692(data.element.color()))
                .method_10852(class_2561.method_43470(". It accepts gladly.").method_27692(class_124.field_1076)),
            true
        );
        return class_1269.field_5812;
    }
}
