package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Set;

/**
 * Watches chat for two specific phrases that flip the world between modes.
 *
 * <p>The surrender phrase ("я казуал" / "i am casual" / "im casual") activates
 * Path of Peace. The redemption phrase ("я готов страдать" / "i am ready to
 * suffer") restores Cruel mode but applies the permanent Shame penalty.
 *
 * <p>Currently mode is server-global. Per-player tracking with persistent
 * state will come in v0.2 (data attachments on the player) so each member of
 * a multiplayer server walks their own path.
 *
 * <p>Note for the Iron Will achievement: we also passively log whether each
 * player has ever sent a message containing the word "casual" / "казуал" —
 * this lets us award the secret achievement at end-game without needing
 * the player to actively opt in to anything.
 */
public final class ChatCommandHandler {
    /** Phrases that activate Path of Peace. Match is case-insensitive, trimmed. */
    private static final Set<String> SURRENDER_PHRASES = Set.of(
        "я казуал",
        "i am casual",
        "im casual",
        "i'm casual"
    );

    /** Phrases that bring the player back to Cruel mode. */
    private static final Set<String> REDEMPTION_PHRASES = Set.of(
        "я готов страдать",
        "i am ready to suffer",
        "im ready to suffer"
    );

    private ChatCommandHandler() {}

    public static void register() {
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String content = message.method_46291().getString().trim().toLowerCase();

            if (SURRENDER_PHRASES.contains(content)) {
                activatePathOfPeace(sender);
            } else if (REDEMPTION_PHRASES.contains(content)) {
                activateRedemption(sender);
            }
            // TODO: detect partial mentions ("это слишком сложно") to trigger
            // gaslighting reminders in player chat.
        });
    }

    private static void activatePathOfPeace(class_3222 player) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;

        CuteDifficult.currentMode = DifficultyMode.PATH_OF_PEACE;

        // Restore HP to vanilla.
        player.method_7353(
                net.minecraft.class_2561.method_43470("You have chosen the Path of Peace.")
                        .method_27695(net.minecraft.class_124.field_1075, net.minecraft.class_124.field_1056),
                false
        );

        // Public announcement — the shame is part of the mechanic.
        class_2561 announcement = class_2561.method_43470("[LOSS OF SPIRIT] ")
            .method_27692(class_124.field_1063)
            .method_10852(class_2561.method_43470(player.method_5477().getString())
                .method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(" has chosen the Path of Peace. The kitsune grieve.")
                .method_27695(class_124.field_1080, class_124.field_1056));

        server.method_3760().method_43514(announcement, false);

        CuteDifficult.LOGGER.info(
            "[CuteDifficult] Player {} surrendered to Path of Peace.",
            player.method_5477().getString()
        );
    }

    private static void activateRedemption(class_3222 player) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;

        if (CuteDifficult.currentMode != DifficultyMode.PATH_OF_PEACE) {
            player.method_7353(
                class_2561.method_43470("You have not yet fallen. There is nothing to return from.")
                    .method_27695(class_124.field_1063, class_124.field_1056),
                false
            );
            return;
        }

        CuteDifficult.currentMode = DifficultyMode.CRUEL;
        player.method_7353(
                net.minecraft.class_2561.method_43470("You return to suffering. The cruel world watches you again.")
                        .method_27695(net.minecraft.class_124.field_1079, net.minecraft.class_124.field_1056),
                false
        );

        class_2561 announcement = class_2561.method_43470("[RETURNED] ")
            .method_27692(class_124.field_1065)
            .method_10852(class_2561.method_43470(player.method_5477().getString())
                .method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470(" walks the cruel road once more. A scar remains.")
                .method_27695(class_124.field_1054, class_124.field_1056));

        server.method_3760().method_43514(announcement, false);
    }
}
