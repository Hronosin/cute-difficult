package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Per-element passive blessings, with a "Great Blessing of Inari"
 * unlock when all nine are simultaneously active.
 *
 * <p><b>Mechanic:</b>
 * <ul>
 *   <li>Each element has its own threshold ({@link #BLESSING_THRESHOLD})
 *       on its Spirit value. When Spirit ≥ threshold for an element,
 *       that element's blessing is active.</li>
 *   <li>Each active blessing grants its own pair of status effects.
 *       All 9 can stack simultaneously.</li>
 *   <li>When ALL 9 are active, "Great Blessing of Inari" engages —
 *       a dramatic chat announcement plus the
 *       {@link FoxPeaceMode} flag is set on the player, making all
 *       kitsune neutral to them regardless of trust/witness status.</li>
 *   <li>When the player drops below 9 simultaneously, the great
 *       blessing disengages and kitsune resume normal behavior toward
 *       them (witnessed killings etc. take effect again).</li>
 * </ul>
 *
 * <p>Refresh interval {@link #REFRESH_INTERVAL} = 200 ticks (10s). All
 * status effects renewed with duration > refresh to avoid flicker.
 * Chat announcements only fire on state change.
 */
public final class ResonanceBlessingHandler {

    /** Spirit threshold per element to enable its blessing. */
    public static final int BLESSING_THRESHOLD = 10;

    private static final int REFRESH_INTERVAL = 200;
    private static final int EFFECT_DURATION = 300;

    /** Last-seen set of active elements per player — for change detection. */
    private static final Map<UUID, EnumSet<Element>> LAST_ACTIVE = new HashMap<>();

    /** Players currently holding the Great Blessing of Inari. */
    public static final Set<UUID> GREAT_BLESSING_PLAYERS = java.util.concurrent.ConcurrentHashMap.newKeySet();

    private static long tickCounter = 0;

    private ResonanceBlessingHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            tickCounter++;
            if (tickCounter % REFRESH_INTERVAL != 0) return;

            for (class_3222 player : server.method_3760().method_14571()) {
                // v0.9.6: removed isCreative() skip — creative players should
                // still see blessings (essential for testing the system at all).
                // Spectator stays skipped — they're invisible observers.
                if (player.method_7325()) continue;
                refreshPlayer(server, player);
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] ResonanceBlessingHandler registered (9-element model).");
    }

    private static void refreshPlayer(MinecraftServer server, class_3222 player) {
        EnumSet<Element> active = EnumSet.noneOf(Element.class);
        StringBuilder debugSpirits = new StringBuilder();
        for (Element element : Element.values()) {
            int value = SpiritData.get(server, player, element);
            debugSpirits.append(element.name()).append("=").append(value).append(" ");
            if (value >= BLESSING_THRESHOLD) {
                active.add(element);
            }
        }

        // Debug log once per refresh cycle.
        CuteDifficult.LOGGER.info(
            "[CuteDifficult] Blessing refresh for {}: {} | active={} | threshold={}",
            player.method_5477().getString(), debugSpirits.toString().trim(),
            active, BLESSING_THRESHOLD);

        EnumSet<Element> previous = LAST_ACTIVE.computeIfAbsent(player.method_5667(), k -> EnumSet.noneOf(Element.class));

        // Apply effects for each active element.
        for (Element element : active) {
            applyElementBlessing(player, element);
        }

        // Detect newly-activated blessings for chat announcement.
        EnumSet<Element> justActivated = EnumSet.copyOf(active);
        justActivated.removeAll(previous);
        for (Element e : justActivated) {
            player.method_7353(
                class_2561.method_43470("✦ Blessing of Inari — " + e.kamiName() + " ✦")
                    .method_27695(e.color(), class_124.field_1067),
                false
            );
        }

        // Detect just-lost blessings for muted "fade" message.
        EnumSet<Element> justLost = EnumSet.copyOf(previous);
        justLost.removeAll(active);
        for (Element e : justLost) {
            player.method_7353(
                class_2561.method_43470(e.kamiName() + "'s favor fades.")
                    .method_27695(class_124.field_1063, class_124.field_1056),
                false
            );
        }

        // Great Blessing — all 9 active.
        boolean wasGreat = GREAT_BLESSING_PLAYERS.contains(player.method_5667());
        boolean isGreat = active.size() == Element.values().length;

        if (isGreat) {
            GREAT_BLESSING_PLAYERS.add(player.method_5667());
            // Apply persistent regen/saturation on top of the per-element effects.
            player.method_6092(new class_1293(
                class_1294.field_5924, EFFECT_DURATION, 1, false, false, true));
            player.method_6092(new class_1293(
                class_1294.field_5922, EFFECT_DURATION, 0, false, false, true));
            if (!wasGreat) {
                player.method_7353(class_2561.method_43470("").method_27692(class_124.field_1065), false);
                player.method_7353(
                    class_2561.method_43470("══════════════════════").method_27692(class_124.field_1065),
                    false
                );
                player.method_7353(
                    class_2561.method_43470("✦ GREAT BLESSING OF INARI ✦")
                        .method_27695(class_124.field_1065, class_124.field_1067),
                    false
                );
                player.method_7353(
                    class_2561.method_43470("All kitsune now walk in peace with you.")
                        .method_27695(class_124.field_1054, class_124.field_1056),
                    false
                );
                player.method_7353(
                    class_2561.method_43470("══════════════════════").method_27692(class_124.field_1065),
                    false
                );
            }
        } else {
            GREAT_BLESSING_PLAYERS.remove(player.method_5667());
            if (wasGreat) {
                player.method_7353(
                    class_2561.method_43470("The Great Blessing wanes. The kitsune watch you again.")
                        .method_27695(class_124.field_1079, class_124.field_1056),
                    false
                );
            }
        }

        LAST_ACTIVE.put(player.method_5667(), active);
    }

    /**
     * Public query for other handlers — does this player currently have
     * the Great Blessing (and thus deserve kitsune peace)?
     */
    public static boolean hasGreatBlessing(class_3222 player) {
        return GREAT_BLESSING_PLAYERS.contains(player.method_5667());
    }

    private static void applyElementBlessing(class_3222 player, Element element) {
        switch (element) {
            case KASAI -> apply(player, class_1294.field_5918, 0);
            case MIZU -> {
                apply(player, class_1294.field_5923, 0);
                apply(player, class_1294.field_5900, 0);
            }
            case DAICHI -> apply(player, class_1294.field_5907, 0);
            case KAZE -> {
                apply(player, class_1294.field_5904, 0);
                apply(player, class_1294.field_5913, 0);
            }
            case KAMINARI -> apply(player, class_1294.field_5910, 0);
            case MORI -> apply(player, class_1294.field_5924, 0);
            case KORI -> apply(player, class_1294.field_5906, 0);
            case YUREI -> apply(player, class_1294.field_5925, 0);
            case TENGOKU -> apply(player, class_1294.field_18980, 0);
        }
    }

    private static void apply(class_3222 player, class_6880<class_1291> effect, int amp) {
        boolean result = player.method_6092(new class_1293(
            effect, EFFECT_DURATION, amp, false, false, true));
        CuteDifficult.LOGGER.info(
            "[CuteDifficult] Applied effect to {}: result={}",
            player.method_5477().getString(), result);
    }
}
