package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxStats;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4019;
import java.util.Random;

/**
 * Gives Yurei (spirit) and Tengoku (sky) foxes the ability to hover and
 * fly when they reach 5+ tails.
 *
 * <p><b>Implementation:</b> we don't replace navigation — that would
 * require swapping {@link net.minecraft.class_1409}
 * for {@link net.minecraft.class_1407} which is
 * mostly inaccessible without reflection. Instead we:
 * <ol>
 *   <li>Set {@link class_1297#method_5875(boolean)} = true so the fox doesn't
 *       fall.</li>
 *   <li>Maintain a target hover height of {@link #IDLE_HOVER_HEIGHT}
 *       blocks above ground. The fox is gently nudged toward this height
 *       each tick.</li>
 *   <li>When a player is in range, drift toward the player (slowly) while
 *       maintaining hover. This makes flying kitsune feel "stalking" —
 *       they don't attack but they follow you in the air.</li>
 * </ol>
 *
 * <p><b>Visual quirk:</b> vanilla fox model isn't drawn for flight, so a
 * flying Kyuubi will look like a fox standing in the air. Combined with
 * the dense particle aura at 5+ tails, this still reads as "supernatural
 * floating entity" — but a custom render model would be nicer. Out of
 * scope for v0.3.x.
 *
 * <p>Active only in CRUEL mode.
 */
public final class FoxFlightHandler {

    /** Target altitude above ground when hovering idly. */
    private static final double IDLE_HOVER_HEIGHT = 4.0;

    /** Vertical movement speed when adjusting height. */
    private static final double VERTICAL_SPEED = 0.1;

    /** Horizontal drift speed when following a player. */
    private static final double FOLLOW_SPEED = 0.08;

    /** Radius within which a flying fox starts following a player. */
    private static final double FOLLOW_RADIUS = 24.0;

    /** Minimum distance to keep from player — won't get closer than this. */
    private static final double MIN_FOLLOW_DISTANCE = 8.0;

    private static final Random RANDOM = new Random();

    private FoxFlightHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_4019 fox && fox.method_5805()) {
                        maybeFly(world, fox);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxFlightHandler registered.");
    }

    private static void maybeFly(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);

        if (!FoxStats.canFly(data.element, data.tails)) {
            // Defensive: if this fox isn't supposed to fly but somehow has
            // no-gravity set (e.g., from a previous state), clear it.
            if (fox.method_5740()) {
                fox.method_5875(false);
            }
            return;
        }

        // Ensure no-gravity is active.
        if (!fox.method_5740()) {
            fox.method_5875(true);
        }

        // Determine target altitude: ground level + hover height.
        double groundY = findGroundY(world, fox);
        double targetY = groundY + IDLE_HOVER_HEIGHT;

        // Compute desired velocity.
        class_243 currentVel = fox.method_18798();
        double vy = 0;
        if (fox.method_23318() < targetY - 0.5) {
            vy = VERTICAL_SPEED;
        } else if (fox.method_23318() > targetY + 0.5) {
            vy = -VERTICAL_SPEED * 0.5;
        } else {
            // Within hover band — small sinusoidal bob for life.
            vy = Math.sin(world.method_8510() * 0.05 + fox.method_5628()) * 0.02;
        }

        // Horizontal: follow nearest player at a respectful distance.
        double vx = 0;
        double vz = 0;
        class_1657 player = world.method_18460(fox, FOLLOW_RADIUS);
        if (player != null) {
            double dx = player.method_23317() - fox.method_23317();
            double dz = player.method_23321() - fox.method_23321();
            double dist = Math.sqrt(dx*dx + dz*dz);
            if (dist > MIN_FOLLOW_DISTANCE) {
                // Drift toward player.
                vx = (dx / dist) * FOLLOW_SPEED;
                vz = (dz / dist) * FOLLOW_SPEED;
            }
            // If within MIN_FOLLOW_DISTANCE, hover in place.
        }

        fox.method_18800(vx, vy, vz);
        fox.field_6037 = true;
    }

    /**
     * Find the Y coordinate of the highest solid block at the fox's
     * X/Z column. Used to compute target hover altitude.
     */
    private static double findGroundY(class_3218 world, class_4019 fox) {
        int x = fox.method_31477();
        int z = fox.method_31479();
        int topY = world.method_8624(net.minecraft.class_2902.class_2903.field_13203, x, z);
        return topY;
    }
}
