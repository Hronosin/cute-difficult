package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.entity.ModEntities;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxPersonality;
import com.cutedifficult.spirit.FoxStats;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4019;
import net.minecraft.class_6880;
import java.util.Optional;
import java.util.Random;

/**
 * Replaces vanilla foxes with our custom {@link KitsuneEntity} on spawn,
 * and assigns initial element/tails/personality data to fresh kitsunes.
 *
 * <p><b>v0.3.4 flow:</b>
 * <ol>
 *   <li>Vanilla {@link class_4019} spawns (natural, command, etc).</li>
 *   <li>Our ENTITY_LOAD listener fires.</li>
 *   <li>If the entity is FoxEntity but NOT KitsuneEntity, discard it and
 *       spawn a fresh KitsuneEntity at the same position with our spirit
 *       data already attached.</li>
 *   <li>If it's a KitsuneEntity (e.g. loaded from disk on chunk load),
 *       just ensure its HP matches its tail count.</li>
 * </ol>
 *
 * <p>Result: there are no vanilla foxes in the world. Every {@code /summon fox},
 * every natural spawn, every chunk that comes online with old foxes — all
 * become kitsune.
 */
public final class FoxSpawnHandler {

    private static final Random RANDOM = new Random();
    private static final double THUNDER_KAMINARI_CHANCE = 0.25;

    private FoxSpawnHandler() {}

    public static void register() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(entity instanceof class_4019 fox)) return;

            // Already our kitsune — just sync HP if needed using cache data.
            if (fox instanceof KitsuneEntity) {
                KitsuneData cached = FoxStorage.peekCache(fox);
                if (cached != null) {
                    FoxStats.applyHpForTails(fox, cached.tails);
                }
                return;
            }

            // Vanilla fox — replace it with a kitsune at the same position.
            replaceWithKitsune(world, fox);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxSpawnHandler registered (kitsune replacement active).");
    }

    private static void replaceWithKitsune(class_3218 world, class_4019 fox) {
        double x = fox.method_23317();
        double y = fox.method_23318();
        double z = fox.method_23321();
        float yaw = fox.method_36454();
        float pitch = fox.method_36455();
        class_2338 pos = fox.method_24515();

        // Get rid of the vanilla fox.
        fox.method_31472();

        // Spawn a kitsune.
        KitsuneEntity kitsune = ModEntities.KITSUNE.method_5883(world);
        if (kitsune == null) {
            CuteDifficult.LOGGER.error("[CuteDifficult] Failed to create KitsuneEntity for replacement.");
            return;
        }
        kitsune.method_5808(x, y, z, yaw, pitch);

        // Assign element, tails, personality.
        Element element = selectElement(world, pos);
        int tails = rollTails();
        FoxPersonality personality = FoxPersonality.random(RANDOM);
        KitsuneData data = KitsuneData.of6(element, personality, tails, 0, 0L, 0);
        FoxStorage.store(kitsune, data);
        FoxStats.applyHpForTails(kitsune, tails);

        world.method_8649(kitsune);

        if (tails >= 5) {
            CuteDifficult.LOGGER.info(
                "[CuteDifficult] Rare kitsune spawned: {} with {} tails ({} HP) at {}",
                element.kamiName(), tails, (int)FoxStats.hpForTails(tails),
                pos.method_23854()
            );
        }
    }

    private static int rollTails() {
        double r = RANDOM.nextDouble();
        if (r < 0.65)    return 1;
        if (r < 0.85)    return 2;
        if (r < 0.95)    return 3;
        if (r < 0.98)    return 4;
        if (r < 0.995)   return 5;
        if (r < 0.999)   return 6;
        if (r < 0.9998)  return 7;
        if (r < 0.99998) return 8;
        return 9;
    }

    private static Element selectElement(class_3218 world, class_2338 pos) {
        if (world.method_8546() && RANDOM.nextDouble() < THUNDER_KAMINARI_CHANCE) {
            return Element.KAMINARI;
        }
        Element fromBiome = elementForBiome(world, pos);
        if (fromBiome != null) return fromBiome;
        return Element.random(RANDOM);
    }

    private static Element elementForBiome(class_3218 world, class_2338 pos) {
        class_6880<class_1959> entry = world.method_23753(pos);
        var keyOpt = entry.method_40230();
        if (keyOpt.isEmpty()) return null;

        String path = keyOpt.get().method_29177().method_12832();

        if (path.contains("snowy") || path.contains("frozen")
            || path.equals("ice_spikes") || path.contains("grove")) return Element.KORI;
        if (path.contains("jungle") || path.contains("forest")
            || path.contains("taiga") || path.equals("flower_forest")
            || path.equals("birch_forest")) return Element.MORI;
        if (path.contains("savanna") || path.equals("desert")
            || path.contains("badlands")) return Element.KASAI;
        if (path.contains("nether") || path.equals("basalt_deltas")
            || path.equals("crimson_forest") || path.equals("warped_forest")
            || path.equals("soul_sand_valley")) return Element.KASAI;
        if (path.contains("peaks") || path.contains("hills")
            || path.equals("stony_shore") || path.equals("meadow")) return Element.DAICHI;
        if (path.equals("dripstone_caves")) return Element.DAICHI;
        if (path.equals("lush_caves")) return Element.MORI;
        if (path.equals("deep_dark")) return Element.YUREI;
        if (path.contains("windswept")) return Element.KAZE;
        if (path.contains("ocean") || path.equals("river")
            || path.equals("frozen_river") || path.contains("beach")
            || path.contains("swamp") || path.equals("mangrove_swamp")) return Element.MIZU;
        if (path.contains("end")) return Element.TENGOKU;

        return null;
    }
}
