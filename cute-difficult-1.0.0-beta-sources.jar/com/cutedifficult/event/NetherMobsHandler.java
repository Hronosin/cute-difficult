package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1545;
import net.minecraft.class_1571;
import net.minecraft.class_1589;
import net.minecraft.class_1677;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5419;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Buffs to Nether mobs — making them "actual devils" per design.
 *
 * <ul>
 *   <li><b>Blazes:</b> periodically fire a 3-ball fan instead of a single
 *       fireball — wider area threat, harder to dodge.</li>
 *   <li><b>Ghasts:</b> when HP drops below 50% the first time, spawn ONE
 *       smaller ghast as a child (mini-ghast = scaled-down HP). The
 *       mini-ghast cannot itself summon. Hard-capped chain.</li>
 *   <li><b>Magma cubes:</b> if airborne for &gt; 0.6s (long fall) and
 *       hit ground, briefly explode in a fiery puff dealing damage and
 *       knockback. Doesn't damage blocks.</li>
 *   <li><b>Piglin brutes:</b> at HP &lt; 30%, enter "blood frenzy" — gain
 *       Strength II for 10s. Visible red particle aura while active.</li>
 * </ul>
 *
 * <p><b>Anti-exponential safety:</b> ghasts can only summon ONCE. The
 * summoned mini-ghast is marked in {@link #IS_MINI_GHAST} and cannot
 * trigger its own summon.
 */
public final class NetherMobsHandler {

    /** Blaze fan-fire cooldown. */
    private static final int BLAZE_FAN_COOLDOWN = 100; // 5s
    private static final double BLAZE_TARGET_RANGE = 16.0;

    /** Ghast summon: only one mini per ghast lifetime. */
    private static final Set<UUID> GHAST_HAS_SUMMONED = new HashSet<>();
    private static final Set<UUID> IS_MINI_GHAST = new HashSet<>();

    /** Magma cube fall tracking — ticks airborne. */
    private static final WeakHashMap<UUID, Integer> MAGMA_AIRBORNE_TICKS = new WeakHashMap<>();
    private static final int MAGMA_AIRBORNE_THRESHOLD = 12; // 0.6s

    /** Brute frenzy: tracks last trigger so we don't spam. */
    private static final WeakHashMap<UUID, Long> BRUTE_LAST_FRENZY = new WeakHashMap<>();
    private static final int BRUTE_FRENZY_COOLDOWN = 600; // 30s

    private static final WeakHashMap<UUID, Long> BLAZE_LAST_FAN = new WeakHashMap<>();
    private static final Random RANDOM = new Random();

    private NetherMobsHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (!entity.method_5805()) continue;
                    if (entity instanceof class_1545 blaze) tickBlaze(world, blaze);
                    else if (entity instanceof class_1571 ghast) tickGhast(world, ghast);
                    else if (entity instanceof class_1589 mc) tickMagmaCube(world, mc);
                    else if (entity instanceof class_5419 brute) tickBrute(world, brute);
                }
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] NetherMobsHandler registered.");
    }

    // ===== BLAZE =====

    private static void tickBlaze(class_3218 world, class_1545 blaze) {
        class_1309 target = blaze.method_5968();
        if (!(target instanceof class_3222 sp)) return;
        if (sp.method_7337() || sp.method_7325()) return;
        double dist = blaze.method_5739(sp);
        if (dist > BLAZE_TARGET_RANGE) return;

        UUID id = blaze.method_5667();
        long now = world.method_8510();
        Long lastFan = BLAZE_LAST_FAN.get(id);
        if (lastFan != null && now - lastFan < BLAZE_FAN_COOLDOWN) return;
        BLAZE_LAST_FAN.put(id, now);

        // Fire 3 small fireballs in a fan toward target.
        class_243 toTarget = sp.method_19538().method_1031(0, sp.method_5751() * 0.5, 0)
            .method_1020(blaze.method_19538().method_1031(0, blaze.method_5751(), 0)).method_1029();
        class_243 perpendicular = new class_243(-toTarget.field_1350, 0, toTarget.field_1352);

        for (int i = -1; i <= 1; i++) {
            class_243 dir = toTarget.method_1019(perpendicular.method_1021(0.15 * i)).method_1029();
            class_1677 ball = new class_1677(world, blaze,
                new class_243(dir.field_1352, dir.field_1351, dir.field_1350).method_1021(1.0));
            ball.method_5814(blaze.method_23317(), blaze.method_23318() + 1.0, blaze.method_23321());
            world.method_8649(ball);
        }

        world.method_43128(null, blaze.method_23317(), blaze.method_23318(), blaze.method_23321(),
            class_3417.field_14970, class_3419.field_15251, 1.5f, 0.9f);
    }

    // ===== GHAST =====

    private static void tickGhast(class_3218 world, class_1571 ghast) {
        UUID id = ghast.method_5667();
        if (IS_MINI_GHAST.contains(id)) return; // mini ghasts never summon
        if (GHAST_HAS_SUMMONED.contains(id)) return;
        if (ghast.method_6032() / ghast.method_6063() > 0.5f) return;

        // Spawn one mini-ghast nearby.
        class_1571 mini = class_1299.field_6107.method_5883(world);
        if (mini == null) return;
        double dx = (RANDOM.nextDouble() - 0.5) * 6;
        double dz = (RANDOM.nextDouble() - 0.5) * 6;
        mini.method_5808(ghast.method_23317() + dx, ghast.method_23318(), ghast.method_23321() + dz, 0, 0);
        // Reduce HP via attribute — set max to 5 instead of 10.
        var hpAttr = mini.method_5996(net.minecraft.class_5134.field_23716);
        if (hpAttr != null) hpAttr.method_6192(5.0);
        mini.method_6033(5.0f);
        world.method_8649(mini);

        IS_MINI_GHAST.add(mini.method_5667());
        GHAST_HAS_SUMMONED.add(id);

        world.method_14199(class_2398.field_22246,
            ghast.method_23317(), ghast.method_23318(), ghast.method_23321(), 30, 1, 1, 1, 0.1);
        world.method_43128(null, ghast.method_23317(), ghast.method_23318(), ghast.method_23321(),
            class_3417.field_14958, class_3419.field_15251, 2.0f, 1.4f);
    }

    // ===== MAGMA CUBE =====

    private static void tickMagmaCube(class_3218 world, class_1589 mc) {
        if (mc.method_7152() < 2) return; // only medium/large
        UUID id = mc.method_5667();
        boolean onGround = mc.method_24828();
        Integer airTicks = MAGMA_AIRBORNE_TICKS.getOrDefault(id, 0);

        if (!onGround) {
            MAGMA_AIRBORNE_TICKS.put(id, airTicks + 1);
            return;
        }

        // Just landed — was it a meaningful fall?
        if (airTicks >= MAGMA_AIRBORNE_THRESHOLD) {
            doFieryPuffExplosion(world, mc);
        }
        MAGMA_AIRBORNE_TICKS.put(id, 0);
    }

    private static void doFieryPuffExplosion(class_3218 world, class_1589 mc) {
        // Visual + sound (no block damage).
        world.method_14199(class_2398.field_11236,
            mc.method_23317(), mc.method_23318() + 0.5, mc.method_23321(), 5, 0.5, 0.3, 0.5, 0);
        world.method_14199(class_2398.field_11239,
            mc.method_23317(), mc.method_23318() + 0.5, mc.method_23321(), 20, 1, 0.5, 1, 0.2);
        world.method_43128(null, mc.method_23317(), mc.method_23318(), mc.method_23321(),
            class_3417.field_15152.comp_349(), class_3419.field_15251, 1.2f, 1.3f);

        double radius = 2.5 + mc.method_7152() * 0.5;
        var box = new net.minecraft.class_238(
            mc.method_23317() - radius, mc.method_23318() - 1, mc.method_23321() - radius,
            mc.method_23317() + radius, mc.method_23318() + 2, mc.method_23321() + radius);
        for (class_1297 e : world.method_8335(mc, box)) {
            if (e instanceof class_1589) continue;
            if (e instanceof class_1309 living) {
                living.method_5643(world.method_48963().method_48813(), 4.0f);
                living.method_5639(4);
                class_243 kb = e.method_19538().method_1020(mc.method_19538()).method_1029().method_1021(0.6);
                e.method_18799(e.method_18798().method_1031(kb.field_1352, 0.4, kb.field_1350));
                e.field_6037 = true;
            }
        }
    }

    // ===== PIGLIN BRUTE =====

    private static void tickBrute(class_3218 world, class_5419 brute) {
        if (brute.method_6032() / brute.method_6063() > 0.3f) return;

        UUID id = brute.method_5667();
        long now = world.method_8510();
        Long lastFrenzy = BRUTE_LAST_FRENZY.get(id);
        if (lastFrenzy != null && now - lastFrenzy < BRUTE_FRENZY_COOLDOWN) return;

        // Engage frenzy.
        brute.method_6092(new net.minecraft.class_1293(
            net.minecraft.class_1294.field_5910, 200, 1, false, true, true));
        brute.method_6092(new net.minecraft.class_1293(
            net.minecraft.class_1294.field_5904, 200, 0, false, true, true));
        BRUTE_LAST_FRENZY.put(id, now);

        world.method_14199(class_2398.field_11231,
            brute.method_23317(), brute.method_23318() + 2, brute.method_23321(), 15, 0.5, 0.3, 0.5, 0.05);
        world.method_43128(null, brute.method_23317(), brute.method_23318(), brute.method_23321(),
            class_3417.field_25729, class_3419.field_15251, 1.5f, 0.7f);
    }
}
