package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1588;
import net.minecraft.class_1593;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2473;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_8111;
import java.util.List;
import java.util.Random;

/**
 * Element-specific passive abilities. All kitsune have these from tail 1.
 *
 * <p>Two layers:
 * <ul>
 *   <li><b>Environmental aura</b> — runs every {@link #AURA_INTERVAL} ticks.
 *       Modifies blocks/weather/light/entities in a small radius around
 *       the kitsune. Examples: Kasai melts ice, Mori speeds plant growth.</li>
 *   <li><b>Damage immunity</b> — runs synchronously via the damage event.
 *       Foxes of certain elements ignore damage from sources thematic to
 *       them (Kasai → fire, Kaminari → lightning, etc).</li>
 * </ul>
 *
 * <p>Performance: scans all FoxEntity / KitsuneEntity in each world once
 * per aura interval. The interval is 40 ticks (2 seconds) — slow enough
 * that hundreds of foxes stay cheap, fast enough that effects feel
 * immediate.
 */
public final class KitsunePassivesHandler {

    /** How often the aura tick runs. 40 ticks = 2 seconds. */
    private static final int AURA_INTERVAL = 40;
    private static long tickCounter = 0;
    private static final Random RANDOM = new Random();

    private KitsunePassivesHandler() {}

    public static void register() {
        // Environmental aura tick.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            tickCounter++;
            if (tickCounter % AURA_INTERVAL != 0) return;
            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof KitsuneEntity kitsune && kitsune.method_5805()) {
                        applyAura(world, kitsune);
                    }
                }
            }
        });

        // Damage immunity check.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof KitsuneEntity kitsune)) return true;
            KitsuneData data = FoxStorage.peekCache(kitsune);
            if (data == null) return true;
            return !isImmune(data.element, source);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] KitsunePassivesHandler registered.");
    }

    /**
     * Should this kitsune ignore damage from this source based on its element?
     */
    private static boolean isImmune(Element element, class_1282 source) {
        return switch (element) {
            case KASAI -> source.method_49708(class_8111.field_42335) || source.method_49708(class_8111.field_42337)
                    || source.method_49708(class_8111.field_42338) || source.method_49708(class_8111.field_42339);
            case MIZU -> source.method_49708(class_8111.field_42342);
            case KAMINARI -> source.method_49708(class_8111.field_42336);
            case KORI -> source.method_49708(class_8111.field_42354);
            case YUREI -> source.method_49708(class_8111.field_42349) || source.method_49708(class_8111.field_42350)
                    || source.method_49708(class_8111.field_42329);
            case TENGOKU -> source.method_49708(class_8111.field_42345) || source.method_49708(class_8111.field_42346);
            case DAICHI -> source.method_49708(class_8111.field_42340) || source.method_49708(class_8111.field_42355);
            case MORI -> false; // Mori protects via poison cleanup, not damage immunity
            case KAZE -> source.method_49708(class_8111.field_42345);
        };
    }

    private static void applyAura(class_3218 world, KitsuneEntity fox) {
        KitsuneData data = FoxStorage.peekCache(fox);
        if (data == null) return;
        class_2338 pos = fox.method_24515();

        switch (data.element) {
            case KASAI -> auraKasai(world, fox, pos);
            case MIZU -> auraMizu(world, fox, pos);
            case DAICHI -> auraDaichi(world, fox, pos);
            case KAZE -> auraKaze(world, fox, pos);
            case KAMINARI -> auraKaminari(world, fox, pos);
            case MORI -> auraMori(world, fox, pos);
            case KORI -> auraKori(world, fox, pos);
            case YUREI -> auraYurei(world, fox, pos);
            case TENGOKU -> auraTengoku(world, fox, pos);
        }

        // Mori bonus: foxes immune to poison via status effect cleansing.
        if (data.element == Element.MORI && fox.method_6059(class_1294.field_5899)) {
            fox.method_6016(class_1294.field_5899);
        }
        // Mizu bonus: never drown.
        if (data.element == Element.MIZU) {
            fox.method_5855(fox.method_5748());
        }
        // Tengoku bonus: emits a faint glow particle so it's visible at night.
        if (data.element == Element.TENGOKU) {
            world.method_14199(class_2398.field_11207,
                    fox.method_23317(), fox.method_23318() + 0.5, fox.method_23321(),
                    1, 0.2, 0.2, 0.2, 0.01);
        }
    }

    // ===== Kasai — melts ice and snow, ignites flammable blocks =====
    private static void auraKasai(class_3218 world, KitsuneEntity fox, class_2338 center) {
        scanRadius(world, center, 6, (p, state) -> {
            if (state.method_27852(class_2246.field_10295) || state.method_27852(class_2246.field_10225)) {
                world.method_8501(p, class_2246.field_10382.method_9564());
                world.method_14199(class_2398.field_11251, p.method_10263()+0.5, p.method_10264()+0.5, p.method_10260()+0.5, 2, 0.2, 0.2, 0.2, 0.01);
            } else if (state.method_27852(class_2246.field_10477) || state.method_27852(class_2246.field_10491)) {
                world.method_8501(p, class_2246.field_10124.method_9564());
                world.method_14199(class_2398.field_11251, p.method_10263()+0.5, p.method_10264()+0.5, p.method_10260()+0.5, 1, 0.1, 0.1, 0.1, 0.01);
            } else if (state.method_27852(class_2246.field_10384)) {
                world.method_8501(p, class_2246.field_10295.method_9564());
            }
        });
    }

    // ===== Mizu — extinguishes fires, hydrates farmland =====
    private static void auraMizu(class_3218 world, KitsuneEntity fox, class_2338 center) {
        scanRadius(world, center, 6, (p, state) -> {
            if (state.method_27852(class_2246.field_10036) || state.method_27852(class_2246.field_22089)) {
                world.method_8501(p, class_2246.field_10124.method_9564());
            } else if (state.method_27852(class_2246.field_10362)) {
                // Set moisture to max.
                class_2680 moistFarm = class_2246.field_10362.method_9564()
                        .method_11657(net.minecraft.class_2344.field_11009, 7);
                if (!state.equals(moistFarm)) {
                    world.method_8501(p, moistFarm);
                }
            }
        });
    }

    // ===== Daichi — restores natural stone (cobble → stone) =====
    private static void auraDaichi(class_3218 world, KitsuneEntity fox, class_2338 center) {
        scanRadius(world, center, 4, (p, state) -> {
            if (state.method_27852(class_2246.field_10445) && RANDOM.nextInt(20) == 0) {
                world.method_8501(p, class_2246.field_10340.method_9564());
            } else if (state.method_27852(class_2246.field_10566) && world.method_8320(p.method_10084()).method_26215()
                    && RANDOM.nextInt(30) == 0) {
                world.method_8501(p, class_2246.field_10219.method_9564());
            }
        });
    }

    // ===== Kaze — light push on nearby entities, no harm =====
    private static void auraKaze(class_3218 world, KitsuneEntity fox, class_2338 center) {
        class_238 box = new class_238(center).method_1014(8);
        for (class_1309 le : world.method_8390(class_1309.class, box, e -> e != fox)) {
            // Just a gentle outward push.
            class_243 outward = le.method_19538().method_1020(fox.method_19538()).method_1029().method_1021(0.05);
            le.method_5762(outward.field_1352, 0.02, outward.field_1350);
            le.field_6037 = true;
        }
    }

    // ===== Kaminari — strike a hostile mob with mini-lightning, charge copper =====
    private static void auraKaminari(class_3218 world, KitsuneEntity fox, class_2338 center) {
        if (RANDOM.nextInt(10) != 0) return; // 10% per aura tick = ~once per 20s avg
        class_238 box = new class_238(center).method_1014(10);
        var hostiles = world.method_8390(class_1588.class, box, class_1588::method_5805);
        if (hostiles.isEmpty()) return;
        class_1588 target = hostiles.get(RANDOM.nextInt(hostiles.size()));
        var bolt = net.minecraft.class_1299.field_6112.method_5883(world);
        if (bolt != null) {
            bolt.method_5814(target.method_23317(), target.method_23318(), target.method_23321());
            bolt.method_29498(false);
            world.method_8649(bolt);
        }
    }

    // ===== Mori — accelerates plant growth, ignores random tick gating =====
    private static void auraMori(class_3218 world, KitsuneEntity fox, class_2338 center) {
        net.minecraft.class_5819 mcRandom = world.method_8409();
        scanRadius(world, center, 6, (p, state) -> {
            class_2248 block = state.method_26204();
            if (block instanceof class_2302 || block instanceof class_2473 || block instanceof class_2523) {
                if (RANDOM.nextInt(3) == 0) {
                    state.method_26199(world, p, mcRandom);
                    world.method_14199(class_2398.field_11211,
                            p.method_10263()+0.5, p.method_10264()+0.7, p.method_10260()+0.5, 1, 0.2, 0.2, 0.2, 0.01);
                }
            } else if (state.method_27852(class_2246.field_16999) && RANDOM.nextInt(5) == 0) {
                state.method_26199(world, p, mcRandom);
            }
        });
    }

    // ===== Kori — freezes water into packed ice =====
    private static void auraKori(class_3218 world, KitsuneEntity fox, class_2338 center) {
        scanRadius(world, center, 6, (p, state) -> {
            if (state.method_27852(class_2246.field_10382) && state.method_26227().method_15771()) {
                if (RANDOM.nextInt(8) == 0) {
                    world.method_8501(p, class_2246.field_10225.method_9564());
                    world.method_14199(class_2398.field_28013,
                            p.method_10263()+0.5, p.method_10264()+0.7, p.method_10260()+0.5, 3, 0.2, 0.1, 0.2, 0.01);
                }
            } else if (state.method_27852(class_2246.field_10036)) {
                world.method_8501(p, class_2246.field_10124.method_9564());
            }
        });
    }

    // ===== Yurei — periodic vex-like teleport through nearby walls =====
    private static void auraYurei(class_3218 world, KitsuneEntity fox, class_2338 center) {
        if (RANDOM.nextInt(15) != 0) return;
        // Random short teleport, ignoring walls — mimics vex/wraith feel.
        double dx = (RANDOM.nextDouble() - 0.5) * 8;
        double dz = (RANDOM.nextDouble() - 0.5) * 8;
        class_2338 target = center.method_10069((int) dx, 0, (int) dz);
        // Find solid ground at that x/z.
        for (int dy = 4; dy >= -4; dy--) {
            class_2338 check = target.method_10069(0, dy, 0);
            if (!world.method_8320(check).method_26215() && world.method_8320(check.method_10084()).method_26215()
                    && world.method_8320(check.method_10086(2)).method_26215()) {
                fox.method_6082(check.method_10263() + 0.5, check.method_10264() + 1, check.method_10260() + 0.5, false);
                world.method_14199(class_2398.field_11214,
                        fox.method_23317(), fox.method_23318() + 0.5, fox.method_23321(),
                        8, 0.3, 0.5, 0.3, 0.1);
                return;
            }
        }
    }

    // ===== Tengoku — drives off phantoms, gives nearby hostiles weakness =====
    private static void auraTengoku(class_3218 world, KitsuneEntity fox, class_2338 center) {
        class_238 box = new class_238(center).method_1014(8);
        // Phantoms flee — give them levitation upward briefly so they can't dive bomb.
        for (class_1593 phantom : world.method_8390(class_1593.class, box, class_1593::method_5805)) {
            phantom.method_6092(new class_1293(
                    class_1294.field_5902, 60, 1, false, false, true));
            class_243 away = phantom.method_19538().method_1020(fox.method_19538()).method_1029().method_1021(0.4);
            phantom.method_5762(away.field_1352, 0.1, away.field_1350);
            phantom.field_6037 = true;
        }
        // Other hostiles get Weakness from being near the heavenly fox.
        for (class_1588 h : world.method_8390(class_1588.class, box, class_1588::method_5805)) {
            h.method_6092(new class_1293(
                    class_1294.field_5911, 60, 0, false, false, true));
        }
    }

    /**
     * Iterate a cube of blocks centered on {@code center} with side
     * {@code radius * 2 + 1}, calling the visitor for each one.
     */
    private static void scanRadius(class_3218 world, class_2338 center, int radius, BlockVisitor visitor) {
        class_2338.class_2339 cursor = new class_2338.class_2339();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz);
                    class_2680 state = world.method_8320(cursor);
                    if (state.method_26215()) continue;
                    visitor.visit(cursor.method_10062(), state);
                }
            }
        }
    }

    @FunctionalInterface
    private interface BlockVisitor {
        void visit(class_2338 pos, class_2680 state);
    }
}