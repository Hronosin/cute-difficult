package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1547;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3218;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Makes skeletons (and strays/wither skeletons) switch to melee combat when
 * the player gets close enough that bow shots become impractical.
 *
 * <p><b>State machine:</b>
 * <ul>
 *   <li>BOW mode (default): vanilla behavior, ranged attacks with bow.</li>
 *   <li>If a player stays within {@link #MELEE_TRIGGER_DIST} for
 *       {@link #COMMIT_TICKS} consecutive ticks, the skeleton swaps to
 *       a sword and enters MELEE mode.</li>
 *   <li>If in MELEE mode and target is beyond {@link #BOW_RESUME_DIST},
 *       the skeleton swaps back to its bow.</li>
 * </ul>
 *
 * <p><b>Hysteresis</b> (different thresholds for switching to vs from
 * melee) prevents oscillation when the player hovers near the threshold.
 * The "commit ticks" delay prevents instant flip-flop when a player
 * sprints past.
 *
 * <p>If the skeleton doesn't have a bow stored (we cache it on first
 * swap), we keep its current bow stack and remember it to restore later.
 * The sword we give it is just an iron sword — vanilla skeletons don't
 * normally hold any, so we generate one.
 *
 * <p>Wither skeletons in vanilla already hold stone swords and do melee;
 * this handler still applies to them (the dist tracking is harmless),
 * but the swap is a no-op since they already have a sword.
 *
 * <p>Active only in CRUEL mode.
 */
public final class SkeletonMeleeHandler {

    /** Inside this distance, skeleton wants to melee. */
    private static final double MELEE_TRIGGER_DIST = 4.0;

    /** Outside this distance, skeleton wants to bow. (Hysteresis gap.) */
    private static final double BOW_RESUME_DIST = 6.0;

    /** Ticks the player must stay close before melee swap fires. */
    private static final int COMMIT_TICKS = 30; // 1.5s

    /** Per-skeleton state: how many ticks player has been in melee range. */
    private static final WeakHashMap<UUID, Integer> PROXIMITY_TICKS = new WeakHashMap<>();

    /** Per-skeleton state: stashed bow, restored when switching back to ranged. */
    private static final WeakHashMap<UUID, class_1799> STASHED_BOW = new WeakHashMap<>();

    /** Per-skeleton state: are we currently in melee mode? */
    private static final WeakHashMap<UUID, Boolean> IN_MELEE = new WeakHashMap<>();

    private SkeletonMeleeHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (var entity : world.method_27909()) {
                    if (entity instanceof class_1547 skeleton && skeleton.method_5805()) {
                        tickSkeleton(skeleton);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] SkeletonMeleeHandler registered.");
    }

    private static void tickSkeleton(class_1547 skeleton) {
        class_1309 target = skeleton.method_5968();
        if (!(target instanceof class_1657 player)) {
            // No target — reset proximity tracking, keep mode as-is.
            PROXIMITY_TICKS.remove(skeleton.method_5667());
            return;
        }

        double distance = skeleton.method_5739(player);
        UUID id = skeleton.method_5667();
        boolean inMelee = IN_MELEE.getOrDefault(id, false);

        if (!inMelee) {
            // Currently ranged. Track how long player has been close.
            if (distance <= MELEE_TRIGGER_DIST) {
                int ticks = PROXIMITY_TICKS.getOrDefault(id, 0) + 1;
                PROXIMITY_TICKS.put(id, ticks);
                if (ticks >= COMMIT_TICKS) {
                    swapToMelee(skeleton);
                    IN_MELEE.put(id, true);
                    PROXIMITY_TICKS.remove(id);
                }
            } else {
                PROXIMITY_TICKS.remove(id);
            }
        } else {
            // Currently melee. Switch back to bow only if player gets far.
            if (distance >= BOW_RESUME_DIST) {
                swapToBow(skeleton);
                IN_MELEE.put(id, false);
            }
        }
    }

    private static void swapToMelee(class_1547 skeleton) {
        class_1799 mainHand = skeleton.method_6118(class_1304.field_6173);
        if (mainHand.method_31574(class_1802.field_8102)) {
            STASHED_BOW.put(skeleton.method_5667(), mainHand.method_7972());
        }
        skeleton.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8371));
    }

    private static void swapToBow(class_1547 skeleton) {
        class_1799 stashed = STASHED_BOW.remove(skeleton.method_5667());
        if (stashed != null) {
            skeleton.method_5673(class_1304.field_6173, stashed);
        } else {
            // Skeleton didn't originally have a bow (maybe wither skeleton).
            // Restore a default bow.
            skeleton.method_5673(class_1304.field_6173, new class_1799(class_1802.field_8102));
        }
    }
}
