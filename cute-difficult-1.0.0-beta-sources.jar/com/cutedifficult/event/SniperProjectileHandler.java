package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1665;
import net.minecraft.class_1686;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.Random;

/**
 * Gives hostile-mob projectiles a small chance to be "sniper shots" — faster,
 * straighter, harder-hitting.
 *
 * <p><b>Mechanic:</b> when any {@link class_1665} (arrow,
 * trident-like) loads into the world and its owner is a hostile mob, roll
 * {@link #SNIPER_CHANCE}. If it lands:
 * <ul>
 *   <li><b>Velocity ×2</b> — the projectile flies much faster, less reaction time.</li>
 *   <li><b>Damage ×1.5</b> — the hit hurts more.</li>
 *   <li><b>Visual + audio cue</b> — a brief glow trail and a high "snipe ping"
 *       sound at the shooter, so the player gets a fair warning that
 *       something dangerous is coming.</li>
 * </ul>
 *
 * <p><b>Why only PersistentProjectileEntity:</b> this is the parent class
 * for arrows, spectral arrows, tipped arrows, and tridents — all of which
 * have the {@code setVelocity} + {@code setDamage} contract we use. Other
 * hostile projectiles (ghast fireballs, blaze fireballs, shulker bullets,
 * potions) have different damage models that aren't cleanly multipliable,
 * so we leave them alone. Practically, the player encounters arrow-spam
 * way more often than any other projectile type, so this hits the
 * most-felt vector.
 *
 * <p>Owner check: we only buff projectiles fired by {@link class_1588}.
 * Snowballs from snow golems, arrows from a pillager that's been pacified,
 * etc. are not boosted.
 *
 * <p>Active only in CRUEL mode.
 */
public final class SniperProjectileHandler {

    private static final double SNIPER_CHANCE = 0.05;
    private static final double VELOCITY_MULT = 2.0;
    private static final float DAMAGE_MULT = 1.5f;

    private static final Random RANDOM = new Random();

    private SniperProjectileHandler() {}

    public static void register() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(entity instanceof class_1665 arrow)) return;

            // Skip splash potions and similar — they extend other branches.
            if (entity instanceof class_1686) return;

            // Need a hostile owner.
            class_1297 owner = arrow.method_24921();
            if (!(owner instanceof class_1588)) return;

            // Roll.
            if (RANDOM.nextDouble() >= SNIPER_CHANCE) return;

            applySniperBuff(world, arrow, (class_1309) owner);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] SniperProjectileHandler registered.");
    }

    private static void applySniperBuff(class_3218 world, class_1665 arrow, class_1309 shooter) {
        // Double the velocity. Keep direction.
        class_243 v = arrow.method_18798();
        arrow.method_18799(v.method_1021(VELOCITY_MULT));
        arrow.field_6037 = true;

        // Bump damage. PersistentProjectileEntity stores damage as a double internally
        // and exposes getDamage()/setDamage(double).
        double currentDamage = arrow.method_7448();
        arrow.method_7438(currentDamage * DAMAGE_MULT);

        // Make it glow so it's visible mid-flight.
        arrow.method_5780("cd_sniper");

        // Warning audio at the shooter — high-pitched ping. Reaches the player
        // a moment before the arrow does, giving a sliver of reaction time.
        world.method_43128(
            null,
            shooter.method_23317(), shooter.method_23318(), shooter.method_23321(),
            class_3417.field_14600,
            class_3419.field_15251,
            1.6f,
            0.4f // very low pitch — distinctive "twang"
        );

        // Telegraph particles at shooter.
        world.method_14199(
            class_2398.field_11207,
            shooter.method_23317(), shooter.method_23318() + shooter.method_5751(), shooter.method_23321(),
            6,
            0.2, 0.2, 0.2,
            0.05
        );
    }
}
