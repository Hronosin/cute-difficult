package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1642;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Zombies grab + (at low HP) summon ONE reinforcement.
 *
 * <p><b>Anti-exponential-spawn safety:</b> reinforcement summoning is
 * gated by two rules to prevent runaway zombie hordes:
 * <ol>
 *   <li>Each zombie can only summon ONCE in its lifetime — tracked via
 *       {@link #HAS_SUMMONED} set.</li>
 *   <li>Summoned zombies are flagged via {@link #IS_SUMMONED_CHILD} and
 *       can NEVER summon themselves — chain depth is hard-capped at 1.</li>
 * </ol>
 * Maximum population growth per encounter: original zombie + 1 child = 2.
 *
 * <p>Grab logic is independent and unaffected.
 */
public final class ZombieGrabHandler {

    private static final double GRAB_RADIUS = 2.5;
    private static final int GRAB_DURATION_TICKS = 40;
    private static final int GRAB_COOLDOWN_TICKS = 200;
    private static final double PULL_STRENGTH = 0.08;

    /** HP fraction below which a zombie may summon reinforcement. */
    private static final float SUMMON_HP_THRESHOLD = 0.3f;

    private static final WeakHashMap<UUID, Long> GRAB_START = new WeakHashMap<>();
    private static final WeakHashMap<UUID, Long> LAST_GRAB_END = new WeakHashMap<>();
    private static final WeakHashMap<UUID, UUID> GRAB_TARGET = new WeakHashMap<>();

    /** Zombies that have already used their one summon — anti-exponential. */
    private static final Set<UUID> HAS_SUMMONED = new HashSet<>();
    /** Zombies that themselves came from a summon — can never summon. */
    private static final Set<UUID> IS_SUMMONED_CHILD = new HashSet<>();

    private ZombieGrabHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_1642 zombie && zombie.method_5805()) {
                        tickZombie(world, zombie);
                    }
                }
            }
        });
        CuteDifficult.LOGGER.info("[CuteDifficult] ZombieGrabHandler registered (grab + capped reinforcement).");
    }

    private static void tickZombie(class_3218 world, class_1642 zombie) {
        UUID id = zombie.method_5667();
        long now = world.method_8510();
        Long grabStart = GRAB_START.get(id);

        // --- Active grab tick ---
        if (grabStart != null && grabStart > 0) {
            UUID targetId = GRAB_TARGET.get(id);
            class_3222 target = findPlayerByUuid(world, targetId);
            long elapsed = now - grabStart;

            if (target == null || !target.method_5805() || elapsed >= GRAB_DURATION_TICKS) {
                GRAB_START.remove(id);
                GRAB_TARGET.remove(id);
                LAST_GRAB_END.put(id, now);
                return;
            }
            class_243 toZombie = zombie.method_19538().method_1020(target.method_19538());
            double dist = toZombie.method_1033();
            if (dist > 0.5 && dist < 10.0) {
                class_243 pull = toZombie.method_1021(PULL_STRENGTH / dist);
                target.method_18799(target.method_18798().method_1031(pull.field_1352, 0, pull.field_1350));
                target.field_6037 = true;
            }
            if (elapsed % 20 == 0) {
                target.method_6092(new class_1293(
                    class_1294.field_5909, 30, 1, false, false, true));
            }
            if (elapsed % 5 == 0) {
                class_243 mid = zombie.method_19538().method_1019(target.method_19538()).method_1021(0.5);
                world.method_14199(class_2398.field_11251, mid.field_1352, mid.field_1351 + 1, mid.field_1350, 2, 0.3, 0.3, 0.3, 0.02);
            }
            return;
        }

        // --- Summon-reinforcement check ---
        tickSummon(world, zombie, id);

        // --- Idle: try to start a grab ---
        Long lastEnd = LAST_GRAB_END.get(id);
        if (lastEnd != null && now - lastEnd < GRAB_COOLDOWN_TICKS) return;

        class_1309 target = zombie.method_5968();
        if (!(target instanceof class_3222 sp)) return;
        if (sp.method_7337() || sp.method_7325()) return;
        if (zombie.method_5739(sp) > GRAB_RADIUS) return;

        GRAB_START.put(id, now);
        GRAB_TARGET.put(id, sp.method_5667());

        world.method_43128(null, zombie.method_23317(), zombie.method_23318(), zombie.method_23321(),
            class_3417.field_14670, class_3419.field_15251, 1.5f, 0.6f);
        world.method_14199(class_2398.field_11231,
            zombie.method_23317(), zombie.method_23318() + 1.5, zombie.method_23321(), 5, 0.3, 0.2, 0.3, 0.05);
    }

    /**
     * Conditions for summon: (1) hasn't summoned yet, (2) isn't itself a
     * summoned child, (3) HP below threshold, (4) has a player target.
     * If all true, spawn one reinforcement zombie and mark this zombie
     * as having spent its summon.
     */
    private static void tickSummon(class_3218 world, class_1642 zombie, UUID id) {
        if (HAS_SUMMONED.contains(id)) return;
        if (IS_SUMMONED_CHILD.contains(id)) return;
        if (zombie.method_6032() / zombie.method_6063() > SUMMON_HP_THRESHOLD) return;
        if (!(zombie.method_5968() instanceof class_3222)) return;

        // Spawn a new zombie next to this one.
        class_1642 child = net.minecraft.class_1299.field_6051.method_5883(world);
        if (child == null) return;
        double dx = (world.field_9229.method_43058() - 0.5) * 2;
        double dz = (world.field_9229.method_43058() - 0.5) * 2;
        child.method_5808(zombie.method_23317() + dx, zombie.method_23318(), zombie.method_23321() + dz,
            zombie.method_36454(), 0);
        world.method_8649(child);

        // Mark the child as un-summonable so it can NEVER spawn another.
        IS_SUMMONED_CHILD.add(child.method_5667());
        HAS_SUMMONED.add(id);

        // FX.
        world.method_14199(class_2398.field_11237,
            zombie.method_23317(), zombie.method_23318() + 1, zombie.method_23321(), 20, 0.5, 0.5, 0.5, 0.05);
        world.method_43128(null, zombie.method_23317(), zombie.method_23318(), zombie.method_23321(),
            class_3417.field_15168, class_3419.field_15251, 1.2f, 0.7f);
    }

    private static class_3222 findPlayerByUuid(class_3218 world, UUID id) {
        if (id == null) return null;
        class_1297 e = world.method_14190(id);
        return e instanceof class_3222 sp ? sp : null;
    }
}
