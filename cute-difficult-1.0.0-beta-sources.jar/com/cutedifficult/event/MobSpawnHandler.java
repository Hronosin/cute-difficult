package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1498;
import net.minecraft.class_1548;
import net.minecraft.class_2487;
import net.minecraft.class_5134;

/**
 * Spawn-time mob modifications. Reacts to {@link ServerEntityEvents#ENTITY_LOAD}
 * which fires both for freshly spawned and chunk-loaded entities, so existing
 * mobs in a world get caught the next time their chunk loads.
 *
 * <p><b>Mechanics:</b>
 * <ul>
 *   <li>Creepers: charged + invisible.</li>
 *   <li>Horses (regular only — donkeys/mules already have fixed stats):
 *       max HP, movement speed, and jump strength forced to the lowest
 *       values that vanilla random would produce. Effectively "the
 *       breeding system never selected for anything good".</li>
 * </ul>
 *
 * <p><b>Why HorseEntity only:</b> only {@link class_1498} has randomized
 * stats in vanilla. DonkeyEntity, MuleEntity, ZombieHorseEntity, and
 * SkeletonHorseEntity have fixed stats and don't need our intervention.
 * Llamas and camels are intentionally left alone — llamas are caravan
 * utility, not racing mounts, and nerfing them breaks gameplay loops
 * the player needs.
 *
 * <p><b>Vanilla horse stat ranges</b> (for reference, source: 1.21.1 vanilla):
 * <ul>
 *   <li>Max HP: 15-30 (we force 15)</li>
 *   <li>Movement speed: 0.1125-0.3375 (we force 0.1125)</li>
 *   <li>Jump strength: 0.4-1.0 (we force 0.4)</li>
 * </ul>
 * At these floors, a horse is slower than a sprinting player, jumps lower
 * than a player without the jump-boost effect, and dies in two hits from
 * a basic mob. Mounted travel becomes a punishment, not a convenience.
 */
public final class MobSpawnHandler {
    private MobSpawnHandler() {}

    public static void register() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            if (entity.method_5864() == class_1299.field_6046 && entity instanceof class_1548 creeper) {
                makeChargedAndInvisible(creeper);
            } else if (entity instanceof class_1498 horse) {
                makePathetic(horse);
            }
        });
    }

    // === Creepers ===

    private static void makeChargedAndInvisible(class_1548 creeper) {
        class_2487 nbt = new class_2487();
        creeper.method_5647(nbt);
        if (!nbt.method_10577("powered")) {
            nbt.method_10556("powered", true);
            creeper.method_5651(nbt);
        }
        applyInvisibility(creeper);
    }

    private static void applyInvisibility(class_1309 entity) {
        entity.method_6092(new class_1293(
                class_1294.field_5905,
                class_1293.field_42106,
                0,
                true,
                false,
                false
        ));
    }

    // === Horses ===

    /**
     * Forces a horse's stats to the worst values that vanilla random would
     * naturally roll. Uses {@code setBaseValue} so the change is permanent
     * and serialized (won't be re-rolled on save/load).
     *
     * <p><b>Attribute names in 1.21.1:</b> {@code GENERIC_MAX_HEALTH} and
     * {@code GENERIC_MOVEMENT_SPEED} are confirmed. For jump strength,
     * Mojang renamed this between 1.20 ({@code HORSE_JUMP_STRENGTH}) and
     * 1.21.2 ({@code JUMP_STRENGTH}, no prefix). 1.21.1 is in between; I'm
     * using {@code GENERIC_JUMP_STRENGTH} as the most likely transitional
     * name. If your IDE flags it red, see the comment in
     * {@link #setHorseJumpFloor} for alternatives.
     */
    private static void makePathetic(class_1498 horse) {
        setBaseValueSafe(horse, class_5134.field_23716, 15.0);
        setBaseValueSafe(horse, class_5134.field_23719, 0.1125);
        setHorseJumpFloor(horse);

        // Heal to the new (lower) max so we don't see a brief overheal.
        horse.method_6033(15.0f);
    }

    /**
     * Sets the jump strength attribute. Isolated in its own method because
     * the attribute name is the most likely thing to differ between
     * yarn builds. If the compiler complains about
     * {@code EntityAttributes.GENERIC_JUMP_STRENGTH}, try:
     * <ul>
     *   <li>{@code EntityAttributes.HORSE_JUMP_STRENGTH} (older yarn)</li>
     *   <li>{@code EntityAttributes.JUMP_STRENGTH} (newer yarn, 1.21.2+)</li>
     * </ul>
     * In IntelliJ: type {@code EntityAttributes.} and Ctrl+Space to see
     * what's actually available.
     */
    private static void setHorseJumpFloor(class_1498 horse) {
        setBaseValueSafe(horse, class_5134.field_23728, 0.4);
    }

    private static void setBaseValueSafe(
            class_1309 entity,
            net.minecraft.class_6880<net.minecraft.class_1320> attr,
            double value
    ) {
        class_1324 instance = entity.method_5996(attr);
        if (instance != null) {
            instance.method_6192(value);
        }
    }
}