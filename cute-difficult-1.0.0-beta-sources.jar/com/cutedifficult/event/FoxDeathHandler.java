package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Random;

/**
 * Punishes the killing of kitsune.
 *
 * <p>v0.4.3 implements two consequences when a fox dies by player hand:
 * <ol>
 *   <li>The killer's element-Spirit drops by {@link #SPIRIT_PENALTY},
 *       and karma rises by {@link #KARMA_PENALTY} per tail (a Kyuubi
 *       kill is dramatically worse than a 1-tail).</li>
 *   <li>Every other fox within {@link #WITNESS_RADIUS} of the death
 *       resets the killer's trust with them to zero AND increments
 *       their {@code witnessedKills} counter. Mature kitsune remember.
 *       Their attack goals respect the witness counter: a witnessing
 *       fox attacks the killer regardless of prior trust.</li>
 * </ol>
 *
 * <p>The witness mechanic creates a chilling consequence chain: kill
 * one fox in a forest, and other foxes around suddenly view you as an
 * enemy even if they previously took offerings. Their flame, water,
 * lightning will be your problem until you find a way to atone
 * (future: Greater Penance ritual). For now, witnessing is permanent.
 */
public final class FoxDeathHandler {

    private static final double WITNESS_RADIUS = 16.0;
    private static final int SPIRIT_PENALTY = 10;
    private static final int KARMA_PENALTY = 5;

    private FoxDeathHandler() {}

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register((victim, source) -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
            if (!(victim instanceof class_4019 fox)) return;
            handleFoxDeath(fox, source);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxDeathHandler registered.");
    }

    private static void handleFoxDeath(class_4019 fox, class_1282 source) {
        if (!(fox.method_37908() instanceof class_3218 world)) return;

        // Identify the player responsible, if any.
        class_3222 killer = null;
        class_1309 attacker = source.method_5529() instanceof class_1309 le ? le : null;
        if (attacker instanceof class_3222 sp) {
            killer = sp;
        } else if (source.method_5526() instanceof class_3222 sp) {
            killer = sp;
        }
        if (killer == null) return;

        Random random = new Random();
        KitsuneData victimData = FoxStorage.getOrCreate(fox, random);

        // 1) Penalize killer.
        MinecraftServer server = killer.method_5682();
        if (server != null) {
            SpiritData.add(server, killer, victimData.element, -SPIRIT_PENALTY);
            SpiritData.addKarma(server, killer, KARMA_PENALTY * victimData.tails);
        }

        killer.method_7353(
            class_2561.method_43470("You have slain a ")
                .method_10852(class_2561.method_43470(victimData.element.kamiName() + " kitsune")
                    .method_27692(victimData.element.color()))
                .method_10852(class_2561.method_43470(" (" + victimData.tails + " tails). The other foxes saw."))
                .method_27695(class_124.field_1079, class_124.field_1056),
            false
        );

        // 2) Propagate to witnesses.
        class_238 witnessBox = new class_238(
            fox.method_23317() - WITNESS_RADIUS, fox.method_23318() - WITNESS_RADIUS, fox.method_23321() - WITNESS_RADIUS,
            fox.method_23317() + WITNESS_RADIUS, fox.method_23318() + WITNESS_RADIUS, fox.method_23321() + WITNESS_RADIUS
        );
        List<class_4019> witnesses = world.method_8390(class_4019.class, witnessBox,
            f -> f != fox && f.method_5805());

        for (class_4019 witness : witnesses) {
            KitsuneData wData = FoxStorage.getOrCreate(witness, random);
            KitsuneData updated = KitsuneData.of6(
                wData.element,
                wData.personality,
                wData.tails,
                0, // trust reset to zero
                wData.lastFedTickStamp,
                wData.witnessedKills + 1
            );
            FoxStorage.store(witness, updated);

            // Visual cue: angry-villager particles burst from each witness.
            world.method_14199(
                class_2398.field_11231,
                witness.method_23317(), witness.method_23318() + 0.7, witness.method_23321(),
                10, 0.3, 0.3, 0.3, 0.1
            );
        }

        if (!witnesses.isEmpty()) {
            world.method_43128(
                null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
                class_3417.field_18265,
                class_3419.field_15251,
                1.5f, 0.6f
            );
            CuteDifficult.LOGGER.debug(
                "[CuteDifficult] {} witness foxes registered the killing.",
                witnesses.size()
            );
        }
    }
}
