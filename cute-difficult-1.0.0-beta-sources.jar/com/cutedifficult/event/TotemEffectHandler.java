package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_124;
import net.minecraft.class_1271;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import java.util.List;
import java.util.Random;

/**
 * v0.5.2: stripped the verbose per-callback debug logs. They served their
 * purpose during the initial wiring debugging — now they just noise.
 *
 * Behavior unchanged: right-clicking a Totem of Undying applies a random
 * positive effect and consumes the totem (in CRUEL mode).
 */
public final class TotemEffectHandler {

    private static final List<class_6880<class_1291>> POSITIVE_EFFECTS = List.of(
        class_1294.field_5924,
        class_1294.field_5907,
        class_1294.field_5910,
        class_1294.field_5904,
        class_1294.field_5898,
        class_1294.field_5918,
        class_1294.field_5917,
        class_1294.field_5913,
        class_1294.field_5925,
        class_1294.field_5923
    );

    private static final int MIN_DURATION_TICKS = 400;
    private static final int MAX_DURATION_TICKS = 6000;
    private static final int MAX_AMPLIFIER = 2;
    private static final Random RANDOM = new Random();

    private TotemEffectHandler() {}

    public static void register() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);

            if (!stack.method_31574(class_1802.field_8288)) {
                return class_1271.method_22430(stack);
            }
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) {
                return class_1271.method_22430(stack);
            }
            if (world.field_9236) {
                return class_1271.method_22427(stack);
            }

            class_6880<class_1291> effect = POSITIVE_EFFECTS.get(
                RANDOM.nextInt(POSITIVE_EFFECTS.size())
            );
            int amplifier = RANDOM.nextInt(MAX_AMPLIFIER + 1);
            int duration = MIN_DURATION_TICKS
                + RANDOM.nextInt(MAX_DURATION_TICKS - MIN_DURATION_TICKS);

            player.method_6092(new class_1293(effect, duration, amplifier));

            if (!player.method_7337()) {
                stack.method_7934(1);
            }

            world.method_43128(
                null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14931,
                class_3419.field_15248,
                1.0f, 1.2f + RANDOM.nextFloat() * 0.2f
            );

            class_2561 effectName = class_2561.method_43471(effect.comp_349().method_5567());
            String tierStr = romanNumeral(amplifier + 1);
            int seconds = duration / 20;

            player.method_7353(
                class_2561.method_43470("The totem grants you ").method_27692(class_124.field_1065)
                    .method_10852(effectName.method_27661().method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" " + tierStr).method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(" for " + seconds + "s.").method_27692(class_124.field_1065)),
                false
            );

            return class_1271.method_22427(stack);
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] TotemEffectHandler registered.");
    }

    private static String romanNumeral(int n) {
        return switch (n) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            default -> String.valueOf(n);
        };
    }
}
