package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_6862;

/**
 * The crafting table is a trickster. When the player closes a crafting
 * interface, there's a chance it sneaks in one extra craft using whatever
 * ingredients the player happens to have. The player gets no say in what
 * gets crafted.
 *
 * <p><b>How:</b> on screen-close, roll {@link #SABOTAGE_CHANCE}. If it
 * triggers, scan the {@link #SABOTAGE_RECIPES} list for entries whose
 * ingredients are all present in the player's inventory. Pick a random
 * matching one. Consume the ingredients, give the output (or drop near
 * player if inventory is full).
 *
 * <p><b>Per-player cooldown:</b> 30 seconds. Prevents the player from
 * being repeatedly punished when actively crafting many things in
 * sequence. Stored in a {@link WeakHashMap} keyed by player UUID — entries
 * are garbage-collected when no longer referenced anywhere, so we don't
 * leak memory across long sessions.
 *
 * <p><b>Recipe design:</b> outputs are chosen to be annoying but not
 * game-breaking. Common patterns:
 * <ul>
 *   <li>Conversions that waste materials (planks → sticks when you
 *       wanted planks; iron → cauldron when you wanted ingots).</li>
 *   <li>Duplicates of things you already have (another crafting table).</li>
 *   <li>Items with niche use (bowls, hay bales).</li>
 *   <li>Things that lock up materials you need for something else
 *       (paper + compass → empty map: wastes your compass).</li>
 * </ul>
 *
 * <p>No "destructive" sabotages (no eating diamonds, no destroying
 * netherite). The mod hurts, but it's not griefing.
 *
 * <p><b>Active only in CRUEL mode.</b>
 */
public final class CraftingSabotageHandler {

    private static final float SABOTAGE_CHANCE = 0.15f;
    private static final long COOLDOWN_MS = 30_000L;
    private static final Random RANDOM = new Random();

    /** Per-player cooldown tracking. WeakHashMap so dead players GC out. */
    private static final Map<UUID, Long> LAST_SABOTAGE = new WeakHashMap<>();

    /** Single requirement: matcher predicate + count. */
    private record Requirement(Predicate<class_1799> matcher, int count) {}

    /** A trolling "recipe" the table can autonomously execute. */
    private record SabotageRecipe(String displayName, List<Requirement> requirements, class_1799 output) {}

    private static Requirement requireItem(class_1792 item, int count) {
        return new Requirement(stack -> stack.method_31574(item), count);
    }

    private static Requirement requireTag(class_6862<class_1792> tag, int count) {
        return new Requirement(stack -> stack.method_31573(tag), count);
    }

    /** Curated list of trolling recipes. Each one is real-ish vanilla output. */
    private static final List<SabotageRecipe> SABOTAGE_RECIPES = List.of(
        new SabotageRecipe(
            "a fresh handful of sticks",
            List.of(requireTag(class_3489.field_15537, 2)),
            new class_1799(class_1802.field_8600, 4)
        ),
        new SabotageRecipe(
            "another crafting table (you can never have too many)",
            List.of(requireTag(class_3489.field_15537, 4)),
            new class_1799(class_1802.field_8465, 1)
        ),
        new SabotageRecipe(
            "a set of fine wooden bowls",
            List.of(requireTag(class_3489.field_15537, 3)),
            new class_1799(class_1802.field_8428, 4)
        ),
        new SabotageRecipe(
            "a book (you needed paper for something else, didn't you?)",
            List.of(requireItem(class_1802.field_8407, 3), requireItem(class_1802.field_8745, 1)),
            new class_1799(class_1802.field_8529, 1)
        ),
        new SabotageRecipe(
            "a single piece of white wool",
            List.of(requireItem(class_1802.field_8276, 4)),
            new class_1799(class_1802.field_19044, 1)
        ),
        new SabotageRecipe(
            "an entirely unwanted furnace",
            List.of(requireItem(class_1802.field_20412, 8)),
            new class_1799(class_1802.field_8732, 1)
        ),
        new SabotageRecipe(
            "a single loaf of bread",
            List.of(requireItem(class_1802.field_8861, 3)),
            new class_1799(class_1802.field_8229, 1)
        ),
        new SabotageRecipe(
            "a hay bale (there go your crops)",
            List.of(requireItem(class_1802.field_8861, 9)),
            new class_1799(class_1802.field_17528, 1)
        ),
        new SabotageRecipe(
            "an iron ingot (compressed from your nuggets)",
            List.of(requireItem(class_1802.field_8675, 9)),
            new class_1799(class_1802.field_8620, 1)
        ),
        new SabotageRecipe(
            "an iron cauldron (a lot of iron for a water bucket alternative)",
            List.of(requireItem(class_1802.field_8620, 7)),
            new class_1799(class_1802.field_8638, 1)
        ),
        new SabotageRecipe(
            "three ladders (going somewhere?)",
            List.of(requireItem(class_1802.field_8600, 7)),
            new class_1799(class_1802.field_8121, 3)
        ),
        new SabotageRecipe(
            "an empty map (your compass is gone, by the way)",
            List.of(requireItem(class_1802.field_8407, 8), requireItem(class_1802.field_8251, 1)),
            new class_1799(class_1802.field_8895, 1)
        ),
        new SabotageRecipe(
            "a torch (just one, alone in the dark)",
            List.of(requireItem(class_1802.field_8600, 1), requireItem(class_1802.field_8713, 1)),
            new class_1799(class_1802.field_8810, 4)
        )
    );

    private CraftingSabotageHandler() {}

    /**
     * Called from the {@code CraftingScreenHandlerMixin} when a crafting
     * UI closes. Rolls the sabotage chance, performs it if it lands.
     */
    public static void trySabotage(class_3222 player) {
        if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;
        if (RANDOM.nextFloat() >= SABOTAGE_CHANCE) return;

        UUID uuid = player.method_5667();
        long now = System.currentTimeMillis();
        Long last = LAST_SABOTAGE.get(uuid);
        if (last != null && now - last < COOLDOWN_MS) return;

        class_1661 inv = player.method_31548();
        List<SabotageRecipe> craftable = new ArrayList<>();
        for (SabotageRecipe recipe : SABOTAGE_RECIPES) {
            if (canCraft(inv, recipe)) {
                craftable.add(recipe);
            }
        }
        if (craftable.isEmpty()) return;

        SabotageRecipe chosen = craftable.get(RANDOM.nextInt(craftable.size()));
        execute(player, chosen);
        LAST_SABOTAGE.put(uuid, now);
    }

    private static boolean canCraft(class_1661 inv, SabotageRecipe recipe) {
        for (Requirement req : recipe.requirements()) {
            if (countMatching(inv, req.matcher()) < req.count()) {
                return false;
            }
        }
        return true;
    }

    private static int countMatching(class_1661 inv, Predicate<class_1799> matcher) {
        int count = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && matcher.test(stack)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static void consume(class_1661 inv, Predicate<class_1799> matcher, int amount) {
        int remaining = amount;
        for (int i = 0; i < inv.method_5439() && remaining > 0; i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && matcher.test(stack)) {
                int take = Math.min(remaining, stack.method_7947());
                stack.method_7934(take);
                remaining -= take;
            }
        }
    }

    private static void execute(class_3222 player, SabotageRecipe recipe) {
        class_1661 inv = player.method_31548();

        for (Requirement req : recipe.requirements()) {
            consume(inv, req.matcher(), req.count());
        }

        class_1799 output = recipe.output().method_7972();
        if (!inv.method_7394(output)) {
            // No room — drop near the player. They'll see what was crafted.
            player.method_7328(output, false);
        }

        player.method_7353(
            class_2561.method_43470("The crafting table giggled and fashioned ").method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(recipe.displayName()).method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43470(".").method_27692(class_124.field_1065)),
            false
        );

        player.method_37908().method_43128(
            null,
            player.method_23317(), player.method_23318(), player.method_23321(),
            class_3417.field_15008,
            class_3419.field_15248,
            0.6f,
            1.6f
        );
    }
}
