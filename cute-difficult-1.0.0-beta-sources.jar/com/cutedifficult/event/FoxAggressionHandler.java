package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxStats;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4019;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Proactive ability casting for high-tail kitsune. The previous design
 * tied ability casts to "took damage this tick", which meant kitsune
 * never used their powers unless the player attacked first. For mature
 * kitsune, this didn't match the lore — they should be assertive,
 * occasionally threatening even peaceful players.
 *
 * <p><b>Rule:</b> if a kitsune has {@link #AGGRESSION_MIN_TAILS} or more
 * tails, AND a player is within {@link #AGGRESSION_RADIUS} blocks, AND
 * the kitsune's own cooldown is up, AND the random roll lands, then the
 * kitsune casts an ability at the player.
 *
 * <p><b>Roll probabilities</b> are very small per tick so that even with
 * a kitsune sitting next to the player, an aggression cast happens
 * maybe once every 5-15 seconds, not every tick. Cooldown then enforces
 * the lower bound.
 *
 * <p>The actual ability code lives in {@link FoxAbilityHandler} —
 * we call into its dispatch by simulating a tiny HP drop (this is gross
 * but avoids duplicating the elemental dispatch). A cleaner refactor
 * would expose a public {@code FoxAbilityHandler.castNow(fox, player)}
 * method; will do that if we add more triggers.
 *
 * <p><b>Tied to FoxAbilityHandler's cooldown</b>: both handlers respect
 * the same {@code FoxStats.abilityCooldownTicks} so we don't double-cast.
 * Different per-fox WeakHashMaps though — we keep our own to avoid
 * stepping on the other handler's state.
 */
public final class FoxAggressionHandler {

    /** Minimum tails to be proactively aggressive. */
    private static final int AGGRESSION_MIN_TAILS = 3;

    /** Radius around fox to look for a player target. */
    private static final double AGGRESSION_RADIUS = 12.0;

    /** Per-tick probability of attempting a cast (gated by cooldown). */
    private static final double CAST_CHANCE_PER_TICK = 0.01;

    private static final WeakHashMap<UUID, Long> LAST_CAST = new WeakHashMap<>();
    private static final Random RANDOM = new Random();

    private FoxAggressionHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_4019 fox && fox.method_5805()) {
                        tickFox(world, fox);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxAggressionHandler registered.");
    }

    private static void tickFox(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        if (data.tails < AGGRESSION_MIN_TAILS) return;

        if (RANDOM.nextDouble() >= CAST_CHANCE_PER_TICK) return;

        class_3222 target = (class_3222) world.method_8604(
            fox.method_23317(), fox.method_23318(), fox.method_23321(),
            AGGRESSION_RADIUS,
            p -> p instanceof class_3222 sp
                && !sp.method_7337() && !sp.method_7325() && sp.method_5805()
        );
        if (target == null) return;

        // Centralized hostility + LOS check.
        if (!com.cutedifficult.spirit.FoxHostility.canAttackWithLineOfSight(fox, target)) return;

        UUID id = fox.method_5667();
        long now = world.method_8510();
        Long lastCast = LAST_CAST.get(id);
        int cooldown = FoxStats.abilityCooldownTicks(data.tails);
        if (lastCast != null && now - lastCast < cooldown) return;

        FoxAbilityHandler.castElementalAbility(world, fox, data, target);
        LAST_CAST.put(id, now);
    }
}
