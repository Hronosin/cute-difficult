package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1628;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Active combat abilities for spiders, replacing the "x-ray vision" idea
 * that ran into mixin descriptor issues.
 *
 * <p><b>Two abilities, both LOS-gated:</b>
 * <ul>
 *   <li><b>Pounce</b> — when a spider has line-of-sight to a player at
 *       4-12 blocks, it can launch itself in a ballistic arc toward the
 *       player. Cooldown 5 seconds.</li>
 *   <li><b>Web shot</b> — at 5-16 blocks with LOS, the spider spits a
 *       "web glob" (particle line + cobweb burst at player). On hit, the
 *       player gets Slowness II for 4 seconds. Cooldown 8 seconds.</li>
 * </ul>
 *
 * <p>Web shot is a hitscan — no flying projectile entity. The particle
 * line shows where the web went, and slowness applies at the moment of
 * fire. Cheaper than a custom projectile and feels responsive.
 *
 * <p>Per-spider cooldowns via {@link WeakHashMap} keyed by entity UUID.
 * Entries naturally die when spiders die.
 *
 * <p>Active only in CRUEL mode.
 */
public final class SpiderAbilitiesHandler {

    private static final double POUNCE_MIN_DIST = 4.0;
    private static final double POUNCE_MAX_DIST = 12.0;
    private static final long POUNCE_COOLDOWN_MS = 5_000L;
    private static final double POUNCE_CHANCE_PER_TICK = 0.04;

    private static final double WEB_MIN_DIST = 5.0;
    private static final double WEB_MAX_DIST = 16.0;
    private static final long WEB_COOLDOWN_MS = 8_000L;
    private static final double WEB_CHANCE_PER_TICK = 0.03;

    private static final int WEB_SLOWNESS_AMPLIFIER = 1;
    private static final int WEB_SLOWNESS_TICKS = 80;

    private static final double POUNCE_SPEED = 1.4;
    private static final double POUNCE_UP = 0.6;

    private static final Random RANDOM = new Random();

    /** Per-spider cooldown tracking. WeakHashMap so dead spiders GC out. */
    private static final WeakHashMap<UUID, Long> LAST_POUNCE = new WeakHashMap<>();
    private static final WeakHashMap<UUID, Long> LAST_WEB = new WeakHashMap<>();

    private SpiderAbilitiesHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity instanceof class_1628 spider && spider.method_5805()) {
                        tickSpider(world, spider);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] SpiderAbilitiesHandler registered.");
    }

    private static void tickSpider(class_3218 world, class_1628 spider) {
        class_1309 target = spider.method_5968();
        if (!(target instanceof class_3222 player)) return;
        if (player.method_7337() || player.method_7325() || !player.method_5805()) return;

        class_243 spiderEyes = spider.method_19538().method_1031(0, spider.method_5751(), 0);
        class_243 playerCenter = player.method_19538().method_1031(0, player.method_17682() * 0.5, 0);
        double distance = spiderEyes.method_1022(playerCenter);

        if (!hasLineOfSight(world, spiderEyes, playerCenter, spider)) return;

        long now = System.currentTimeMillis();

        if (distance >= POUNCE_MIN_DIST && distance <= POUNCE_MAX_DIST
            && RANDOM.nextDouble() < POUNCE_CHANCE_PER_TICK)
        {
            Long lastPounce = LAST_POUNCE.get(spider.method_5667());
            if (lastPounce == null || now - lastPounce >= POUNCE_COOLDOWN_MS) {
                doPounce(world, spider, playerCenter);
                LAST_POUNCE.put(spider.method_5667(), now);
                return;
            }
        }

        if (distance >= WEB_MIN_DIST && distance <= WEB_MAX_DIST
            && RANDOM.nextDouble() < WEB_CHANCE_PER_TICK)
        {
            Long lastWeb = LAST_WEB.get(spider.method_5667());
            if (lastWeb == null || now - lastWeb >= WEB_COOLDOWN_MS) {
                doWebShot(world, spider, spiderEyes, playerCenter, player);
                LAST_WEB.put(spider.method_5667(), now);
            }
        }
    }

    private static void doPounce(class_3218 world, class_1628 spider, class_243 targetPos) {
        class_243 spiderPos = spider.method_19538();
        class_243 toTarget = targetPos.method_1020(spiderPos);
        class_243 horizontal = new class_243(toTarget.field_1352, 0, toTarget.field_1350).method_1029();

        class_243 velocity = new class_243(
            horizontal.field_1352 * POUNCE_SPEED,
            POUNCE_UP,
            horizontal.field_1350 * POUNCE_SPEED
        );
        spider.method_18799(velocity);
        spider.field_6037 = true;

        world.method_14199(
            class_2398.field_11205,
            spiderPos.field_1352, spiderPos.field_1351 + 0.5, spiderPos.field_1350,
            12,
            0.3, 0.2, 0.3,
            0.3
        );
        world.method_43128(
            null,
            spiderPos.field_1352, spiderPos.field_1351, spiderPos.field_1350,
            class_3417.field_15170,
            class_3419.field_15251,
            1.5f,
            0.7f
        );
    }

    private static void doWebShot(
        class_3218 world,
        class_1628 spider,
        class_243 from,
        class_243 to,
        class_3222 player
    ) {
        int segments = 16;
        class_243 step = to.method_1020(from).method_1021(1.0 / segments);
        for (int i = 1; i <= segments; i++) {
            class_243 point = from.method_1019(step.method_1021(i));
            world.method_14199(
                class_2398.field_50246,
                point.field_1352, point.field_1351, point.field_1350,
                2,
                0.1, 0.1, 0.1,
                0.0
            );
        }

        world.method_43128(
            null,
            from.field_1352, from.field_1351, from.field_1350,
            class_3417.field_14657,
            class_3419.field_15251,
            1.0f,
            1.5f
        );

        player.method_6092(new class_1293(
            class_1294.field_5909,
            WEB_SLOWNESS_TICKS,
            WEB_SLOWNESS_AMPLIFIER,
            false,
            true,
            true
        ));

        world.method_14199(
            class_2398.field_50246,
            player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
            20,
            0.4, 0.5, 0.4,
            0.05
        );
    }

    private static boolean hasLineOfSight(class_3218 world, class_243 from, class_243 to, class_1297 ignore) {
        class_3959 ctx = new class_3959(
            from,
            to,
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            ignore
        );
        class_3965 hit = world.method_17742(ctx);
        return hit.method_17783() == class_239.class_240.field_1333;
    }
}
