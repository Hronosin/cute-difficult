package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.util.DifficultyMode;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_4019;
import java.util.Random;

/**
 * Post-mixin fox behavior tweaks.
 *
 * <p>The main flight suppression is now done by {@link com.cutedifficult.mixin.FoxEntityMixin}
 * which removes the avoid-goal from the fox's goal selector. This handler
 * is left with one job: putting the Kyuubi into a sitting pose when a
 * player is near, as a visual telegraph of "this is the one".
 *
 * <p>Tick rate: we check every tick but only act on Kyuubi (9-tail) foxes,
 * which are vanishingly rare. Cheap.
 */
public final class FoxBehaviorHandler {

    private static final double KYUUBI_SIT_RADIUS = 12.0;
    private static final Random RANDOM = new Random();

    private FoxBehaviorHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            for (class_3218 world : server.method_3738()) {
                for (var entity : world.method_27909()) {
                    if (entity instanceof class_4019 fox && fox.method_5805()) {
                        maybeSit(world, fox);
                    }
                }
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] FoxBehaviorHandler registered (Kyuubi pose only).");
    }

    private static void maybeSit(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        if (data.tails < KitsuneData.MAX_TAILS) {
            // Only Kyuubi sits. If a fox just dropped from 9 to <9 (shouldn't
            // happen but defensive), let vanilla handle posture again.
            return;
        }

        class_1657 nearestPlayer = world.method_18460(fox, KYUUBI_SIT_RADIUS);
        if (nearestPlayer != null) {
            fox.method_18294(true);
        }
    }
}
