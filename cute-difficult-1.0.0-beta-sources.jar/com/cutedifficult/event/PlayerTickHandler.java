package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.SpiritData;
import com.cutedifficult.util.DifficultyMode;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_3222;
import net.minecraft.class_8646;
import net.minecraft.server.MinecraftServer;

/**
 * Per-tick maintenance.
 *
 * <p>Three things happen here:
 * <ol>
 *   <li><b>Hunger refresh</b> — re-apply {@link class_1294#field_5903} every
 *       5 seconds so it never drops off.</li>
 *   <li><b>Spirit decay</b> — once per in-game day, every element's Spirit
 *       decays by 1. This makes maintenance an active choice.</li>
 *   <li><b>Sidebar binding</b> — every 5 seconds, find the player's dominant
 *       element and bind ITS objective to the sidebar slot. Sidebar can only
 *       hold one objective; we rotate to the most-relevant.</li>
 * </ol>
 *
 * <p>The sidebar binding is server-global (the scoreboard is shared) which
 * means in multiplayer, all players see the dominant element of whoever
 * was last "ticked into" the sidebar. Single-player and small servers
 * with similar progression: fine. Big multiplayer servers: we'll need
 * per-player sidebars via a custom HUD (out of scope for v0.3.0).
 */
public final class PlayerTickHandler {
    private static final int HUNGER_REFRESH_INTERVAL = 100; // 5s
    private static final int HUNGER_DURATION_TICKS = 1200;
    private static final int HUNGER_AMPLIFIER = 0;

    private static final int SPIRIT_DECAY_INTERVAL = 24000; // 1 in-game day

    /** How often to re-evaluate dominant element. Every 5 seconds. */
    private static final int SIDEBAR_REFRESH_INTERVAL = 100;

    private static long tickCounter = 0;

    private PlayerTickHandler() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;

            boolean refreshHunger = (tickCounter % HUNGER_REFRESH_INTERVAL == 0);
            boolean decaySpirit = (tickCounter % SPIRIT_DECAY_INTERVAL == 0);
            boolean refreshSidebar = (tickCounter % SIDEBAR_REFRESH_INTERVAL == 0);

            if (!refreshHunger && !decaySpirit && !refreshSidebar) return;
            if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

            var playerList = server.method_3760().method_14571();
            if (playerList.isEmpty()) return;

            // Sidebar update — pick whichever player's dominant element to show.
            // In single-player this is trivially correct; in multiplayer we
            // pick the first connected player. Custom per-player HUD is future work.
            if (refreshSidebar) {
                updateSidebar(server, playerList.get(0));
            }

            for (class_3222 player : playerList) {
                if (player.method_7337() || player.method_7325()) continue;

                if (refreshHunger) {
                    applyOrRefreshHunger(player);
                }
                if (decaySpirit) {
                    decayAllElements(server, player);
                }
            }
        });
    }

    private static void applyOrRefreshHunger(class_3222 player) {
        class_1293 existing = player.method_6112(class_1294.field_5903);
        if (existing != null && existing.method_5584() > 40) return;

        player.method_6092(new class_1293(
            class_1294.field_5903,
            HUNGER_DURATION_TICKS,
            HUNGER_AMPLIFIER,
            true,
            false,
            true
        ));
    }

    /**
     * Pick this player's dominant Spirit element and bind its objective to
     * the sidebar slot. The sidebar will then update live as the score
     * changes for that element.
     */
    /**
     * v0.9: sidebar disabled in favor of client-side {@code SpiritOverlayHud}.
     * Each player now sees their own stats via HUD overlay rather than a
     * shared global scoreboard. This method is kept as a no-op so the
     * call site doesn't need to change, and it actively unbinds any sidebar
     * objective leftover from older mod versions or other mods.
     */
    private static void updateSidebar(MinecraftServer server, class_3222 referencePlayer) {
        class_269 scoreboard = server.method_3845();
        class_266 currentlyBound = scoreboard.method_1189(class_8646.field_45157);
        if (currentlyBound != null) {
            // Check if this is one of OUR objectives — if yes, unbind.
            for (Element e : Element.values()) {
                class_266 ours = scoreboard.method_1170(SpiritData.objectiveFor(e));
                if (currentlyBound == ours) {
                    scoreboard.method_1158(class_8646.field_45157, null);
                    break;
                }
            }
        }
    }

    /**
     * Once per in-game day: every element loses 1 Spirit, but never goes
     * below 0 from decay alone (negative values come only from active
     * offenses).
     */
    private static void decayAllElements(MinecraftServer server, class_3222 player) {
        for (Element element : Element.values()) {
            int current = SpiritData.get(server, player, element);
            if (current > 0) {
                SpiritData.set(server, player, element, current - 1);
            }
        }
    }
}
