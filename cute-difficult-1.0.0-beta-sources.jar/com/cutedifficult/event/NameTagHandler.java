package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxPersonality;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;
import java.util.Random;

/**
 * Bind a fox to a name via a vanilla name tag. The chosen name is
 * stored in {@link KitsuneData#customName} and persists in NBT.
 *
 * <p><b>Personality bias by name:</b> hashing the name yields a
 * deterministic shift in the fox's 7 personality traits. Different
 * names tilt the fox toward different archetypes:
 * <ul>
 *   <li>Hash bit 0 → pride bias</li>
 *   <li>Hash bit 1 → trust bias</li>
 *   <li>Hash bit 2 → curiosity bias</li>
 *   <li>Hash bit 3 → memory bias</li>
 *   <li>Hash bit 4 → greed bias</li>
 *   <li>Hash bit 5 → sensitivity bias</li>
 *   <li>Hash bit 6 → trauma bias</li>
 * </ul>
 *
 * <p>The bias is +15 per relevant bit, capped at 100. Same name = same
 * shift, so "Sakura" always nudges the same direction. This makes
 * naming a meaningful choice rather than just labeling.
 */
public final class NameTagHandler {

    private static final Random RANDOM = new Random();
    private static final int BIAS_AMOUNT = 15;

    private NameTagHandler() {}

    public static void register() {
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!(entity instanceof class_4019 fox)) return class_1269.field_5811;
            if (!(player instanceof class_3222 sp)) return class_1269.field_5811;
            if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5811;
            if (hand != class_1268.field_5808) return class_1269.field_5811;

            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31574(class_1802.field_8448)) return class_1269.field_5811;

            // Vanilla requires the name tag to have a custom name set in an anvil.
            var customName = stack.method_57824(net.minecraft.class_9334.field_49631);
            if (customName == null) return class_1269.field_5811;

            String chosenName = customName.getString().trim();
            if (chosenName.isEmpty()) return class_1269.field_5811;

            applyNameToFox(serverWorld, sp, fox, chosenName, stack);
            return class_1269.field_5812;
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] NameTagHandler registered.");
    }

    private static void applyNameToFox(class_3218 world, class_3222 player,
                                        class_4019 fox, String name, class_1799 tag) {
        KitsuneData existing = FoxStorage.getOrCreate(fox, RANDOM);
        if (!existing.customName.isEmpty()) {
            player.method_7353(
                class_2561.method_43470("This kitsune already has a name: " + existing.customName)
                    .method_27695(class_124.field_1080, class_124.field_1056),
                true
            );
            return;
        }

        // Compute hash-based bias.
        FoxPersonality biased = biasPersonality(existing.personality, name);
        KitsuneData updated = existing
            .withCustomName(name)
            .withPersonality(biased);
        FoxStorage.store(fox, updated);

        // Set the entity's custom display name too (so floating-name shows).
        fox.method_5665(class_2561.method_43470(name).method_27695(class_124.field_1065, class_124.field_1056));
        fox.method_5880(true);

        // Consume the tag.
        if (!player.method_7337()) tag.method_7934(1);

        // FX.
        world.method_14199(class_2398.field_11201,
            fox.method_23317(), fox.method_23318() + 0.8, fox.method_23321(),
            6, 0.3, 0.3, 0.3, 0.05);
        world.method_43128(null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_18056, class_3419.field_15254, 1.0f, 1.4f);

        player.method_7353(
            class_2561.method_43470("Named: ")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(name).method_27692(existing.element.color())),
            false
        );
    }

    /**
     * Deterministic bias based on name hash. Each bit of the hash flips
     * one personality trait upward by BIAS_AMOUNT. Same name → same bias,
     * so naming a fox "Sakura" anywhere gives the same character tilt.
     */
    private static FoxPersonality biasPersonality(FoxPersonality base, String name) {
        int hash = name.toLowerCase().hashCode();

        int pride = clamp(base.pride() + (((hash >> 0) & 1) == 1 ? BIAS_AMOUNT : 0));
        int trust = clamp(base.trust() + (((hash >> 1) & 1) == 1 ? BIAS_AMOUNT : 0));
        int curiosity = clamp(base.curiosity() + (((hash >> 2) & 1) == 1 ? BIAS_AMOUNT : 0));
        int memory = clamp(base.memory() + (((hash >> 3) & 1) == 1 ? BIAS_AMOUNT : 0));
        int greed = clamp(base.greed() + (((hash >> 4) & 1) == 1 ? BIAS_AMOUNT : 0));
        int sensitivity = clamp(base.sensitivity() + (((hash >> 5) & 1) == 1 ? BIAS_AMOUNT : 0));
        int trauma = clamp(base.trauma() + (((hash >> 6) & 1) == 1 ? BIAS_AMOUNT : 0));

        return new FoxPersonality(pride, trust, curiosity, memory, greed, sensitivity, trauma);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }
}
