package com.cutedifficult.event;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.util.DifficultyMode;
import java.util.List;
import java.util.Random;
import net.minecraft.class_238;
import net.minecraft.class_3218;
import net.minecraft.class_4019;

/**
 * Social mechanics for kitsune.
 *
 * <p>Currently exposes one static helper used by other handlers
 * ({@code FoxOfferingHandler} can be extended to use it for spirit
 * multipliers when same-element kitsune are nearby).
 *
 * <p>This isn't a tick handler — it's a query interface. We don't run
 * any per-tick logic for social mechanics; instead, when an event
 * happens (offering, death), the relevant handler queries this class
 * to see which other foxes are nearby and modulate behavior.
 *
 * <p>Future expansions can hook here for fox-fox interactions like
 * pack-bonding, mating display particles, or cross-element resonance
 * cascades.
 */
public final class FoxSocialHandler {

    /** Radius for "nearby same-element" social queries. */
    public static final double SOCIAL_RADIUS = 12.0;

    private FoxSocialHandler() {}

    /**
     * Count of other kitsune of the same element within social range of
     * the given fox. Used to scale spirit gain on offerings (multiple
     * same-element witnesses → bigger reward).
     */
    public static int sameElementNearby(class_3218 world, class_4019 fox) {
        KitsuneData data = FoxStorage.getOrCreate(fox, new Random());
        class_238 box = new class_238(
            fox.method_23317() - SOCIAL_RADIUS, fox.method_23318() - SOCIAL_RADIUS, fox.method_23321() - SOCIAL_RADIUS,
            fox.method_23317() + SOCIAL_RADIUS, fox.method_23318() + SOCIAL_RADIUS, fox.method_23321() + SOCIAL_RADIUS
        );
        List<class_4019> nearby = world.method_8390(class_4019.class, box, f -> f != fox && f.method_5805());
        int count = 0;
        for (class_4019 other : nearby) {
            KitsuneData od = FoxStorage.getOrCreate(other, new Random());
            if (od.element == data.element) count++;
        }
        return count;
    }
}
