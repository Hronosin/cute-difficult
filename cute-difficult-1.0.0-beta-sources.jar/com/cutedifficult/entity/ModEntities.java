package com.cutedifficult.entity;

import com.cutedifficult.CuteDifficult;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4019;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

/**
 * Registry for custom entity types.
 *
 * <p>v0.3.5 fix: {@link class_1299.class_1300#method_5905(String)} in 1.21.1 takes
 * a string identifier path, not a {@link class_5321}. We pass the
 * stringified registry name. The Registry.register call still takes the
 * full {@code RegistryKey}, so that part is unchanged.
 */
public final class ModEntities {

    public static final class_5321<class_1299<?>> KITSUNE_KEY =
            class_5321.method_29179(class_7923.field_41177.method_30517(),
                    class_2960.method_60655(CuteDifficult.MOD_ID, "kitsune"));

    public static final class_1299<KitsuneEntity> KITSUNE = class_2378.method_39197(
            class_7923.field_41177,
            KITSUNE_KEY,
            class_1299.class_1300.<KitsuneEntity>method_5903(KitsuneEntity::new, class_1311.field_6294)
                    .method_17687(0.6f, 0.7f)
                    .method_27299(8)
                    .method_5905(CuteDifficult.MOD_ID + ":kitsune")
    );

    private ModEntities() {}

    public static void init() {
        FabricDefaultAttributeRegistry.register(KITSUNE, class_4019.method_26885());
        CuteDifficult.LOGGER.info("[CuteDifficult] Registered entity type: cutedifficult:kitsune");
    }
}