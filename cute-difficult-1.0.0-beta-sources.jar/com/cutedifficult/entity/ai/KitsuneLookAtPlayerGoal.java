package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_1657;

/**
 * Turns the kitsune's head toward the nearest player when one is within
 * {@link #LOOK_RADIUS}.
 *
 * <p>Doesn't move the body — only head/eyes. Compatible with WanderGoal
 * (look-at uses LOOK control; wander uses MOVE).
 */
public class KitsuneLookAtPlayerGoal extends class_1352 {

    private static final double LOOK_RADIUS = 16.0;
    private static final int DURATION = 40; // 2s of staring

    private final KitsuneEntity kitsune;
    private class_1657 target;
    private int ticksLeft;

    public KitsuneLookAtPlayerGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.of(class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (this.kitsune.method_59922().method_43048(8) != 0) return false;
        this.target = this.kitsune.method_37908().method_18460(this.kitsune, LOOK_RADIUS);
        return this.target != null;
    }

    @Override
    public boolean method_6266() {
        return this.target != null && this.target.method_5805()
            && this.kitsune.method_5858(this.target) < LOOK_RADIUS * LOOK_RADIUS
            && this.ticksLeft > 0;
    }

    @Override
    public void method_6269() {
        this.ticksLeft = DURATION;
    }

    @Override
    public void method_6270() {
        this.target = null;
    }

    @Override
    public void method_6268() {
        if (this.target == null) return;
        this.ticksLeft--;
        this.kitsune.method_5988().method_20248(
            this.target.method_23317(),
            this.target.method_23320(),
            this.target.method_23321()
        );
    }
}
