package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.class_1352;
import net.minecraft.class_1657;

/**
 * For 9-tail Kyuubi: when a player approaches, sit in regal pose.
 *
 * <p>Implementation: the goal takes MOVE control to prevent wander/attack
 * goals from making the kitsune walk while sitting. The sit flag is set
 * each tick the player is nearby; cleared when they leave.
 */
public class KitsuneSitGoal extends class_1352 {

    private static final double SIT_RADIUS = 8.0;

    private final KitsuneEntity kitsune;
    private final Random random = new Random();

    public KitsuneSitGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        KitsuneData data = FoxStorage.getOrCreate(this.kitsune, this.random);
        if (data.tails < KitsuneData.MAX_TAILS) return false;
        class_1657 player = this.kitsune.method_37908().method_18460(this.kitsune, SIT_RADIUS);
        return player != null && !player.method_7325();
    }

    @Override
    public boolean method_6266() {
        return method_6264();
    }

    @Override
    public void method_6269() {
        this.kitsune.method_18294(true);
        this.kitsune.method_5942().method_6340();
    }

    @Override
    public void method_6270() {
        this.kitsune.method_18294(false);
    }
}
