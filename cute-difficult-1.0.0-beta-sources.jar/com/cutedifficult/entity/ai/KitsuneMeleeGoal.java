package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxStats;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Close-range dash attack for kitsune. When a player is within
 * {@link #DASH_TRIGGER_RADIUS} (and outside the very-close
 * {@link #DASH_MIN_RADIUS} so we don't dash into them when stuck),
 * the kitsune launches itself in a small ballistic arc at the player
 * and deals impact damage on landing.
 *
 * <p><b>State machine:</b>
 * <ol>
 *   <li>Idle — waiting for player to be in dash range.</li>
 *   <li>Wind-up — looking at target, small particle telegraph for
 *       {@link #WINDUP_TICKS} ticks. Gives the player a chance to react.</li>
 *   <li>Airborne — velocity assigned, kitsune flies at target. We track
 *       this state for {@link #AIRBORNE_TIMEOUT} ticks max.</li>
 *   <li>Impact — when close enough during airborne, deal damage and apply
 *       a brief slowness to the target. Reset.</li>
 *   <li>Cooldown — block dashes for {@link #DASH_COOLDOWN_TICKS}.</li>
 * </ol>
 *
 * <p><b>Damage scaling:</b> base 4 damage × (tails / 9). 9-tail dashes
 * for 4 damage; 3-tail (the minimum for melee) for ~1.3.
 *
 * <p>Higher goal priority than {@link KitsuneAttackGoal} so close-range
 * is preferred over ranged. Takes MOVE + LOOK controls during wind-up
 * and dash to ensure other goals don't interrupt mid-pounce.
 */
public class KitsuneMeleeGoal extends class_1352 {

    private static final int MIN_TAILS = 3;
    private static final int FRIENDLY_TRUST_THRESHOLD = 30;
    /** Outer radius — player must be within this for dash to consider. */
    private static final double DASH_TRIGGER_RADIUS = 4.0;
    /** Inner buffer — don't dash if player is literally inside the kitsune. */
    private static final double DASH_MIN_RADIUS = 0.6;
    /** Wind-up duration before launching. Telegraphs the attack. */
    private static final int WINDUP_TICKS = 10; // 0.5s
    /** Max airborne duration before resetting if no impact (safety net). */
    private static final int AIRBORNE_TIMEOUT = 30; // 1.5s
    /** Distance at which airborne kitsune deals impact damage. */
    private static final double IMPACT_DISTANCE = 1.5;
    /** Cooldown between dashes. */
    private static final int DASH_COOLDOWN_TICKS = 100; // 5s

    /** Horizontal speed of the dash. */
    private static final double DASH_HORIZONTAL = 1.2;
    /** Upward velocity component — small arc, not big leap. */
    private static final double DASH_UPWARD = 0.4;

    private final KitsuneEntity kitsune;
    private final Random random = new Random();

    private class_3222 target;
    private Phase phase = Phase.IDLE;
    private int phaseTicks;
    private long lastDashEndedAt;

    private enum Phase { IDLE, WINDUP, AIRBORNE }

    public KitsuneMeleeGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        KitsuneData data = FoxStorage.getOrCreate(this.kitsune, this.random);
        if (data.tails < MIN_TAILS) return false;

        long now = this.kitsune.method_37908().method_8510();
        if (now - this.lastDashEndedAt < DASH_COOLDOWN_TICKS) return false;

        var nearest = this.kitsune.method_37908().method_8604(
            this.kitsune.method_23317(), this.kitsune.method_23318(), this.kitsune.method_23321(),
            DASH_TRIGGER_RADIUS,
            p -> p instanceof class_3222 sp
                && !sp.method_7337() && !sp.method_7325() && sp.method_5805()
        );
        if (!(nearest instanceof class_3222 sp)) return false;

        // Great Blessing peace — never dash a blessed player.
        if (com.cutedifficult.event.ResonanceBlessingHandler.hasGreatBlessing(sp)) return false;

        // Witnessed killings override trust. Otherwise trust gates attack.
        if (data.witnessedKills == 0 && data.trustLevel >= FRIENDLY_TRUST_THRESHOLD) return false;

        double distance = this.kitsune.method_5739(sp);
        if (distance < DASH_MIN_RADIUS) return false;

        this.target = sp;
        return true;
    }

    @Override
    public boolean method_6266() {
        if (this.target == null) return false;
        if (!this.target.method_5805()) return false;
        // Great Blessing peace.
        if (com.cutedifficult.event.ResonanceBlessingHandler.hasGreatBlessing(this.target)) return false;
        // Trust gate with witness override.
        KitsuneData data = FoxStorage.getOrCreate(this.kitsune, this.random);
        if (data.witnessedKills == 0 && data.trustLevel >= FRIENDLY_TRUST_THRESHOLD) return false;
        return this.phase != Phase.IDLE;
    }

    @Override
    public void method_6269() {
        this.phase = Phase.WINDUP;
        this.phaseTicks = 0;
        // Stop any current navigation — we'll take over.
        this.kitsune.method_5942().method_6340();
    }

    @Override
    public void method_6270() {
        this.target = null;
        this.phase = Phase.IDLE;
        this.lastDashEndedAt = this.kitsune.method_37908().method_8510();
    }

    @Override
    public void method_6268() {
        if (this.target == null) {
            this.phase = Phase.IDLE;
            return;
        }
        this.phaseTicks++;

        switch (this.phase) {
            case WINDUP -> tickWindup();
            case AIRBORNE -> tickAirborne();
            default -> {}
        }
    }

    private void tickWindup() {
        // Lock look on target.
        this.kitsune.method_5988().method_6226(this.target, 60f, 60f);

        // Telegraph particles at the kitsune's feet — preparing to pounce.
        if (this.kitsune.method_37908() instanceof class_3218 serverWorld) {
            serverWorld.method_14199(
                class_2398.field_11205,
                this.kitsune.method_23317(), this.kitsune.method_23318() + 0.2, this.kitsune.method_23321(),
                3, 0.2, 0.1, 0.2, 0.05
            );
        }

        if (this.phaseTicks >= WINDUP_TICKS) {
            launchDash();
            this.phase = Phase.AIRBORNE;
            this.phaseTicks = 0;
        }
    }

    private void launchDash() {
        class_243 toTarget = this.target.method_19538().method_1020(this.kitsune.method_19538());
        class_243 horizontal = new class_243(toTarget.field_1352, 0, toTarget.field_1350);
        double horizontalLen = horizontal.method_1033();
        if (horizontalLen < 0.01) {
            // Player directly above/below — small upward push.
            horizontal = new class_243(0.1, 0, 0);
            horizontalLen = horizontal.method_1033();
        }
        class_243 direction = horizontal.method_1021(1.0 / horizontalLen);

        class_243 velocity = new class_243(
            direction.field_1352 * DASH_HORIZONTAL,
            DASH_UPWARD,
            direction.field_1350 * DASH_HORIZONTAL
        );
        this.kitsune.method_18799(velocity);
        this.kitsune.field_6037 = true;

        // Audio — pounce sound.
        this.kitsune.method_37908().method_43128(
            null,
            this.kitsune.method_23317(), this.kitsune.method_23318(), this.kitsune.method_23321(),
            class_3417.field_18058,
            class_3419.field_15251,
            1.3f, 1.1f
        );
    }

    private void tickAirborne() {
        // Check for impact every airborne tick.
        double distance = this.kitsune.method_5739(this.target);
        if (distance < IMPACT_DISTANCE) {
            doImpact();
            this.phase = Phase.IDLE; // canStart will block via cooldown after stop()
            return;
        }
        if (this.phaseTicks >= AIRBORNE_TIMEOUT) {
            // Missed — just end the dash.
            this.phase = Phase.IDLE;
        }
    }

    private void doImpact() {
        KitsuneData data = FoxStorage.getOrCreate(this.kitsune, this.random);
        double power = data.tails / 9.0;

        // Damage — generic, scaled by tails.
        this.target.method_5643(
            this.kitsune.method_37908().method_48963().method_48812(this.kitsune),
            (float) (4.0 * power)
        );

        // Brief slowness on impact — represents the player being knocked off-balance.
        this.target.method_6092(new class_1293(class_1294.field_5909, 20, 1));

        // Impact particles + sound.
        if (this.kitsune.method_37908() instanceof class_3218 serverWorld) {
            serverWorld.method_14199(
                class_2398.field_11227,
                this.target.method_23317(), this.target.method_23318() + 1.0, this.target.method_23321(),
                1, 0.1, 0.1, 0.1, 0.0
            );
        }
        this.kitsune.method_37908().method_43128(
            null,
            this.target.method_23317(), this.target.method_23318(), this.target.method_23321(),
            class_3417.field_18058,
            class_3419.field_15251,
            1.5f, 0.8f
        );
    }
}
