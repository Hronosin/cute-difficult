package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.event.FoxAbilityHandler;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import com.cutedifficult.spirit.FoxStats;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Proactive ranged ability casting.
 *
 * <p><b>v0.4.2 fix:</b> trust gate was only in {@code canStart()}.
 * When a player feeds a fox WHILE the goal is running, {@code shouldContinue()}
 * had no trust check — the goal kept casting through the friendship
 * threshold being crossed. Now {@code shouldContinue()} also gates on
 * trust, so a running attack goal is immediately terminated by a
 * successful offering.
 */
public class KitsuneAttackGoal extends class_1352 {

    private static final int MIN_TAILS = 3;
    private static final int FRIENDLY_TRUST_THRESHOLD = 30;
    private static final double ATTACK_RADIUS = 12.0;
    private static final int INITIAL_DELAY = 40;

    private final KitsuneEntity kitsune;
    private final Random random = new Random();

    private class_3222 target;
    private int ticksUntilCast;
    private int castCooldown;

    public KitsuneAttackGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.noneOf(class_4134.class));
    }

    /** Combined eligibility check used by both canStart and shouldContinue. */
    private boolean isEligible() {
        KitsuneData data = readData();
        if (data == null || data.tails < MIN_TAILS) return false;
        if (this.target == null) return false;
        return com.cutedifficult.spirit.FoxHostility.canAttackWithLineOfSight(this.kitsune, this.target);
    }

    @Override
    public boolean method_6264() {
        KitsuneData data = readData();
        if (data == null || data.tails < MIN_TAILS) return false;
        class_3222 nearest = findTarget();
        if (nearest == null) return false;
        // Apply hostility check using found target.
        if (!com.cutedifficult.spirit.FoxHostility.canAttackWithLineOfSight(this.kitsune, nearest)) return false;
        this.target = nearest;
        return true;
    }

    @Override
    public boolean method_6266() {
        if (!isEligible()) return false; // <-- KEY: trust check on every tick too
        if (this.target == null) return false;
        if (!this.target.method_5805() || this.target.method_7337() || this.target.method_7325()) return false;
        return this.kitsune.method_5858(this.target) <= ATTACK_RADIUS * ATTACK_RADIUS;
    }

    @Override
    public void method_6269() {
        this.ticksUntilCast = INITIAL_DELAY;
        KitsuneData data = readData();
        this.castCooldown = data == null ? 200 : FoxStats.abilityCooldownTicks(data.tails);
    }

    @Override
    public void method_6270() {
        this.target = null;
    }

    @Override
    public void method_6268() {
        if (this.target == null) return;
        if (--this.ticksUntilCast > 0) return;

        this.kitsune.method_5988().method_6226(this.target, 30f, 30f);

        KitsuneData data = readData();
        if (data == null) return;
        if (!(this.kitsune.method_37908() instanceof class_3218 serverWorld)) return;

        FoxAbilityHandler.castElementalAbility(serverWorld, this.kitsune, data, this.target);

        this.ticksUntilCast = this.castCooldown + this.random.nextInt(20);
    }

    private KitsuneData readData() {
        return FoxStorage.getOrCreate(this.kitsune, this.random);
    }

    private class_3222 findTarget() {
        var nearest = this.kitsune.method_37908().method_8604(
            this.kitsune.method_23317(), this.kitsune.method_23318(), this.kitsune.method_23321(),
            ATTACK_RADIUS,
            p -> p instanceof class_3222 sp
                && !sp.method_7337() && !sp.method_7325() && sp.method_5805()
        );
        return nearest instanceof class_3222 sp ? sp : null;
    }
}
