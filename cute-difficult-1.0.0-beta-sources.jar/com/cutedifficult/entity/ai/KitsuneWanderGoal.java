package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_243;
import net.minecraft.class_5532;

/**
 * Calm wandering — the kitsune picks a random spot within {@link #RANGE}
 * blocks and walks there at {@link #SPEED}. Repeats with {@link #CHANCE_DENOMINATOR}-th
 * probability per tick when idle.
 *
 * <p>This replaces vanilla's {@code WanderAroundFarGoal} which had
 * fox-specific quirks (avoiding the player's bed area, escaping when
 * "lifted by jumping into water") that we don't want for kitsune.
 *
 * <p>The goal yields when the navigation reports idle so other goals
 * (look-at-player, attack, sit) can take over without contest.
 */
public class KitsuneWanderGoal extends class_1352 {

    private static final double RANGE = 10.0;
    private static final double SPEED = 0.6;
    private static final int CHANCE_DENOMINATOR = 120; // ~1 attempt per 6s

    private final KitsuneEntity kitsune;
    private double targetX, targetY, targetZ;

    public KitsuneWanderGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        if (this.kitsune.method_18272()) return false;
        if (this.kitsune.method_5740()) return false; // flying handled elsewhere
        if (this.kitsune.method_59922().method_43048(CHANCE_DENOMINATOR) != 0) return false;

        class_243 target = class_5532.method_31510(this.kitsune, (int) RANGE, 4);
        if (target == null) return false;
        this.targetX = target.field_1352;
        this.targetY = target.field_1351;
        this.targetZ = target.field_1350;
        return true;
    }

    @Override
    public boolean method_6266() {
        return !this.kitsune.method_5942().method_6357();
    }

    @Override
    public void method_6269() {
        this.kitsune.method_5942().method_6337(this.targetX, this.targetY, this.targetZ, SPEED);
    }
}
