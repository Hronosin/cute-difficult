package com.cutedifficult.entity.ai;

import com.cutedifficult.entity.KitsuneEntity;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import java.util.EnumSet;
import java.util.Random;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_5532;

/**
 * Flee from player — used only by 1-2 tail kitsune (young, fearful).
 *
 * <p>Activates when a player is within {@link #FLEE_TRIGGER_RADIUS}.
 * Picks a wander point AWAY from the player and runs there at {@link #FLEE_SPEED}.
 *
 * <p>Higher tail kitsune don't get this goal at all (they don't fear
 * mortals), so the behavior matrix is:
 * <ul>
 *   <li>1-2 tails: this goal active → flees</li>
 *   <li>3+ tails: this goal not added → stands, attacks</li>
 * </ul>
 */
public class KitsuneFleeGoal extends class_1352 {

    private static final int MAX_TAILS_THAT_FLEE = 2;
    private static final double FLEE_TRIGGER_RADIUS = 6.0;
    private static final double FLEE_SPEED = 1.2;
    private static final int FLEE_DISTANCE = 10;

    private final KitsuneEntity kitsune;
    private final Random random = new Random();

    private class_1657 threat;
    private double targetX, targetY, targetZ;

    public KitsuneFleeGoal(KitsuneEntity kitsune) {
        this.kitsune = kitsune;
        this.method_6265(EnumSet.of(class_4134.field_18405));
    }

    @Override
    public boolean method_6264() {
        KitsuneData data = FoxStorage.getOrCreate(this.kitsune, this.random);
        if (data.tails > MAX_TAILS_THAT_FLEE) return false;

        class_1657 nearestPlayer = this.kitsune.method_37908().method_18460(
            this.kitsune, FLEE_TRIGGER_RADIUS
        );
        if (nearestPlayer == null) return false;
        if (nearestPlayer.method_7337() || nearestPlayer.method_7325()) return false;

        // Pick a fleeing target — a point in the opposite direction.
        class_243 awayFromPlayer = this.kitsune.method_19538().method_1020(nearestPlayer.method_19538()).method_1029();
        class_243 candidate = class_5532.method_31511(
            this.kitsune, FLEE_DISTANCE, 7, awayFromPlayer
        );
        if (candidate == null) return false;

        this.threat = nearestPlayer;
        this.targetX = candidate.field_1352;
        this.targetY = candidate.field_1351;
        this.targetZ = candidate.field_1350;
        return true;
    }

    @Override
    public boolean method_6266() {
        return !this.kitsune.method_5942().method_6357();
    }

    @Override
    public void method_6269() {
        this.kitsune.method_5942().method_6337(
            this.targetX, this.targetY, this.targetZ, FLEE_SPEED
        );
    }

    @Override
    public void method_6270() {
        this.threat = null;
    }
}
