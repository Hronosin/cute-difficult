package com.cutedifficult.client.hud;

import com.cutedifficult.network.SpiritOverlayPayload;
import com.cutedifficult.spirit.Element;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * v0.9.7: replaced the verbose "✦ Great Blessing of Inari ✦" text badge
 * with a compact icon strip. Each element now has a small star icon in
 * its kami color shown next to its row when its blessing is active. A
 * golden ★ above the panel indicates the Great Blessing (all 9 active).
 *
 * <p>Threshold for "blessing active" mirrors {@code ResonanceBlessingHandler.BLESSING_THRESHOLD}
 * — when spirit ≥ 10 the icon turns on. We hardcode 10 here to avoid a
 * server-class dependency on the client side.
 */
public final class SpiritOverlayHud {

    private static final Map<Element, Integer> CURRENT_SPIRITS = new EnumMap<>(Element.class);
    private static int currentKarma = 0;
    private static boolean greatBlessing = false;
    private static boolean visible = true;
    private static boolean hasReceivedData = false;

    /** Same threshold as ResonanceBlessingHandler. Hardcoded here for client-side use. */
    private static final int BLESSING_THRESHOLD = 10;

    private static final int BG_COLOR = 0x99000000;
    private static final int BG_PADDING = 5;

    /** Icon character for an active blessing — a small star/sparkle. */
    private static final String ACTIVE_ICON = "✦";

    static {
        for (Element e : Element.values()) CURRENT_SPIRITS.put(e, 0);
    }

    private SpiritOverlayHud() {}

    public static void updateFromPayload(SpiritOverlayPayload payload) {
        for (Element e : Element.values()) {
            CURRENT_SPIRITS.put(e, payload.spirits().getOrDefault(e, 0));
        }
        currentKarma = payload.karma();
        greatBlessing = payload.greatBlessing();
        hasReceivedData = true;
    }

    public static boolean hasReceivedData() {
        return hasReceivedData;
    }

    public static void toggleVisibility() {
        visible = !visible;
    }

    public static boolean isVisible() {
        return visible;
    }

    public static void render(class_332 ctx, class_9779 tickCounter) {
        if (!visible) return;

        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842) return;
        if (client.field_1724 == null) return;

        int screenWidth = ctx.method_51421();
        int screenHeight = ctx.method_51443();
        var textRenderer = client.field_1772;

        final int panelInnerWidth = 110;
        final int rightMargin = 4;
        final int lineHeight = 10;

        // Content height: optional Great star line, 9 element rows, spacer, karma.
        int rows = Element.values().length + 1;
        int extraTop = greatBlessing ? lineHeight + 2 : 0;
        int contentHeight = extraTop + rows * lineHeight + 2;

        int contentX = screenWidth - panelInnerWidth - rightMargin;
        int contentY = (screenHeight - contentHeight) / 2;

        int bgX = contentX - BG_PADDING;
        int bgY = contentY - BG_PADDING;
        int bgW = panelInnerWidth + BG_PADDING * 2;
        int bgH = contentHeight + BG_PADDING * 2;
        ctx.method_25294(bgX, bgY, bgX + bgW, bgY + bgH, BG_COLOR);

        int x = contentX;
        int y = contentY;

        // Great Blessing — single bold gold star, right-aligned. Way more
        // compact than the old text badge that overflowed the panel.
        if (greatBlessing) {
            class_2561 greatIcon = class_2561.method_43470("★ ★ ★")
                .method_27695(class_124.field_1065, class_124.field_1067);
            int iconWidth = textRenderer.method_27525(greatIcon);
            ctx.method_27535(textRenderer, greatIcon,
                contentX + (panelInnerWidth - iconWidth) / 2, y, 0xFFFFFF);
            y += lineHeight + 2;
        }

        // Per-element rows: [icon] [kami name] [: value]
        // The icon is colored in the kami color when blessing is active,
        // dark gray dot when not. This gives an at-a-glance overview of
        // which blessings are currently in effect.
        for (Element element : Element.values()) {
            int value = CURRENT_SPIRITS.getOrDefault(element, 0);
            boolean active = value >= BLESSING_THRESHOLD;

            class_2561 icon;
            if (active) {
                icon = class_2561.method_43470(ACTIVE_ICON + " ").method_27692(element.color());
            } else {
                icon = class_2561.method_43470("· ").method_27692(class_124.field_1063);
            }
            class_2561 label = class_2561.method_43470(element.kamiName()).method_27692(element.color());
            class_2561 valueText = class_2561.method_43470(": " + value).method_27692(class_124.field_1068);

            int drawX = x;
            ctx.method_27535(textRenderer, icon, drawX, y, 0xFFFFFF);
            drawX += textRenderer.method_27525(icon);
            ctx.method_27535(textRenderer, label, drawX, y, 0xFFFFFF);
            drawX += textRenderer.method_27525(label);
            ctx.method_27535(textRenderer, valueText, drawX, y, 0xFFFFFF);
            y += lineHeight;
        }

        y += 2;
        class_124 karmaColor = currentKarma > 0
            ? class_124.field_1079
            : (currentKarma < 0 ? class_124.field_1075 : class_124.field_1080);
        class_2561 karmaLabel = class_2561.method_43470("  Karma").method_27692(karmaColor);
        class_2561 karmaValue = class_2561.method_43470(": " + currentKarma).method_27692(class_124.field_1068);
        ctx.method_27535(textRenderer, karmaLabel, x, y, 0xFFFFFF);
        int karmaLabelWidth = textRenderer.method_27525(karmaLabel);
        ctx.method_27535(textRenderer, karmaValue,
            x + karmaLabelWidth, y, 0xFFFFFF);
    }
}
