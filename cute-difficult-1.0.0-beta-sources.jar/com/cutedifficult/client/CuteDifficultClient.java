package com.cutedifficult.client;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.client.gui.BestiaryScreen;
import com.cutedifficult.client.hud.SpiritOverlayHud;
import com.cutedifficult.entity.ModEntities;
import com.cutedifficult.network.BestiaryOpenPayload;
import com.cutedifficult.network.SpiritOverlayPayload;
import com.cutedifficult.spirit.BestiaryData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4042;
import org.lwjgl.glfw.GLFW;

/**
 * Client-side initializer.
 *
 * <p>v0.9.1: added the Spirit HUD toggle keybind (default: H) and the
 * background-fade behind the HUD content. Keybind is registered through
 * vanilla's KeyBinding system, so it appears in the Controls menu under
 * a "Cute Difficult" category and respects player rebinds.
 */
public class CuteDifficultClient implements ClientModInitializer {

    /** Keybind for toggling the Spirit overlay. Default: H. */
    private static class_304 toggleHudKey;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.KITSUNE, class_4042::new);

        // Bestiary GUI receiver.
        ClientPlayNetworking.registerGlobalReceiver(BestiaryOpenPayload.PAYLOAD_ID, (payload, context) -> {
            class_310 client = context.client();
            client.execute(() -> BestiaryScreen.open(payload.entries(), BestiaryData.MAX_ENTRIES));
        });

        // Spirit overlay receiver.
        ClientPlayNetworking.registerGlobalReceiver(SpiritOverlayPayload.PAYLOAD_ID, (payload, context) -> {
            SpiritOverlayHud.updateFromPayload(payload);
            // Debug: log first received packet to confirm path works.
            if (!SpiritOverlayHud.hasReceivedData()) {
                CuteDifficult.LOGGER.info(
                    "[CuteDifficult] Client received first spirit overlay packet.");
            }
        });

        // HUD render hook.
        HudRenderCallback.EVENT.register(SpiritOverlayHud::render);

        // Toggle keybind. Default: H. Translation key is mapped in lang/en_us.json
        // (or left as the raw key string if no lang entry — fine for testing).
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.cutedifficult.toggle_spirit_hud",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_H,
            "category.cutedifficult.main"
        ));

        // Tick handler to detect press events. We use wasPressed() which
        // consumes one press per call — that's exactly the toggle pattern
        // we want.
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHudKey.method_1436()) {
                SpiritOverlayHud.toggleVisibility();
            }
        });

        CuteDifficult.LOGGER.info("[CuteDifficult] Client init complete (renderer + bestiary + spirit HUD + keybinds).");
    }
}
