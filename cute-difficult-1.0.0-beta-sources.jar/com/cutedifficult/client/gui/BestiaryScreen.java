package com.cutedifficult.client.gui;

import com.cutedifficult.spirit.Element;
import java.util.List;
import java.util.Set;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/**
 * The Bestiary of Inari custom GUI.
 *
 * <p><b>v0.6.1 fix:</b> the previous render() called {@code super.render()}
 * AT THE END, which re-applied the screen background blur on top of our
 * drawn content — making everything look smeared. Fix: call
 * {@link #method_25420} at the very top, then draw book + text, then
 * delegate to super to draw widgets (buttons). The super call still
 * triggers a background render internally but at that point the book
 * texture acts as a foreground layer that's preserved.
 *
 * <p>Actually, simpler approach: override {@link #method_25420} to
 * be a no-op (or to just draw the blur once at the start), and call
 * background + book + text + super.render in the correct order.
 *
 * <p>Final structure of render():
 * <ol>
 *   <li>{@code renderBackground} — vanilla translucent darkening.</li>
 *   <li>Draw book.png texture.</li>
 *   <li>Draw page-specific text content.</li>
 *   <li>{@code super.render} for buttons — but it'll re-render the
 *       background. To prevent that we override renderBackground to be
 *       a no-op after the first call, OR we just live with the buttons
 *       being drawn directly.</li>
 * </ol>
 *
 * <p>Cleanest fix: don't call super.render at all; manually draw the
 * drawables. We iterate this.children() for the visual rendering.
 */
public class BestiaryScreen extends class_437 {

    private static final class_2960 BOOK_TEXTURE = class_2960.method_60656("textures/gui/book.png");
    private static final int BOOK_WIDTH = 192;
    private static final int BOOK_HEIGHT = 192;
    private static final int TOTAL_PAGES = 10;

    private final Set<String> entries;
    private final int totalDiscovered;
    private final int maxEntries;
    private int pageIndex = 0;

    private class_4185 nextButton;
    private class_4185 prevButton;

    public BestiaryScreen(Set<String> entries, int maxEntries) {
        super(class_2561.method_43470("Bestiary of Inari"));
        this.entries = entries;
        this.totalDiscovered = entries.size();
        this.maxEntries = maxEntries;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int bookLeft = (this.field_22789 - BOOK_WIDTH) / 2;
        int bookTop = (this.field_22790 - BOOK_HEIGHT) / 2;

        this.prevButton = class_4185.method_46430(
                class_2561.method_43470("◀ Prev"),
                btn -> changePage(-1)
        ).method_46434(bookLeft + 20, bookTop + BOOK_HEIGHT - 24, 50, 18).method_46431();

        this.nextButton = class_4185.method_46430(
                class_2561.method_43470("Next ▶"),
                btn -> changePage(1)
        ).method_46434(bookLeft + BOOK_WIDTH - 70, bookTop + BOOK_HEIGHT - 24, 50, 18).method_46431();

        class_4185 doneButton = class_4185.method_46430(
                class_2561.method_43470("Done"),
                btn -> this.method_25419()
        ).method_46434(bookLeft + (BOOK_WIDTH - 50) / 2, bookTop + BOOK_HEIGHT + 4, 50, 18).method_46431();

        this.method_37063(prevButton);
        this.method_37063(nextButton);
        this.method_37063(doneButton);

        updateButtonStates();
    }

    private void changePage(int delta) {
        pageIndex = Math.max(0, Math.min(TOTAL_PAGES - 1, pageIndex + delta));
        updateButtonStates();
    }

    private void updateButtonStates() {
        prevButton.field_22763 = pageIndex > 0;
        nextButton.field_22763 = pageIndex < TOTAL_PAGES - 1;
    }

    /**
     * v0.6.1: override the parent's renderBackground to a no-op so calling
     * super.render(...) at the END of our render() doesn't re-blur over
     * our book content. We handle background ourselves explicitly at the
     * top of render().
     */
    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // No-op. Real background drawn from render() directly.
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // 1) Draw the screen darkening + blur ONCE, ourselves.
        super.method_25420(ctx, mouseX, mouseY, delta);

        int bookLeft = (this.field_22789 - BOOK_WIDTH) / 2;
        int bookTop = (this.field_22790 - BOOK_HEIGHT) / 2;

        // 2) Draw the book texture as a foreground.
        ctx.method_25290(BOOK_TEXTURE, bookLeft, bookTop, 0, 0, BOOK_WIDTH, BOOK_HEIGHT, 256, 256);

        // 3) Page content overlay.
        if (pageIndex == 0) {
            renderCoverPage(ctx, bookLeft, bookTop);
        } else {
            Element element = Element.values()[pageIndex - 1];
            renderElementPage(ctx, bookLeft, bookTop, element);
        }

        // 4) Buttons — super.render handles them. Our overridden
        // renderBackground above is a no-op, so super won't re-blur.
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    private void renderCoverPage(class_332 ctx, int bookLeft, int bookTop) {
        int textLeft = bookLeft + 36;
        int contentTop = bookTop + 30;

        ctx.method_51439(this.field_22793,
                class_2561.method_43470("Bestiary of Inari").method_27695(class_124.field_1065, class_124.field_1067),
                textLeft, contentTop, 0x000000, false);

        ctx.method_51439(this.field_22793,
                class_2561.method_43470("Discovered: " + totalDiscovered + " / " + maxEntries)
                        .method_27692(class_124.field_1063),
                textLeft, contentTop + 16, 0x000000, false);

        String[] blurb = {
                "The kitsune walk among",
                "us. Those whom you have",
                "inquired upon are recorded",
                "here.",
                "",
                "Turn the pages to behold",
                "the nine kami of Inari."
        };
        for (int i = 0; i < blurb.length; i++) {
            ctx.method_51439(this.field_22793,
                    class_2561.method_43470(blurb[i]).method_27695(class_124.field_1063, class_124.field_1056),
                    textLeft, contentTop + 40 + i * 11, 0x000000, false);
        }

        ctx.method_51439(this.field_22793,
                class_2561.method_43470("Page " + (pageIndex + 1) + " / " + TOTAL_PAGES)
                        .method_27692(class_124.field_1063),
                textLeft, bookTop + BOOK_HEIGHT - 42, 0x000000, false);
    }

    private void renderElementPage(class_332 ctx, int bookLeft, int bookTop, Element element) {
        int textLeft = bookLeft + 36;
        int contentTop = bookTop + 22;

        ctx.method_51439(this.field_22793,
                class_2561.method_43470(element.kamiName()).method_27695(element.color(), class_124.field_1067),
                textLeft, contentTop, 0x000000, false);

        List<net.minecraft.class_5481> wrapped = this.field_22793.method_1728(
                class_2561.method_43470(element.flavor()).method_27695(class_124.field_1063, class_124.field_1056),
                BOOK_WIDTH - 70
        );
        int lineY = contentTop + 14;
        for (var line : wrapped) {
            ctx.method_51430(this.field_22793, line, textLeft, lineY, 0x000000, false);
            lineY += 10;
        }

        lineY += 6;
        String[] tiers = {"young", "matured", "venerable", "ancient", "Kyuubi"};
        boolean anyDiscovered = false;
        for (String tier : tiers) {
            String key = element.name() + ":" + tier;
            boolean known = entries.contains(key);
            if (known) anyDiscovered = true;

            class_2561 line = known
                    ? class_2561.method_43470("✓ ").method_27692(class_124.field_1077)
                    .method_27661().method_10852(class_2561.method_43470(tier).method_27692(class_124.field_1074))
                    : class_2561.method_43470("✗ ").method_27692(class_124.field_1063)
                    .method_27661().method_10852(class_2561.method_43470("(unknown)").method_27692(class_124.field_1063));
            ctx.method_51439(this.field_22793, line, textLeft, lineY, 0x000000, false);
            lineY += 11;
        }

        if (anyDiscovered) {
            lineY += 6;
            ctx.method_51439(this.field_22793,
                    class_2561.method_43470("Favored offering:").method_27692(class_124.field_1063),
                    textLeft, lineY, 0x000000, false);
            ctx.method_51439(this.field_22793,
                    class_2561.method_43470(element.correctOffering().method_7848().getString())
                            .method_27692(element.color()),
                    textLeft, lineY + 10, 0x000000, false);
        }

        ctx.method_51439(this.field_22793,
                class_2561.method_43470("Page " + (pageIndex + 1) + " / " + TOTAL_PAGES)
                        .method_27692(class_124.field_1063),
                textLeft, bookTop + BOOK_HEIGHT - 42, 0x000000, false);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public static void open(Set<String> entries, int maxEntries) {
        class_310.method_1551().method_1507(new BestiaryScreen(entries, maxEntries));
    }
}