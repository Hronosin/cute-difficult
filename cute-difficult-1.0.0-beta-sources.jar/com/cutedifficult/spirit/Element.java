package com.cutedifficult.spirit;

import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

/**
 * The nine elements of the kitsune spirit system, in fixed order.
 *
 * <p>Each element has:
 * <ul>
 *   <li>A Japanese name ({@link #kamiName()}) — used in lore and the codex.</li>
 *   <li>A flavor description ({@link #flavor()}).</li>
 *   <li>A color ({@link #color()}) used for particle effects, tail glow,
 *       and codex entries.</li>
 *   <li>A "correct" offering item ({@link #correctOffering()}) — the item
 *       a fox of this element wants. Other items either do nothing
 *       (neutral) or actively offend (see {@link OfferingResult}).</li>
 *   <li>A list of items considered "offensive" to this element —
 *       offering one of these triggers a Lesser Mark, slows future
 *       interactions, and may shift the local social network.</li>
 * </ul>
 *
 * <p>This enum is the source of truth for the entire elemental matrix.
 * Other systems (offering handler, codex generator, shrine generator,
 * fox spawn logic) all read from here. Adding/removing an element means
 * exactly one edit point.
 *
 * <p>Design note: we use a record-like pattern instead of pure data
 * methods because the metadata is conceptually constant. If Java let us
 * have constants attached to enum cases without per-method override
 * boilerplate, we'd use that — but this is the cleanest available
 * version in plain Java 21.
 */
public enum Element {
    KASAI(
            "Kasai", "fire",
            "The element of consumption, sun, and forge. Foxes of Kasai burn with constant inner heat.",
            class_124.field_1061,
            class_1802.field_8135,
            new class_1792[]{class_1802.field_8705, class_1802.field_8426, class_1802.field_8178, class_1802.field_8543}
    ),
    MIZU(
            "Mizu", "water",
            "The element of flow, depths, and reflection. Mizu foxes seek still waters.",
            class_124.field_1075,
            class_1802.field_8846,
            new class_1792[]{class_1802.field_8135, class_1802.field_8183, class_1802.field_8054}
    ),
    DAICHI(
            "Daichi", "earth",
            "The element of stone, root, and patience. Daichi foxes are heavy-pawed and slow to anger.",
            class_124.field_1065,
            class_1802.field_27063,
            new class_1792[]{class_1802.field_8153, class_1802.field_8614}
    ),
    KAZE(
            "Kaze", "wind",
            "The element of breath, height, and sudden change. Kaze foxes are restless.",
            class_124.field_1068,
            class_1802.field_8614,
            new class_1792[]{class_1802.field_20391, class_1802.field_20412, class_1802.field_8831}
    ),
    KAMINARI(
            "Kaminari", "thunder",
            "The element of storms and revelation. Kaminari foxes appear only with rain on the horizon.",
            class_124.field_1054,
            class_1802.field_27022,
            new class_1792[]{class_1802.field_8745, class_1802.field_19044, class_1802.field_19059}
    ),
    MORI(
            "Mori", "forest",
            "The element of green life. Mori foxes refuse meat — they remember every grain of pollen.",
            class_124.field_1060,
            class_1802.field_16998,
            new class_1792[]{class_1802.field_8046, class_1802.field_8389, class_1802.field_8726, class_1802.field_8748, class_1802.field_8504, class_1802.field_8511}
    ),
    KORI(
            "Kori", "ice",
            "The element of stillness and preservation. Kori foxes do not blink.",
            class_124.field_1078,
            class_1802.field_8178,
            new class_1792[]{class_1802.field_8135, class_1802.field_8183, class_1802.field_8187, class_1802.field_8814}
    ),
    YUREI(
            "Yurei", "spirit",
            "The element of memory and what remains. Yurei foxes can only be seen by the awakened.",
            class_124.field_1076,
            class_1802.field_38746,
            new class_1792[]{class_1802.field_8463, class_1802.field_8367} // they reject mortal medicine
    ),
    TENGOKU(
            "Tengoku", "sky",
            "The element of celestial fire. Tengoku foxes look only at the stars.",
            class_124.field_1075,
            class_1802.field_8613,
            new class_1792[]{class_1802.field_8328, class_1802.field_8067, class_1802.field_21999} // they reject the underworld
    );

    private final String kamiName;
    private final String shortName;
    private final String flavor;
    private final class_124 color;
    private final class_1792 correctOffering;
    private final class_1792[] offensiveOfferings;

    Element(
            String kamiName,
            String shortName,
            String flavor,
            class_124 color,
            class_1792 correctOffering,
            class_1792[] offensiveOfferings
    ) {
        this.kamiName = kamiName;
        this.shortName = shortName;
        this.flavor = flavor;
        this.color = color;
        this.correctOffering = correctOffering;
        this.offensiveOfferings = offensiveOfferings;
    }

    public String kamiName() { return kamiName; }
    public String shortName() { return shortName; }
    public String flavor() { return flavor; }
    public class_124 color() { return color; }
    public class_1792 correctOffering() { return correctOffering; }
    public class_1792[] offensiveOfferings() { return offensiveOfferings; }

    public boolean isOffended(class_1792 item) {
        for (class_1792 bad : offensiveOfferings) {
            if (bad == item) return true;
        }
        return false;
    }

    /**
     * Returns a random element. Used at fox spawn to assign an element if
     * the fox doesn't have one yet.
     */
    public static Element random(java.util.Random rng) {
        return values()[rng.nextInt(values().length)];
    }
}