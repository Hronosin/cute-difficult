package com.cutedifficult.spirit;

import com.cutedifficult.event.ResonanceBlessingHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4019;

/**
 * Centralized "should this fox attack this player?" decision.
 *
 * <p>v0.6.3 deduplication: previously trust/witness/great-blessing checks
 * were scattered across {@link com.cutedifficult.entity.ai.KitsuneAttackGoal},
 * {@link com.cutedifficult.event.FoxAbilityHandler},
 * {@link com.cutedifficult.event.FoxAggressionHandler}, and
 * {@link com.cutedifficult.entity.ai.KitsuneMeleeGoal} — and some of
 * them only had partial logic. Refactor: every code path that's about
 * to cast an ability or initiate combat MUST call {@link #canAttack}
 * first. One source of truth.
 *
 * <p>Also adds {@link #hasLineOfSight} so attacks don't happen through
 * walls — addresses the "kitsune shoots fireballs through a stone wall"
 * complaint.
 *
 * <p>Rules in priority order:
 * <ol>
 *   <li><b>Great Blessing of Inari</b> on player → always peaceful.</li>
 *   <li><b>Witnessed killings &gt; 0</b> → fox attacks regardless of trust.</li>
 *   <li><b>Trust ≥ {@link #FRIENDLY_TRUST_THRESHOLD}</b> → friendly, no attack.</li>
 *   <li>Otherwise → attack permitted.</li>
 * </ol>
 */
public final class FoxHostility {

    public static final int FRIENDLY_TRUST_THRESHOLD = 30;

    private FoxHostility() {}

    public static boolean canAttack(class_4019 fox, class_3222 target) {
        if (target == null || !target.method_5805()) return false;
        if (target.method_7337() || target.method_7325()) return false;

        // v0.9.7: if the player recently attacked THIS specific fox,
        // its rage overrides everything — even the Great Blessing of
        // Inari. Otherwise blessed players could massacre kitsune
        // without retaliation, which breaks the moral logic of the
        // whole system. The grudge times out after a few seconds
        // (see FoxRageHandler.RAGE_TICKS).
        if (com.cutedifficult.event.FoxRageHandler.isEnragedAt(fox, target)) {
            return true;
        }

        // Great Blessing overrides everything else.
        if (ResonanceBlessingHandler.hasGreatBlessing(target)) return false;

        KitsuneData data = FoxStorage.peekCache(fox);
        if (data == null) {
            // No data cached yet — treat as hostile (default-aggressive new fox).
            return true;
        }

        // Witnessed killings override trust.
        if (data.witnessedKills > 0) return true;

        // Friendly foxes don't attack.
        if (data.trustLevel >= FRIENDLY_TRUST_THRESHOLD) return false;

        return true;
    }

    /**
     * Line-of-sight check: is there an unobstructed path from the fox's
     * eyes to the target's center? Returns false if a solid block is in
     * the way.
     */
    public static boolean hasLineOfSight(class_4019 fox, class_1297 target) {
        class_1937 world = fox.method_37908();
        class_243 from = fox.method_19538().method_1031(0, fox.method_5751(), 0);
        class_243 to = target.method_19538().method_1031(0, target.method_17682() * 0.5, 0);

        class_3959 ctx = new class_3959(
            from, to,
            class_3959.class_3960.field_17558,
            class_3959.class_242.field_1348,
            fox
        );
        class_3965 hit = world.method_17742(ctx);
        return hit.method_17783() == class_239.class_240.field_1333;
    }

    /**
     * Convenience: both checks combined. Most callers want this.
     */
    public static boolean canAttackWithLineOfSight(class_4019 fox, class_3222 target) {
        return canAttack(fox, target) && hasLineOfSight(fox, target);
    }
}
