package com.cutedifficult.spirit;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

/**
 * Element-specific blessings granted by friendly foxes after offerings.
 *
 * <p>Each element has a thematic blessing — buff(s) appropriate to the
 * element. Duration and amplifier scale with tail count of the granting
 * fox: more tails = longer, stronger blessing.
 *
 * <p>Blessings are applied directly as vanilla status effects so they're
 * visible in the inventory effects panel and consumed by death etc.
 * normally. They stack-by-replacement: a new blessing of the same type
 * overrides duration, but doesn't compound amplifiers.
 *
 * <p>This is the player-facing reward for tending kitsune — concrete,
 * felt power in exchange for grinding spiritual capital.
 */
public final class Blessings {

    private Blessings() {}

    /**
     * Apply the appropriate blessing for the given element and tail
     * count to the player. Called from {@code FoxOfferingHandler} when
     * a successful offering happens and trust crosses a threshold.
     */
    public static void grant(class_3222 player, Element element, int tails) {
        // Duration scales 600..3600 ticks (30s..3min) with tails.
        int duration = 600 + tails * 333; // 1 tail = 933 ticks ~46s; 9 tails = 3597 ~3min
        // Amplifier: 0 (Level I) for low tails, up to 2 (Level III) for Kyuubi.
        int amplifier = Math.min(2, (tails - 1) / 3);

        switch (element) {
            case KASAI -> applyMulti(player, duration, amplifier,
                class_1294.field_5918, class_1294.field_5910);
            case MIZU -> applyMulti(player, duration, amplifier,
                class_1294.field_5923, class_1294.field_5900);
            case DAICHI -> applyMulti(player, duration, amplifier,
                class_1294.field_5907, class_1294.field_5917);
            case KAZE -> applyMulti(player, duration, amplifier,
                class_1294.field_5904, class_1294.field_5913);
            case KAMINARI -> applyMulti(player, duration, amplifier,
                class_1294.field_5910, class_1294.field_5904);
            case MORI -> applyMulti(player, duration, amplifier,
                class_1294.field_5924, class_1294.field_5926);
            case KORI -> applyMulti(player, duration, amplifier,
                class_1294.field_5907, class_1294.field_5906);
            case YUREI -> applyMulti(player, duration, amplifier,
                class_1294.field_5925, class_1294.field_5905);
            case TENGOKU -> applyMulti(player, duration, amplifier,
                class_1294.field_5924, class_1294.field_5922, class_1294.field_18980);
        }
    }

    @SafeVarargs
    private static void applyMulti(
        class_3222 player,
        int duration,
        int amplifier,
        net.minecraft.class_6880<net.minecraft.class_1291>... effects
    ) {
        for (var effect : effects) {
            player.method_6092(new class_1293(
                effect, duration, amplifier, false, true, true
            ));
        }
    }
}
