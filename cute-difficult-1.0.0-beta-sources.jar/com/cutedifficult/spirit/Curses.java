package com.cutedifficult.spirit;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;
import net.minecraft.class_6880;

/**
 * Element-specific curses applied by enraged foxes (offended via wrong
 * offering, or attacking the fox).
 *
 * <p>Mirror of {@link Blessings} — same dispatch shape, opposite intent.
 * Each element thematic in its punishment.
 *
 * <p>Duration scales with the fox's tail count: a 9-tail Kyuubi's curse
 * lasts MUCH longer than a 2-tail's. Amplifier follows same tiering.
 *
 * <p>Mechanic: curses are vanilla negative status effects, so milk
 * removes them, totem of undying does not interact (we already disabled
 * its save-from-death effect), and natural duration applies. Player can
 * cleanse with milk; that's intentional — curses should hurt but not
 * be permanently uncleansable.
 */
public final class Curses {

    private Curses() {}

    public static void inflict(class_3222 player, Element element, int tails) {
        // Curse duration is shorter than blessing — 400..2200 ticks (20s..110s).
        int duration = 400 + tails * 200;
        int amplifier = Math.min(2, (tails - 1) / 3);

        switch (element) {
            case KASAI -> applyMulti(player, duration, amplifier,
                class_1294.field_5911, class_1294.field_5903);
            case MIZU -> applyMulti(player, duration, amplifier,
                class_1294.field_5909, class_1294.field_5901);
            case DAICHI -> applyMulti(player, duration, amplifier,
                class_1294.field_5909, class_1294.field_5901);
            case KAZE -> applyMulti(player, duration, amplifier,
                class_1294.field_5909, class_1294.field_5911);
            case KAMINARI -> applyMulti(player, duration, amplifier,
                class_1294.field_5919, class_1294.field_5911);
            case MORI -> applyMulti(player, duration, amplifier,
                class_1294.field_5899, class_1294.field_5908);
            case KORI -> applyMulti(player, duration, amplifier,
                class_1294.field_5909, class_1294.field_5901);
            case YUREI -> applyMulti(player, duration, amplifier,
                class_1294.field_5919, class_1294.field_38092);
            case TENGOKU -> applyMulti(player, duration, amplifier,
                class_1294.field_5912, class_1294.field_5902);
        }
    }

    @SafeVarargs
    private static void applyMulti(
        class_3222 player,
        int duration,
        int amplifier,
        net.minecraft.class_6880<net.minecraft.class_1291>... effects
    ) {
        for (var effect : effects) {
            player.method_6092(new class_1293(
                effect, duration, amplifier, false, true, true
            ));
        }
    }
}
