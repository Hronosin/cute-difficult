package com.cutedifficult.spirit;

import java.util.Random;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.class_2487;
import net.minecraft.class_4019;

/**
 * Cache + NBT serialization for {@link KitsuneData}.
 *
 * <p>The data class itself ({@link KitsuneData}) is dumb — just public final
 * fields. All logic lives here:
 * <ul>
 *   <li>{@link #getOrCreate} — primary read path, used by every handler</li>
 *   <li>{@link #store} — write to cache</li>
 *   <li>{@link #peekCache} — peek without creating</li>
 *   <li>{@link #injectIntoCache} — set from NBT load</li>
 *   <li>{@link #toNbt} / {@link #fromNbt} — persistence</li>
 *   <li>{@link #generate} — randomized initialization</li>
 * </ul>
 *
 * <p>This separation makes the system robust: the data class can never
 * "be broken" by record-related compilation quirks because it has no
 * record-magic at all. All quirks are isolated to FoxStorage where they
 * can be debugged in one place.
 */
public final class FoxStorage {

    public static final String NBT_KEY = "cd_fox_data";

    private static final WeakHashMap<UUID, KitsuneData> CACHE = new WeakHashMap<>();

    private FoxStorage() {}

    public static class_2487 toNbt(KitsuneData data) {
        class_2487 nbt = new class_2487();
        nbt.method_10582("element", data.element.name());
        nbt.method_10566("personality", data.personality.toNbt());
        nbt.method_10569("tails", data.tails);
        nbt.method_10569("trustLevel", data.trustLevel);
        nbt.method_10544("lastFedTickStamp", data.lastFedTickStamp);
        nbt.method_10569("witnessedKills", data.witnessedKills);
        nbt.method_10582("customName", data.customName);
        nbt.method_10544("lastPettedTickStamp", data.lastPettedTickStamp);
        return nbt;
    }

    public static KitsuneData fromNbt(class_2487 nbt) {
        Element element;
        try {
            element = Element.valueOf(nbt.method_10558("element"));
        } catch (IllegalArgumentException e) {
            element = Element.KASAI;
        }
        FoxPersonality personality = FoxPersonality.fromNbt(nbt.method_10562("personality"));
        return new KitsuneData(
            element,
            personality,
            nbt.method_10550("tails"),
            nbt.method_10550("trustLevel"),
            nbt.method_10537("lastFedTickStamp"),
            nbt.method_10550("witnessedKills"),
            nbt.method_10545("customName") ? nbt.method_10558("customName") : "",
            nbt.method_10545("lastPettedTickStamp") ? nbt.method_10537("lastPettedTickStamp") : 0L
        );
    }

    public static KitsuneData generate(Random rng) {
        return new KitsuneData(
            Element.random(rng),
            FoxPersonality.random(rng),
            1, 0, 0L, 0, "", 0L
        );
    }

    public static KitsuneData getOrCreate(class_4019 fox, Random rng) {
        UUID id = fox.method_5667();
        KitsuneData cached = CACHE.get(id);
        if (cached != null) return cached;
        KitsuneData fresh = generate(rng);
        CACHE.put(id, fresh);
        return fresh;
    }

    public static void store(class_4019 fox, KitsuneData data) {
        CACHE.put(fox.method_5667(), data);
    }

    public static KitsuneData peekCache(class_4019 fox) {
        return CACHE.get(fox.method_5667());
    }

    public static void injectIntoCache(class_4019 fox, KitsuneData data) {
        CACHE.put(fox.method_5667(), data);
    }
}
