package com.cutedifficult.spirit;

import com.cutedifficult.CuteDifficult;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.server.MinecraftServer;

/**
 * The fully suffocating Spirit system. Replaces the single Spirit scoreboard
 * value with NINE element-specific values, plus purity and resonance metrics.
 *
 * <p>The player's spiritual standing is no longer "I have 47 Spirit". It is:
 *
 * <pre>
 *   Kasai Spirit: 12 / 100
 *   Mizu Spirit: 5 / 100
 *   Daichi Spirit: 23 / 100
 *   Kaze Spirit: 0 / 100
 *   Kaminari Spirit: 0 / 100
 *   Mori Spirit: 41 / 100
 *   Kori Spirit: 8 / 100
 *   Yurei Spirit: 0 / 100
 *   Tengoku Spirit: 0 / 100
 *
 *   Total Purity: 67%
 *   Resonance: 4 (of 9)
 *   Hollow risk: low
 * </pre>
 *
 * <p>To approach a Kyuubi of Kasai, you need {@code Kasai Spirit} above 60.
 * Total Spirit doesn't help — only the matching element. To perform certain
 * cross-elemental rituals, you need Resonance (number of elements above
 * threshold) at a minimum count.
 *
 * <p><b>Hollow check</b>: the {@code totalSpirit()} of all nine is permitted
 * to go negative. Below 0 total, the player enters Hollow state.
 *
 * <p><b>Stored in scoreboard objectives:</b> one objective per element
 * ({@code cd_spirit_kasai}, {@code cd_spirit_mizu}, etc.) so they persist
 * with the world. The legacy {@code cd_spirit} from v0.1 is kept for
 * backward compatibility but is now COMPUTED as the sum.
 *
 * <p>Players who started a world in v0.1/0.2 will see their accumulated
 * {@code cd_spirit} ignored — fresh start on the 9-axis system. This is
 * deliberate: the new system isn't backward-mappable, and committing to
 * a fresh accounting matches the "ascetic restart" the late-game requires
 * anyway.
 *
 * <p><b>Display:</b> sidebar can only show ONE objective. We rotate through
 * the elements based on which the player has the highest value in, so the
 * sidebar shows what's most relevant. {@code /cd spirit} reveals the full
 * matrix.
 */
public final class SpiritData {

    /** Per-element scoreboard objective IDs. */
    public static String objectiveFor(Element element) {
        return "cd_spirit_" + element.shortName();
    }

    /** Karma is unchanged from v0.1. */
    public static final String KARMA_OBJECTIVE = "cd_karma";

    /** Marker tag — set when a player has been initialized in v0.3+. */
    public static final String INIT_TAG = "cd_initialized_v3";

    /** Starting value for each element when player joins fresh. */
    public static final int DEFAULT_PER_ELEMENT = 1;

    /** Threshold above which an element "counts" for resonance. */
    public static final int RESONANCE_THRESHOLD = 10;

    private SpiritData() {}

    public static void ensureObjectives(MinecraftServer server) {
        class_269 scoreboard = server.method_3845();

        for (Element element : Element.values()) {
            String objId = objectiveFor(element);
            if (scoreboard.method_1170(objId) == null) {
                scoreboard.method_1168(
                    objId,
                    class_274.field_1468,
                    class_2561.method_43470(element.kamiName() + " Spirit").method_27692(element.color()),
                    class_274.class_275.field_1472,
                    true,
                    null
                );
                CuteDifficult.LOGGER.info("[CuteDifficult] Registered Spirit objective for {}", element);
            }
        }

        if (scoreboard.method_1170(KARMA_OBJECTIVE) == null) {
            scoreboard.method_1168(
                KARMA_OBJECTIVE,
                class_274.field_1468,
                class_2561.method_43470("Karma").method_27692(class_124.field_1061),
                class_274.class_275.field_1472,
                true,
                null
            );
        }
    }

    public static void initializePlayer(MinecraftServer server, class_9015 holder) {
        if (holder instanceof net.minecraft.class_3222 player) {
            if (player.method_5752().contains(INIT_TAG)) return;
            player.method_5780(INIT_TAG);
        }

        class_269 scoreboard = server.method_3845();
        for (Element element : Element.values()) {
            class_266 obj = scoreboard.method_1170(objectiveFor(element));
            if (obj != null) {
                scoreboard.method_1180(holder, obj).method_55410(DEFAULT_PER_ELEMENT);
            }
        }

        class_266 karma = scoreboard.method_1170(KARMA_OBJECTIVE);
        if (karma != null) {
            scoreboard.method_1180(holder, karma).method_55410(0);
        }
    }

    // --- Per-element read/write ---

    public static int get(MinecraftServer server, class_9015 holder, Element element) {
        class_266 obj = server.method_3845().method_1170(objectiveFor(element));
        if (obj == null) return 0;
        return server.method_3845().method_1180(holder, obj).method_55409();
    }

    public static void set(MinecraftServer server, class_9015 holder, Element element, int value) {
        class_266 obj = server.method_3845().method_1170(objectiveFor(element));
        if (obj == null) return;
        int clamped = Math.max(-100, Math.min(100, value));
        server.method_3845().method_1180(holder, obj).method_55410(clamped);
    }

    public static void add(MinecraftServer server, class_9015 holder, Element element, int delta) {
        set(server, holder, element, get(server, holder, element) + delta);
    }

    // --- Derived metrics ---

    /**
     * Sum of Spirit across all nine elements. Below 0 = Hollow.
     */
    public static int totalSpirit(MinecraftServer server, class_9015 holder) {
        int total = 0;
        for (Element element : Element.values()) {
            total += get(server, holder, element);
        }
        return total;
    }

    /**
     * "Resonance" — number of elements where Spirit >= {@link #RESONANCE_THRESHOLD}.
     * Range 0..9. Needed for certain cross-element rituals.
     */
    public static int resonance(MinecraftServer server, class_9015 holder) {
        int count = 0;
        for (Element element : Element.values()) {
            if (get(server, holder, element) >= RESONANCE_THRESHOLD) {
                count++;
            }
        }
        return count;
    }

    /**
     * Purity (0..1) — sum of POSITIVE elements / sum of |all elements|.
     * Players close to Hollow have low purity even if they have one
     * strongly-developed element, because negatives drag it down.
     */
    public static double purity(MinecraftServer server, class_9015 holder) {
        int positive = 0;
        int absolute = 0;
        for (Element element : Element.values()) {
            int v = get(server, holder, element);
            if (v > 0) positive += v;
            absolute += Math.abs(v);
        }
        if (absolute == 0) return 0.0;
        return (double) positive / absolute;
    }

    /**
     * Which element does the player have the most Spirit in? Used for
     * sidebar display rotation.
     */
    public static Element dominantElement(MinecraftServer server, class_9015 holder) {
        Element best = Element.KASAI;
        int bestValue = Integer.MIN_VALUE;
        for (Element element : Element.values()) {
            int v = get(server, holder, element);
            if (v > bestValue) {
                bestValue = v;
                best = element;
            }
        }
        return best;
    }

    // --- Karma (unchanged) ---

    public static int getKarma(MinecraftServer server, class_9015 holder) {
        class_266 obj = server.method_3845().method_1170(KARMA_OBJECTIVE);
        if (obj == null) return 0;
        return server.method_3845().method_1180(holder, obj).method_55409();
    }

    public static void addKarma(MinecraftServer server, class_9015 holder, int delta) {
        class_266 obj = server.method_3845().method_1170(KARMA_OBJECTIVE);
        if (obj == null) return;
        var score = server.method_3845().method_1180(holder, obj);
        score.method_55410(score.method_55409() + delta);
    }
}
