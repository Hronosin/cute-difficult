package com.cutedifficult.util;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import com.cutedifficult.spirit.SpiritData;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_3222;
import net.minecraft.class_9015;
import net.minecraft.server.MinecraftServer;

/**
 * Wraps the scoreboard objectives used to track Spirit and Karma.
 *
 * <p><b>Fixes applied in v0.1.1:</b>
 * <ul>
 *   <li>Spirit objective is now bound to the SIDEBAR display slot, so it
 *       actually shows up on the player's HUD on the right side of the
 *       screen. Previously it existed only as invisible data.</li>
 *   <li>Initialization to the default Spirit value of 5 was buggy — it used
 *       a non-existent {@code isLocked()} check and never reliably ran.
 *       Now we mark the player with a command tag {@code cd_initialized}
 *       on first init; tags persist across sessions, so each player is
 *       initialized exactly once.</li>
 *   <li>Removed the "auto-init on every getSpirit" behavior, which had a
 *       race with the scoreboard's default-0 state. Initialization is now
 *       explicit via {@link #initializePlayer}, called from the join handler.</li>
 * </ul>
 *
 * <p><b>Note on display:</b> only ONE objective can occupy SIDEBAR at a time.
 * We give that slot to Spirit because it's the headline progression stat;
 * Karma is queryable via {@code /cd karma} or {@code /scoreboard players list}
 * for now. Proper dual-stat HUD will come with the custom UI in v0.3.
 */
public final class SpiritScoreboard {
    public static final String SPIRIT_OBJECTIVE = "cd_spirit";
    public static final String KARMA_OBJECTIVE = "cd_karma";

    /** Marker tag added to players after their first Spirit initialization. */
    private static final String INIT_TAG = "cd_initialized";

    /** Default Spirit value for a freshly initialized "Mortal" tier player. */
    public static final int DEFAULT_SPIRIT = 5;

    private SpiritScoreboard() {}

    /**
     * Ensures both objectives exist, AND that Spirit is bound to the sidebar.
     * Safe to call repeatedly.
     */
    public static void ensureObjectives(MinecraftServer server) {
        class_269 scoreboard = server.method_3845();

        class_266 spirit = scoreboard.method_1170(SPIRIT_OBJECTIVE);
        if (spirit == null) {
            spirit = scoreboard.method_1168(
                SPIRIT_OBJECTIVE,
                class_274.field_1468,
                class_2561.method_43470("Spirit").method_27692(class_124.field_1075),
                class_274.class_275.field_1472,
                true,
                null
            );
            CuteDifficult.LOGGER.info("[CuteDifficult] Registered Spirit scoreboard objective.");
        }

        class_266 karma = scoreboard.method_1170(KARMA_OBJECTIVE);
        if (karma == null) {
            scoreboard.method_1168(
                KARMA_OBJECTIVE,
                class_274.field_1468,
                class_2561.method_43470("Karma").method_27692(class_124.field_1061),
                class_274.class_275.field_1472,
                true,
                null
            );
            CuteDifficult.LOGGER.info("[CuteDifficult] Registered Karma scoreboard objective.");
        }

        // v0.9.5: create per-element Spirit objectives. SpiritData.get/set use
        // `objectiveFor(element)` which yields e.g. "cd_spirit_kasai" — these
        // need to exist as actual scoreboard objectives, otherwise get returns
        // 0 and set is a silent no-op. Before this fix, all spirit commands
        // were broken (the value never persisted).
        for (Element element : Element.values()) {
            String objId = SpiritData.objectiveFor(element);
            if (scoreboard.method_1170(objId) == null) {
                scoreboard.method_1168(
                    objId,
                    class_274.field_1468,
                    class_2561.method_43470(element.kamiName()).method_27692(element.color()),
                    class_274.class_275.field_1472,
                    true,
                    null
                );
                CuteDifficult.LOGGER.info("[CuteDifficult] Registered Spirit objective for {}", element.name());
            }
        }

        // v0.9: sidebar binding removed. Spirit display now uses the
        // client-side SpiritOverlayHud via custom packets so each player
        // sees their own stats. The scoreboard objective still exists for
        // data storage; we just don't bind it to SIDEBAR anymore.
        // scoreboard.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, spirit);
    }

    /**
     * Initializes a player's Spirit to the default value if they haven't been
     * initialized before. Uses a command tag as a persistent flag.
     *
     * <p>Call this once on player join.
     */
    public static void initializePlayer(MinecraftServer server, class_3222 player) {
        if (player.method_5752().contains(INIT_TAG)) {
            return; // Already initialized in a previous session.
        }
        player.method_5780(INIT_TAG);

        class_266 spirit = server.method_3845().method_1170(SPIRIT_OBJECTIVE);
        if (spirit != null) {
            server.method_3845()
                .method_1180(player, spirit)
                .method_55410(DEFAULT_SPIRIT);
        }

        class_266 karma = server.method_3845().method_1170(KARMA_OBJECTIVE);
        if (karma != null) {
            server.method_3845()
                .method_1180(player, karma)
                .method_55410(0);
        }

        CuteDifficult.LOGGER.info(
            "[CuteDifficult] Initialized Spirit={} Karma=0 for {}",
            DEFAULT_SPIRIT, player.method_5477().getString()
        );
    }

    // === Read/write helpers ===

    public static int getSpirit(MinecraftServer server, class_9015 holder) {
        class_266 objective = server.method_3845().method_1170(SPIRIT_OBJECTIVE);
        if (objective == null) return DEFAULT_SPIRIT;
        return server.method_3845().method_1180(holder, objective).method_55409();
    }

    public static void setSpirit(MinecraftServer server, class_9015 holder, int value) {
        class_266 objective = server.method_3845().method_1170(SPIRIT_OBJECTIVE);
        if (objective == null) return;
        int clamped = Math.max(-100, Math.min(100, value));
        server.method_3845().method_1180(holder, objective).method_55410(clamped);
    }

    public static void addSpirit(MinecraftServer server, class_9015 holder, int delta) {
        setSpirit(server, holder, getSpirit(server, holder) + delta);
    }

    public static int getKarma(MinecraftServer server, class_9015 holder) {
        class_266 objective = server.method_3845().method_1170(KARMA_OBJECTIVE);
        if (objective == null) return 0;
        return server.method_3845().method_1180(holder, objective).method_55409();
    }

    public static void setKarma(MinecraftServer server, class_9015 holder, int value) {
        class_266 objective = server.method_3845().method_1170(KARMA_OBJECTIVE);
        if (objective == null) return;
        server.method_3845().method_1180(holder, objective).method_55410(value);
    }

    public static void addKarma(MinecraftServer server, class_9015 holder, int delta) {
        setKarma(server, holder, getKarma(server, holder) + delta);
    }
}
