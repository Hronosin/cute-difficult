package com.cutedifficult.mixin;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.util.DifficultyMode;
import com.cutedifficult.util.FurnaceOverheatTracker;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks into the static {@code tick} method of {@link class_2609}
 * to drive the overheat mechanic. Catches all three variants — regular
 * furnace, blast furnace, smoker — because they all inherit this tick.
 *
 * <p>The vanilla tick fires once per game tick per loaded furnace. We
 * inject at TAIL (after vanilla burn/cook logic has fully run for this
 * tick), so we see the resulting BlockState (LIT updated, cookTime
 * advanced) when we read it. This is the most predictable injection
 * point.
 *
 * <p>We're a no-op on the client side and in Path of Peace mode — the
 * tracker call is cheap but checks reduce noise.
 */
@Mixin(class_2609.class)
public abstract class FurnaceOverheatMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private static void cuteDifficult$onFurnaceTick(
        class_1937 world,
        class_2338 pos,
        class_2680 state,
        class_2609 blockEntity,
        CallbackInfo ci
    ) {
        if (!(world instanceof class_3218 serverWorld)) return;
        if (CuteDifficult.currentMode != DifficultyMode.CRUEL) return;

        FurnaceOverheatTracker.tickFurnace(serverWorld, pos, state);
    }
}
