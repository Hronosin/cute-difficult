package com.cutedifficult.item;

import com.cutedifficult.spirit.BestiaryData;
import com.cutedifficult.spirit.KitsuneData;
import com.cutedifficult.spirit.FoxStorage;
import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4019;

/**
 * The Scroll of Inquiry — single-use item that records a fox's spiritual
 * data into the player's Bestiary.
 *
 * <p>Right-click on a fox while holding the scroll:
 * <ol>
 *   <li>If the fox's element + tail bucket is already recorded, the
 *       scroll is wasted (no benefit).</li>
 *   <li>If the entry is new, the scroll is consumed, a particle burst
 *       around the fox confirms success, and the bestiary entry is
 *       added with element name, tail count tier, and a brief flavor
 *       summary.</li>
 * </ol>
 *
 * <p>The scroll deliberately doesn't reveal the fox's personality
 * traits — those remain hidden forever. The Bestiary is "what kind of
 * kitsune exist", not "what is this specific one thinking".
 */
public class ScrollOfInquiryItem extends class_1792 {

    private static final Random RANDOM = new Random();

    public ScrollOfInquiryItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        if (!(entity instanceof class_4019 fox)) return class_1269.field_5811;
        if (!(user instanceof class_3222 serverPlayer)) return class_1269.field_5811;
        if (!(user.method_37908() instanceof class_3218 serverWorld)) return class_1269.field_5811;

        KitsuneData data = FoxStorage.getOrCreate(fox, RANDOM);
        boolean isNew = BestiaryData.recordEntry(serverPlayer, data);

        if (!isNew) {
            // Already recorded — give a hint, don't consume the scroll.
            serverPlayer.method_7353(
                class_2561.method_43470("This kitsune's nature is already known to you.")
                    .method_27695(class_124.field_1080, class_124.field_1056),
                true
            );
            return class_1269.field_5814;
        }

        // New entry — consume scroll, celebrate.
        stack.method_7934(1);

        serverWorld.method_14199(
            class_2398.field_11215,
            fox.method_23317(), fox.method_23318() + 0.5, fox.method_23321(),
            20, 0.4, 0.4, 0.4, 0.5
        );
        serverWorld.method_43128(
            null, fox.method_23317(), fox.method_23318(), fox.method_23321(),
            class_3417.field_15119,
            class_3419.field_15248,
            0.8f, 1.3f
        );

        serverPlayer.method_7353(
            class_2561.method_43470("Recorded: ")
                .method_27692(class_124.field_1065)
                .method_10852(class_2561.method_43470(data.element.kamiName() + " kitsune (" + tailTier(data.tails) + ")")
                    .method_27692(data.element.color())),
            false
        );

        return class_1269.field_5812;
    }

    /**
     * Tail count tier label — we don't reveal exact number, only a
     * descriptive bucket. This preserves some mystery — a "young" kitsune
     * could be 1 or 2 tails, you have to look more carefully (or count
     * from the visual aura intensity) to know.
     */
    public static String tailTier(int tails) {
        if (tails <= 2) return "young";
        if (tails <= 4) return "matured";
        if (tails <= 6) return "venerable";
        if (tails <= 8) return "ancient";
        return "Kyuubi";
    }
}
