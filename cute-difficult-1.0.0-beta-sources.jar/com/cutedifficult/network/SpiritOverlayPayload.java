package com.cutedifficult.network;

import com.cutedifficult.CuteDifficult;
import com.cutedifficult.spirit.Element;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Per-player snapshot of spirit state for the HUD overlay.
 *
 * <p>Sent server → client at a low rate (once per second). Carries:
 * <ul>
 *   <li>All 9 element spirit values</li>
 *   <li>Karma value</li>
 *   <li>Whether the Great Blessing of Inari is currently active</li>
 * </ul>
 *
 * <p>Payload format: 9 ints (element order matches Element.values()),
 * one int karma, one byte (0 or 1) for great-blessing flag. ~42 bytes
 * per packet. Negligible bandwidth even at 1/sec for many players.
 */
public record SpiritOverlayPayload(
    Map<Element, Integer> spirits,
    int karma,
    boolean greatBlessing
) implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(CuteDifficult.MOD_ID, "spirit_overlay");
    public static final class_8710.class_9154<SpiritOverlayPayload> PAYLOAD_ID = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, SpiritOverlayPayload> CODEC = class_9139.method_56438(
        SpiritOverlayPayload::write,
        SpiritOverlayPayload::read
    );

    private static void write(SpiritOverlayPayload p, class_2540 buf) {
        for (Element e : Element.values()) {
            buf.method_10804(p.spirits.getOrDefault(e, 0));
        }
        buf.method_10804(p.karma);
        buf.method_52964(p.greatBlessing);
    }

    private static SpiritOverlayPayload read(class_2540 buf) {
        Map<Element, Integer> map = new EnumMap<>(Element.class);
        for (Element e : Element.values()) {
            map.put(e, buf.method_10816());
        }
        int karma = buf.method_10816();
        boolean great = buf.readBoolean();
        return new SpiritOverlayPayload(map, karma, great);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PAYLOAD_ID;
    }
}
