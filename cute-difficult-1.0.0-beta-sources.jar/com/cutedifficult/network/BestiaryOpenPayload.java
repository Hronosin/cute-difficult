package com.cutedifficult.network;

import com.cutedifficult.CuteDifficult;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Server → client packet carrying the bestiary entries for the receiving
 * player. Sent when they open the bestiary; the client renders the GUI
 * with this data.
 *
 * <p>Format: a single varint count followed by N UTF-8 strings (each
 * "ELEMENT:tier" key). Compact, ~10-20 bytes for typical progress.
 */
public record BestiaryOpenPayload(Set<String> entries) implements class_8710 {

    public static final class_2960 ID = class_2960.method_60655(CuteDifficult.MOD_ID, "bestiary_open");
    public static final class_8710.class_9154<BestiaryOpenPayload> PAYLOAD_ID = new class_8710.class_9154<>(ID);

    public static final class_9139<class_2540, BestiaryOpenPayload> CODEC = class_9139.method_56438(
        BestiaryOpenPayload::write,
        BestiaryOpenPayload::read
    );

    private static void write(BestiaryOpenPayload payload, class_2540 buf) {
        buf.method_10804(payload.entries.size());
        for (String key : payload.entries) {
            buf.method_10788(key, 64);
        }
    }

    private static BestiaryOpenPayload read(class_2540 buf) {
        int n = buf.method_10816();
        Set<String> set = new HashSet<>();
        for (int i = 0; i < n; i++) {
            set.add(buf.method_10800(64));
        }
        return new BestiaryOpenPayload(set);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PAYLOAD_ID;
    }
}
