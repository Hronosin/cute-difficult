package com.cutedifficult.quality;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1766;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1820;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Quality system glue.
 *
 * <p>Quality is stored on the ItemStack via the CUSTOM_DATA NBT component
 * — a simple integer index into {@link QualityTier#values()}. CUSTOM_DATA
 * is the right place because (1) it persists with the stack across all
 * vanilla operations (drops, inventory transfers, chest storage), and
 * (2) it doesn't require us to register a new DataComponentType (which
 * involves codecs and registry work and is overkill for a single int).
 *
 * <p>On read, if no quality is set we DO NOT default to anything — null
 * means "no quality applied". This lets us treat freshly-spawned items
 * (like creative-mode `/give`) as untouched until they go through a
 * craft/loot pipeline that calls {@link #ensureQuality}.
 *
 * <p>{@link #ensureQuality} is idempotent — calls it multiple times
 * doesn't re-roll. Call it from craft and loot hooks.
 */
public final class ItemQuality {

    /** Key inside CUSTOM_DATA NBT compound. */
    private static final String NBT_KEY = "cd_quality";

    private static final Random RANDOM = new Random();

    private ItemQuality() {}

    /** Get the tier of a stack, or null if no quality has been set. */
    public static QualityTier get(class_1799 stack) {
        var custom = stack.method_57824(class_9334.field_49628);
        if (custom == null) return null;
        class_2487 nbt = custom.method_57461();
        if (!nbt.method_10573(NBT_KEY, class_2520.field_33253)) return null;
        int idx = nbt.method_10550(NBT_KEY);
        if (idx < 0 || idx >= QualityTier.values().length) return null;
        return QualityTier.values()[idx];
    }

    /** Force a tier onto a stack (overwriting). */
    public static void set(class_1799 stack, QualityTier tier) {
        var custom = stack.method_57825(class_9334.field_49628,
            net.minecraft.class_9279.field_49302);
        class_2487 nbt = custom.method_57461();
        nbt.method_10569(NBT_KEY, tier.ordinal());
        stack.method_57379(class_9334.field_49628, net.minecraft.class_9279.method_57456(nbt));

        // Apply display changes: prefix name with tier, add lore line.
        applyDisplay(stack, tier);
    }

    /**
     * Roll a quality if not present. Returns the (possibly new) tier.
     * Safe to call on stacks that already have quality — it won't re-roll.
     */
    public static QualityTier ensureQuality(class_1799 stack) {
        QualityTier existing = get(stack);
        if (existing != null) return existing;
        if (!appliesTo(stack)) return null;
        QualityTier rolled = QualityTier.roll(RANDOM);
        set(stack, rolled);
        return rolled;
    }

    /** Whether the quality system applies to this item at all. */
    public static boolean appliesTo(class_1799 stack) {
        var item = stack.method_7909();
        return item instanceof class_1829
            || item instanceof class_1766
            || item instanceof class_1810
            || item instanceof class_1743
            || item instanceof class_1821
            || item instanceof class_1794
            || item instanceof class_1835
            || item instanceof class_1820
            || item instanceof class_1738;
    }

    /**
     * Multiplier to apply to damage/protection for this stack. Defaults
     * to 1.0 if no quality (i.e., quality-free stacks act vanilla).
     */
    public static float multiplier(class_1799 stack) {
        QualityTier tier = get(stack);
        return tier == null ? 1.0f : tier.multiplier();
    }

    /**
     * Sets the visible name + lore line to reflect quality.
     */
    private static void applyDisplay(class_1799 stack, QualityTier tier) {
        // Prefix the name with "<Tier> " in the tier's color.
        class_2561 vanillaName = stack.method_7909().method_7848();
        class_2561 newName = class_2561.method_43470(tier.displayName() + " ")
            .method_27692(tier.color())
            .method_27661()
            .method_10852(vanillaName.method_27661().method_27692(class_124.field_1070));
        stack.method_57379(class_9334.field_49631, newName);

        // Add a lore line with the multiplier — replace any prior quality
        // lore if it exists.
        List<class_2561> lore = new ArrayList<>();
        lore.add(class_2561.method_43470(String.format("Quality multiplier: %.2fx", tier.multiplier()))
            .method_27695(tier.color(), class_124.field_1056));
        stack.method_57379(class_9334.field_49632, new class_9290(lore));
    }
}
